const CACHE_NAME = 'resto-ai-offline-v5';
const APP_SHELL = ['/', '/index.html', '/manifest.json', '/static/app-icon.svg', '/static/app-icon-192.png', '/static/app-icon-512.png'];
self.addEventListener('install', (event) => {
  event.waitUntil(caches.open(CACHE_NAME).then(async (cache) => {
    await Promise.all(APP_SHELL.map(async (asset) => {
      try { await cache.add(asset); } catch { /* Một asset phụ lỗi không được làm hỏng toàn bộ PWA. */ }
    }));
    return self.skipWaiting();
  }));
});
self.addEventListener('activate', (event) => {
  event.waitUntil(caches.keys().then((keys) => Promise.all(keys.filter((key) => key !== CACHE_NAME).map((key) => caches.delete(key)))).then(() => self.clients.claim()));
});
self.addEventListener('fetch', (event) => {
  const request = event.request;
  if (request.method !== 'GET' || new URL(request.url).origin !== self.location.origin) return;
  event.respondWith(caches.match(request).then((cached) => cached || fetch(request).then((response) => {
    if (response.ok || response.type === 'opaque') caches.open(CACHE_NAME).then((cache) => cache.put(request, response.clone()));
    return response;
  }).catch(() => request.mode === 'navigate' ? caches.match('/index.html') : new Response('', { status: 504, statusText: 'Offline' }))));
});
function normalizeNotification(payload) {
  const data = payload || {};
  return { id: data.id || `push-${Date.now()}`, kind: data.kind || 'flash', title: data.title || 'Resto.AI có cập nhật mới', body: data.body || 'Mở Resto.AI để xem thông tin mới nhất.', view: data.view || 'forecast', createdAt: data.createdAt || new Date().toISOString(), read: false };
}
self.addEventListener('push', (event) => {
  let payload = {};
  try { payload = event.data ? event.data.json() : {}; } catch { payload = { body: event.data ? event.data.text() : undefined }; }
  const notification = normalizeNotification(payload.notification || payload);
  event.waitUntil(self.registration.showNotification(notification.title, { body: notification.body, icon: '/static/app-icon-192.png', badge: '/static/app-icon-192.png', tag: `resto-ai-${notification.kind}`, renotify: true, data: notification }));
});
self.addEventListener('notificationclick', (event) => {
  event.notification.close();
  event.waitUntil(self.clients.matchAll({ type: 'window', includeUncontrolled: true }).then((windows) => windows.length ? windows[0].focus() : self.clients.openWindow('/')));
});
