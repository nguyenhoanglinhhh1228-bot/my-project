# Resto.AI Mobile

## APK Android

`app-debug.apk` là bản Android đã ký debug để cài trực tiếp trên máy Android. Bản này nhúng toàn bộ giao diện Resto.AI và bộ dự báo offline cục bộ; không cần tài khoản Manus để mở các chức năng đã nhúng.

Cài đặt:

1. Tải file APK.
2. Mở file trên Android.
3. Cho phép trình duyệt/ứng dụng quản lý file cài ứng dụng không rõ nguồn nếu Android hỏi.
4. Bấm **Cài đặt**.

## iOS / IPA

Thư mục `ios/` đã được tạo sẵn với bundle identifier `com.restoai.manager`. Để tạo IPA cài được:

1. Mở `ios/App/App.xcworkspace` bằng Xcode trên macOS.
2. Chọn Team là tài khoản Apple Developer của chủ app.
3. Kiểm tra Bundle Identifier `com.restoai.manager`.
4. Chọn **Product → Archive**.
5. Chọn **Distribute App** để xuất IPA hoặc đưa lên TestFlight/App Store.

IPA cần chữ ký Apple hợp lệ. Không thể tạo IPA cài đặt vĩnh viễn trên Linux hoặc bằng tài khoản Apple miễn phí; tài khoản miễn phí thường chỉ cho sideload thời hạn ngắn. Tài khoản Apple Developer trả phí là yêu cầu của Apple, không phải khóa của Manus.

## Giới hạn độc lập

Các chức năng POS, đơn hàng, kho, sổ quỹ, báo cáo và dự báo cục bộ được nhúng trong app. Đồng bộ nhiều thiết bị, AI máy chủ và cập nhật từ xa không được xem là offline; muốn có các chức năng đó cần một backend riêng do chủ app kiểm soát.
