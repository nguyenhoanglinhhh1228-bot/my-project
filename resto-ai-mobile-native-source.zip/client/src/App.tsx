import { type CSSProperties, type ReactNode, useCallback, useEffect, useMemo, useRef, useState } from 'react';
import {
  AlertTriangle,
  ArrowDownRight,
  ArrowLeftRight,
  ArrowUpRight,
  Bell,
  BellRing,
  Boxes,
  Bot,
  CalendarDays,
  Check,
  CheckCircle2,
  ChevronDown,
  ChevronRight,
  CloudRain,
  CloudSun,
  ClipboardCheck,
  Clock3,
  CircleDollarSign,
  ChefHat,
  ClipboardList,
  Download,
  ExternalLink,
  FileDown,
  History,
  Lightbulb,
  Lock,
  LayoutDashboard,
  MessageCircle,
  Minus,
  MoreHorizontal,
  PackageCheck,
  Pencil,
  Phone,
  Plus,
  RefreshCw,
  ReceiptText,
  Save,
  Search,
  Send,
  Settings,
  SlidersHorizontal,
  ShoppingBasket,
  Smartphone,
  Sun,
  Store,
  Sparkles,
  Trash2,
  Truck,
  TrendingUp,
  Users,
  WalletCards,
  Unlock,
  X,
} from 'lucide-react';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import { predictIngredientDemand } from '@/lib/restaurant-ai';
import type { PredictRequest, PredictResponse, ShoppingListItem, SmartAdvice } from '@/lib/restaurant-ai';
import { Bar } from 'react-chartjs-2';
import { BarElement, CategoryScale, Chart as ChartJS, Legend, LinearScale, Tooltip } from 'chart.js';
import { ErrorBoundary } from '@/components/error-boundary';
import { Toaster } from '@/components/ui/toaster';
import { TooltipProvider } from '@/components/ui/tooltip';

ChartJS.register(CategoryScale, LinearScale, BarElement, Tooltip, Legend);

type View = 'overview' | 'pos' | 'orders' | 'shopping' | 'ledger' | 'forecast' | 'reports' | 'more';
type TransactionType = 'thu' | 'chi';
type ReportType = 'tong-hop' | 'doanh-thu' | 'chi-phi';
type ReportPeriod = 'thang-05-2025' | 'thang-04-2025' | 'tat-ca' | 'tuy-chon';
type Transaction = {
  id: string;
  type: TransactionType;
  category: string;
  note: string;
  amount: number;
  date: string;
  hour?: number;
};
type OrderStatus = 'moi' | 'dang-lam' | 'cho-thanh-toan' | 'hoan-tat';
type Order = {
  id: string;
  channel: 'Tại quán' | 'Mang đi' | 'Online';
  table: string;
  customer: string;
  status: OrderStatus;
  total: number;
  items: number;
  createdAt: string;
  branch: string;
};
type PricePoint = { date: string; price: number };
type Ingredient = {
  id: string;
  name: string;
  unit: string;
  current: number;
  minimum: number;
  price: number;
  updated: string;
  shelfLifeDays?: number;
  supplier?: string;
  priceHistory?: PricePoint[];
};
type Profile = {
  name: string;
  restaurant: string;
  email: string;
  phone: string;
  notifications: boolean;
  weekStart: string;
};
type Role = 'staff' | 'manager';
type AuthUser = {
  id: string;
  tenantId: string;
  username: string;
  displayName: string;
  role: Role;
};
type AuthStatus = 'loading' | 'signed-out' | 'signed-in';
type Modal = 'transaction' | 'ingredient' | 'adjust' | 'fixed-cost' | null;
type FixedCost = {
  id: string;
  name: string;
  amount: number;
  frequency: 'tháng' | 'tuần';
};
type BomLine = {
  ingredientId: string;
  quantity: number;
  unit: string;
};
type MenuVariant = {
  id: string;
  label: string;
  priceDelta: number;
  bom: BomLine[];
};
type MenuModifier = {
  id: string;
  label: string;
  price: number;
  bom: BomLine[];
};
type MenuDish = {
  id: string;
  name: string;
  category: string;
  basePrice: number;
  accent: string;
  short: string;
  variants: MenuVariant[];
  modifiers: MenuModifier[];
  baseBom: BomLine[];
};
type CartLine = {
  id: string;
  dishId: string;
  name: string;
  variant: MenuVariant;
  modifiers: MenuModifier[];
  note: string;
  quantity: number;
  unitPrice: number;
  accent: string;
  short: string;
  bom: BomLine[];
};
type ToastTone = 'success' | 'error' | 'warning';
type NotificationKind = 'shopping' | 'anomaly' | 'flash';
type AuraNotification = {
  id: string;
  kind: NotificationKind;
  title: string;
  body: string;
  view: View;
  createdAt: string;
  read: boolean;
};
type AuraNotificationInput = Omit<AuraNotification, 'id' | 'createdAt' | 'read'> & { id?: string };
function normalizeWorkspace(value?: string | null): View {
  if (value === 'tong-quan' || value === 'overview') return 'overview';
  if (value === 'du-bao' || value === 'forecast') return 'forecast';
  if (value === 'don-hang' || value === 'orders') return 'orders';
  if (value === 'di-cho' || value === 'shopping') return 'shopping';
  if (value === 'giao-dich' || value === 'nguyen-lieu' || value === 'ledger') return 'ledger';
  if (value === 'bao-cao' || value === 'reports') return 'reports';
  if (value === 'mo-rong' || value === 'more') return 'more';
  return 'pos';
}
type DishForecast = {
  id: string;
  name: string;
  servings: number;
  previous: number;
  ingredients: string;
};
type ForecastRecommendation = {
  id: string;
  name: string;
  unit: string;
  quantity: number;
  price: number;
  confirmed: boolean;
};
type SalesDay = {
  date: string;
  weather: 'nắng' | 'mưa' | 'nhiều mây';
  dishes: Record<string, number>;
  waste: number;
};
type ForecastRun = {
  id: string;
  createdAt: string;
  targetDate: string;
  weather: 'nắng' | 'mưa' | 'nhiều mây';
  temperature: number;
  confidence: number;
  note: string;
  dishes: DishForecast[];
  recommendations: ForecastRecommendation[];
};
type MlForecast = PredictResponse;

const queryClient = new QueryClient();
const today = new Date().toISOString().slice(0, 10);
const notificationStorageKey = 'resto-ai-notifications';
const notificationPromptKey = 'resto-ai-notification-prompt-seen';
const authRememberKey = 'resto-ai-remembered-login';
const seedTransactions: Transaction[] = [
  { id: 'tx-1', type: 'thu', category: 'Bán hàng', note: 'Doanh thu ca trưa', amount: 4280000, date: today, hour: 12 },
  { id: 'tx-2', type: 'chi', category: 'Nguyên liệu', note: 'Thịt bò tươi & rau thơm', amount: 1620000, date: today, hour: 13 },
  { id: 'tx-3', type: 'thu', category: 'Bán hàng', note: 'Doanh thu ca tối', amount: 5960000, date: '2025-05-26', hour: 19 },
  { id: 'tx-4', type: 'chi', category: 'Nhân sự', note: 'Lương ca tuần 4', amount: 3750000, date: '2025-05-25', hour: 14 },
  { id: 'tx-5', type: 'chi', category: 'Vận hành', note: 'Điện, nước tháng 5', amount: 2180000, date: '2025-05-24' },
  { id: 'tx-6', type: 'thu', category: 'Bán hàng', note: 'Đơn mang đi', amount: 2840000, date: '2025-05-23', hour: 17 },
  { id: 'tx-7', type: 'chi', category: 'Nguyên liệu', note: 'Bún, bánh phở & gia vị', amount: 940000, date: '2025-05-22' },
  { id: 'tx-8', type: 'thu', category: 'Bán hàng', note: 'Doanh thu ca tối', amount: 5120000, date: '2025-05-21', hour: 19 },
];
const seedOrders: Order[] = [
  { id: 'DH-1048', channel: 'Tại quán', table: 'Bàn 06', customer: 'Khách lẻ', status: 'cho-thanh-toan', total: 286000, items: 4, createdAt: '17:28', branch: 'Bếp Nhà Mình' },
  { id: 'DH-1047', channel: 'Online', table: 'Giao tận nơi', customer: 'Nguyễn Minh', status: 'dang-lam', total: 412000, items: 6, createdAt: '17:21', branch: 'Bếp Nhà Mình' },
  { id: 'DH-1046', channel: 'Mang đi', table: 'Take-away', customer: 'Khách lẻ', status: 'moi', total: 156000, items: 3, createdAt: '17:15', branch: 'Bếp Nhà Mình' },
  { id: 'DH-1045', channel: 'Tại quán', table: 'Bàn 02', customer: 'Khách lẻ', status: 'hoan-tat', total: 534000, items: 8, createdAt: '17:02', branch: 'Bếp Nhà Mình' },
  { id: 'DH-1044', channel: 'Online', table: 'Giao tận nơi', customer: 'Trần An', status: 'hoan-tat', total: 298000, items: 4, createdAt: '16:48', branch: 'Bếp Nhà Mình' },
];
const seedIngredients: Ingredient[] = [
  { id: 'ing-1', name: 'Thịt bò thăn', unit: 'kg', current: 8.4, minimum: 12, price: 210000, updated: today, shelfLifeDays: 3 },
  { id: 'ing-2', name: 'Bánh phở tươi', unit: 'kg', current: 19, minimum: 15, price: 32000, updated: today, shelfLifeDays: 2 },
  { id: 'ing-3', name: 'Rau quế', unit: 'bó', current: 24, minimum: 20, price: 9000, updated: '2025-05-26', shelfLifeDays: 2 },
  { id: 'ing-4', name: 'Hành lá', unit: 'kg', current: 3.2, minimum: 5, price: 38000, updated: today, shelfLifeDays: 2 },
  { id: 'ing-5', name: 'Nước mắm nhĩ', unit: 'chai', current: 11, minimum: 6, price: 68000, updated: '2025-05-25', shelfLifeDays: 90 },
  { id: 'ing-6', name: 'Chanh tươi', unit: 'kg', current: 6.5, minimum: 8, price: 42000, updated: today, shelfLifeDays: 5 },
  { id: 'ing-7', name: 'Gạo tẻ', unit: 'kg', current: 74, minimum: 40, price: 18500, updated: '2025-05-24', shelfLifeDays: 30 },
  { id: 'ing-strawberry', name: 'Dâu tươi', unit: 'g', current: 3200, minimum: 1800, price: 120, updated: today, shelfLifeDays: 2 },
  { id: 'ing-milk', name: 'Sữa tươi', unit: 'ml', current: 12000, minimum: 5000, price: 28, updated: today, shelfLifeDays: 7 },
  { id: 'ing-cup', name: 'Ly nhựa', unit: 'cái', current: 500, minimum: 100, price: 1000, updated: today, shelfLifeDays: 365 },
  { id: 'ing-ice', name: 'Đá viên', unit: 'kg', current: 18, minimum: 8, price: 10000, updated: today, shelfLifeDays: 1 },
];
const supplierByIngredient: Record<string, string> = {
  'ing-1': 'Thực phẩm Minh Phát',
  'ing-2': 'Nông sản An Tâm',
  'ing-3': 'Nông sản An Tâm',
  'ing-4': 'Nông sản An Tâm',
  'ing-5': 'Gia vị Hương Việt',
  'ing-6': 'Nông sản An Tâm',
  'ing-7': 'Gạo sạch Đại Phúc',
  'ing-strawberry': 'Vườn Dâu Đà Lạt',
  'ing-milk': 'Sữa tươi Nhà Bò',
  'ing-cup': 'Bao bì Phúc Khang',
  'ing-ice': 'Đá lạnh Tân Tiến',
};
const supplierContactByName: Record<string, string> = {
  'Thực phẩm Minh Phát': 'SMS nhà cung cấp',
  'Nông sản An Tâm': 'SMS nhà cung cấp',
  'Gia vị Hương Việt': 'SMS nhà cung cấp',
  'Gạo sạch Đại Phúc': 'SMS nhà cung cấp',
  'Vườn Dâu Đà Lạt': 'SMS nhà cung cấp',
  'Sữa tươi Nhà Bò': 'SMS nhà cung cấp',
  'Bao bì Phúc Khang': 'SMS nhà cung cấp',
  'Đá lạnh Tân Tiến': 'SMS nhà cung cấp',
};
function supplierForIngredient(item: Pick<Ingredient, 'id' | 'supplier'>) {
  return item.supplier ?? supplierByIngredient[item.id] ?? 'Nhà cung cấp chưa gán';
}
function priceHistoryForIngredient(item: Ingredient): PricePoint[] {
  if (item.priceHistory?.length) return item.priceHistory;
  const previousMultiplier = item.id === 'ing-strawberry' ? .88 : item.id === 'ing-1' ? .92 : .96;
  return [
    { date: '2 tháng trước', price: Math.round(item.price * (previousMultiplier - .04)) },
    { date: 'Tháng trước', price: Math.round(item.price * previousMultiplier) },
    { date: 'Hiện tại', price: item.price },
  ];
}
function priceChangePercent(item: Ingredient) {
  const history = priceHistoryForIngredient(item);
  const previous = history.at(-2)?.price ?? item.price;
  return previous ? Math.round(((item.price - previous) / previous) * 100) : 0;
}
const seedFixedCosts: FixedCost[] = [
  { id: 'cost-rent', name: 'Mặt bằng', amount: 12000000, frequency: 'tháng' },
  { id: 'cost-salary', name: 'Tiền lương', amount: 18000000, frequency: 'tháng' },
  { id: 'cost-utilities', name: 'Điện nước', amount: 3200000, frequency: 'tháng' },
];
const menuDishes: MenuDish[] = [
  {
    id: 'tra-dau',
    name: 'Trà dâu tươi kem phô mai',
    category: 'Đồ uống AI gợi ý',
    basePrice: 52000,
    accent: 'from-rose-100 to-pink-200',
    short: 'TD',
    variants: [
      { id: 'tra-dau-m', label: 'Size M', priceDelta: 0, bom: [{ ingredientId: 'ing-strawberry', quantity: 50, unit: 'g' }, { ingredientId: 'ing-milk', quantity: 100, unit: 'ml' }, { ingredientId: 'ing-cup', quantity: 1, unit: 'cái' }, { ingredientId: 'ing-ice', quantity: 0.12, unit: 'kg' }] },
      { id: 'tra-dau-l', label: 'Size L', priceDelta: 10000, bom: [{ ingredientId: 'ing-strawberry', quantity: 75, unit: 'g' }, { ingredientId: 'ing-milk', quantity: 140, unit: 'ml' }, { ingredientId: 'ing-cup', quantity: 1, unit: 'cái' }, { ingredientId: 'ing-ice', quantity: 0.16, unit: 'kg' }] },
    ],
    modifiers: [
      { id: 'cream-cheese', label: 'Kem phô mai', price: 12000, bom: [{ ingredientId: 'ing-milk', quantity: 35, unit: 'ml' }] },
      { id: 'extra-jelly', label: 'Thêm thạch', price: 8000, bom: [{ ingredientId: 'ing-cup', quantity: 0.05, unit: 'cái' }] },
    ],
    baseBom: [],
  },
  {
    id: 'pho-bo',
    name: 'Phở bò tái',
    category: 'Món nước',
    basePrice: 65000,
    accent: 'from-emerald-100 to-teal-200',
    short: 'PB',
    variants: [
      { id: 'pho-bo-m', label: 'Tiêu chuẩn', priceDelta: 0, bom: [{ ingredientId: 'ing-1', quantity: 0.12, unit: 'kg' }, { ingredientId: 'ing-2', quantity: 0.18, unit: 'kg' }, { ingredientId: 'ing-3', quantity: 0.08, unit: 'bó' }] },
      { id: 'pho-bo-l', label: 'Đặc biệt', priceDelta: 18000, bom: [{ ingredientId: 'ing-1', quantity: 0.18, unit: 'kg' }, { ingredientId: 'ing-2', quantity: 0.24, unit: 'kg' }, { ingredientId: 'ing-3', quantity: 0.1, unit: 'bó' }] },
    ],
    modifiers: [
      { id: 'extra-beef', label: 'Thêm thịt bò', price: 25000, bom: [{ ingredientId: 'ing-1', quantity: 0.08, unit: 'kg' }] },
      { id: 'extra-noodle', label: 'Thêm bánh phở', price: 10000, bom: [{ ingredientId: 'ing-2', quantity: 0.1, unit: 'kg' }] },
    ],
    baseBom: [],
  },
  {
    id: 'ca-phe',
    name: 'Cà phê sữa',
    category: 'Đồ uống',
    basePrice: 32000,
    accent: 'from-stone-200 to-amber-300',
    short: 'CF',
    variants: [
      { id: 'ca-phe-m', label: 'Size M', priceDelta: 0, bom: [{ ingredientId: 'ing-milk', quantity: 80, unit: 'ml' }, { ingredientId: 'ing-cup', quantity: 1, unit: 'cái' }, { ingredientId: 'ing-ice', quantity: 0.1, unit: 'kg' }] },
      { id: 'ca-phe-l', label: 'Size L', priceDelta: 8000, bom: [{ ingredientId: 'ing-milk', quantity: 120, unit: 'ml' }, { ingredientId: 'ing-cup', quantity: 1, unit: 'cái' }, { ingredientId: 'ing-ice', quantity: 0.14, unit: 'kg' }] },
    ],
    modifiers: [
      { id: 'extra-milk', label: 'Nhiều sữa', price: 5000, bom: [{ ingredientId: 'ing-milk', quantity: 40, unit: 'ml' }] },
    ],
    baseBom: [],
  },
  {
    id: 'bun-cha',
    name: 'Bún chả Hà Nội',
    category: 'Món no',
    basePrice: 68000,
    accent: 'from-yellow-100 to-lime-200',
    short: 'BC',
    variants: [
      { id: 'bun-cha-standard', label: 'Tiêu chuẩn', priceDelta: 0, bom: [{ ingredientId: 'ing-1', quantity: 0.14, unit: 'kg' }, { ingredientId: 'ing-3', quantity: 0.08, unit: 'bó' }] },
      { id: 'bun-cha-large', label: 'Phần lớn', priceDelta: 16000, bom: [{ ingredientId: 'ing-1', quantity: 0.2, unit: 'kg' }, { ingredientId: 'ing-3', quantity: 0.12, unit: 'bó' }] },
    ],
    modifiers: [
      { id: 'extra-herb', label: 'Thêm rau thơm', price: 6000, bom: [{ ingredientId: 'ing-3', quantity: 0.04, unit: 'bó' }] },
    ],
    baseBom: [],
  },
];
const seedProfile: Profile = {
  name: 'Minh Anh',
  restaurant: 'Bếp Nhà Mình',
  email: 'minhanh@bepnhaminh.vn',
  phone: '090 412 6850',
  notifications: true,
  weekStart: 'thứ hai',
};

  function readStorage<T>(key: string, fallback: T): T {
    // 1. Mở khóa vào thẳng Dashboard
    if (typeof fallback === 'boolean') return true as unknown as T;
    if (key === 'user' || key === 'profile' || key === 'auth' || key === 'resto_user' || fallback === null) {
      return (seedProfile || { name: 'Minh Anh', role: 'owner', restaurant: 'Resto.AI' }) as unknown as T;
    }

    // 2. Bảo vệ dữ liệu mảng tránh lỗi .some()
    if (Array.isArray(fallback)) return fallback;

    // 3. Đọc dữ liệu từ bộ nhớ
    try {
      const value = localStorage.getItem(key);
      if (value && value !== 'null' && value !== 'undefined') {
        return JSON.parse(value) as T;
      }
    } catch {}

    return fallback;
  }
function notificationDate(value: string) {
  return new Intl.DateTimeFormat('vi-VN', { hour: '2-digit', minute: '2-digit' }).format(new Date(value));
}
function isNotificationSupported() {
  return typeof window !== 'undefined' && 'Notification' in window;
}
async function showSystemNotification(notification: AuraNotification) {
  if (!isNotificationSupported() || Notification.permission !== 'granted') return;
  const options = {
    body: notification.body,
    icon: '/static/app-icon.svg',
    badge: '/static/app-icon.svg',
    tag: `resto-ai-${notification.kind}`,
    data: { id: notification.id, kind: notification.kind, view: notification.view },
  };
  try {
    const registration = await navigator.serviceWorker?.getRegistration();
    if (registration) {
      await registration.showNotification(notification.title, options);
    } else {
      new Notification(notification.title, options);
    }
  } catch {
    // Browser notification APIs can reject when permission changes mid-session.
  }
}
function money(value: number) {
  return new Intl.NumberFormat('vi-VN', { style: 'currency', currency: 'VND', maximumFractionDigits: 0 }).format(value);
}
function compactMoney(value: number) {
  if (value >= 1000000) return `${(value / 1000000).toFixed(1).replace('.0', '')} tr`;
  return `${Math.round(value / 1000)}k`;
}
function dateLabel(value: string) {
  return new Intl.DateTimeFormat('vi-VN', { day: '2-digit', month: '2-digit', year: 'numeric' }).format(new Date(`${value}T12:00:00`));
}
function uid(prefix: string) {
  return `${prefix}-${Date.now()}-${Math.random().toString(36).slice(2, 7)}`;
}
function dateInput(value: Date) {
  return value.toISOString().slice(0, 10);
}
function daySeed(value: string) {
  const date = new Date(`${value}T12:00:00`);
  return Math.abs(Math.floor(date.getTime() / 86400000));
}
function weatherFor(value: string): SalesDay['weather'] {
  const seed = daySeed(value);
  return seed % 7 === 0 || seed % 11 === 0 ? 'mưa' : seed % 3 === 0 ? 'nhiều mây' : 'nắng';
}
function createSalesHistory() {
  const result: SalesDay[] = [];
  const dishBase = { pho: 78, rice: 54, coffee: 62, milkTea: 39 };
  for (let offset = 60; offset >= 1; offset -= 1) {
    const date = new Date();
    date.setDate(date.getDate() - offset);
    const dateValue = dateInput(date);
    const seed = daySeed(dateValue);
    const weekday = date.getDay();
    const weekendFactor = weekday === 0 || weekday === 6 ? 1.18 : weekday === 1 ? .86 : 1;
    const rainFactor = weatherFor(dateValue) === 'mưa' ? .91 : 1;
    const wave = 0.91 + ((seed * 17) % 19) / 100;
    result.push({
      date: dateValue,
      weather: weatherFor(dateValue),
      dishes: {
        pho: Math.round(dishBase.pho * weekendFactor * rainFactor * wave),
        rice: Math.round(dishBase.rice * weekendFactor * wave),
        coffee: Math.round(dishBase.coffee * (weekday === 1 ? .92 : 1) * wave),
        milkTea: Math.round(dishBase.milkTea * (weekday === 0 || weekday === 6 ? 1.08 : 1) * rainFactor * wave),
      },
      waste: Math.round(3.1 + ((seed * 13) % 32) / 10),
    });
  }
  return result;
}
function averageByWeekday(history: SalesDay[], dateValue: string, key: string) {
  const weekday = new Date(`${dateValue}T12:00:00`).getDay();
  const matching = history.filter((item) => new Date(`${item.date}T12:00:00`).getDay() === weekday);
  if (!matching.length) return 50;
  return matching.reduce((sum, item) => sum + (item.dishes[key] ?? 0), 0) / matching.length;
}
function createForecast(targetDate: string, history: SalesDay[], runId = uid('forecast')): ForecastRun {
  const weather = weatherFor(targetDate);
  const seed = daySeed(targetDate);
  const rainAdjustment = weather === 'mưa' ? { pho: 1.11, rice: 1.05, coffee: .94, milkTea: .78 } : weather === 'nhiều mây' ? { pho: 1.04, rice: 1.01, coffee: .98, milkTea: .93 } : { pho: 1, rice: 1, coffee: 1.05, milkTea: 1.06 };
  const variance = 0.97 + (seed % 8) / 100;
  const servings = {
    pho: Math.round(averageByWeekday(history, targetDate, 'pho') * rainAdjustment.pho * variance),
    rice: Math.round(averageByWeekday(history, targetDate, 'rice') * rainAdjustment.rice * variance),
    coffee: Math.round(averageByWeekday(history, targetDate, 'coffee') * rainAdjustment.coffee * variance),
    milkTea: Math.round(averageByWeekday(history, targetDate, 'milkTea') * rainAdjustment.milkTea * variance),
  };
  const total = Object.values(servings).reduce((sum, value) => sum + value, 0);
  const temperature = weather === 'mưa' ? 25 : weather === 'nhiều mây' ? 28 : 32;
  const recommendations: ForecastRecommendation[] = [
    { id: 'banh-pho', name: 'Bánh phở', unit: 'kg', quantity: Number((servings.pho * .09 + .5).toFixed(1)), price: 32000, confirmed: false },
    { id: 'thit-bo', name: 'Thịt bò', unit: 'kg', quantity: Number((servings.pho * .055 + .3).toFixed(1)), price: 210000, confirmed: false },
    { id: 'gao', name: 'Gạo', unit: 'kg', quantity: Number((servings.rice * .075 + .5).toFixed(1)), price: 18500, confirmed: false },
    { id: 'ca-phe', name: 'Cà phê', unit: 'kg', quantity: Number((servings.coffee * .018 + .2).toFixed(1)), price: 185000, confirmed: false },
    { id: 'sua', name: 'Sữa', unit: 'lít', quantity: Number((servings.milkTea * .13 + servings.coffee * .04 + .5).toFixed(1)), price: 33000, confirmed: false },
    { id: 'da', name: 'Đá', unit: 'kg', quantity: Number((total * (weather === 'mưa' ? .035 : .055) + .8).toFixed(1)), price: 4000, confirmed: false },
  ];
  return {
    id: runId,
    createdAt: new Date().toISOString(),
    targetDate,
    weather,
    temperature,
    confidence: 86 + (seed % 8),
    note: weather === 'mưa'
      ? 'Mưa nhẹ vào buổi chiều: ưu tiên món nóng, giảm chuẩn bị đồ uống lạnh.'
      : weather === 'nhiều mây'
        ? 'Trời dịu, giữ nhịp chuẩn bị cân bằng và theo dõi ca trưa.'
        : 'Ngày khô ráo: chuẩn bị đủ đồ uống và tăng nhẹ lượng phục vụ buổi sáng.',
    dishes: [
      { id: 'pho', name: 'Phở', servings: servings.pho, previous: Math.round(averageByWeekday(history, targetDate, 'pho')), ingredients: `${(servings.pho * .09).toFixed(1)} kg bánh phở · ${(servings.pho * .055).toFixed(1)} kg thịt bò` },
      { id: 'rice', name: 'Cơm trưa', servings: servings.rice, previous: Math.round(averageByWeekday(history, targetDate, 'rice')), ingredients: `${(servings.rice * .075).toFixed(1)} kg gạo · ${(servings.rice * .018).toFixed(1)} kg rau` },
      { id: 'coffee', name: 'Cà phê', servings: servings.coffee, previous: Math.round(averageByWeekday(history, targetDate, 'coffee')), ingredients: `${(servings.coffee * .018).toFixed(1)} kg cà phê · ${(servings.coffee * .04).toFixed(1)} lít sữa` },
      { id: 'milkTea', name: 'Trà sữa', servings: servings.milkTea, previous: Math.round(averageByWeekday(history, targetDate, 'milkTea')), ingredients: `${(servings.milkTea * .13).toFixed(1)} lít sữa · ${Math.max(1, Math.round(servings.milkTea * .72))} kg đá` },
    ],
    recommendations,
  };
}

type InstallPromptEvent = Event & {
  prompt: () => Promise<void>;
  userChoice: Promise<{ outcome: 'accepted' | 'dismissed'; platform: string }>;
};

function isStandaloneMode() {
  return window.matchMedia('(display-mode: standalone)').matches
    || (navigator as Navigator & { standalone?: boolean }).standalone === true;
}

function isPhoneDevice() {
  return /Android|iPhone|iPad|iPod|Windows Phone/i.test(navigator.userAgent)
    || window.matchMedia('(max-width: 768px)').matches;
}

type InsightSignal = {
  greeting: string;
  title: string;
  body: string;
  actionLabel: string;
  actionKind: 'combo' | 'restock' | 'audit';
  weatherLabel: string;
  severity: 'calm' | 'watch' | 'urgent';
  burnRate: number;
};

function buildInsight({ forecast, ingredients, transactions }: { forecast: ForecastRun; ingredients: Ingredient[]; transactions: Transaction[] }): InsightSignal {
  const hour = new Date().getHours();
  const revenueToday = transactions.filter((item) => item.type === 'thu' && item.date === today).reduce((sum, item) => sum + item.amount, 0);
  const servings = Math.max(1, forecast.dishes.reduce((sum, item) => sum + item.servings, 0));
  const burnRate = Math.round(revenueToday / servings);
  const shortShelf = ingredients.find((item) => (item.shelfLifeDays ?? 7) <= 2 && item.current > item.minimum);
  const shortage = ingredients.find((item) => item.current < item.minimum);
  const weatherLabel = `${forecast.weather === 'nắng' ? 'Nắng' : forecast.weather === 'mưa' ? 'Mưa' : 'Nhiều mây'} ${forecast.temperature}°C`;
  if (hour >= 21) {
    return {
      greeting: 'TỔNG KẾT CA HÔM NAY',
      title: 'Quán đã hoàn thành một ngày tốt.',
      body: `Doanh thu đạt ${money(revenueToday)}, tốc độ bán trung bình ${money(burnRate)}/suất. ${shortShelf ? `${shortShelf.name} còn dư trên ngưỡng an toàn, nên ưu tiên kiểm tra trước ca sáng.` : 'Tồn kho đang trong vùng kiểm soát.'}`,
      actionLabel: shortShelf ? 'Tạo combo xả hàng' : 'Mở kiểm kho cuối ngày',
      actionKind: shortShelf ? 'combo' : 'audit',
      weatherLabel,
      severity: shortShelf ? 'watch' : 'calm',
      burnRate,
    };
  }
  if (shortShelf) {
    return {
      greeting: 'INSIGHT ENGINE · HÀNH ĐỘNG SỚM',
      title: `Nên ưu tiên ${shortShelf.name} trong ca hôm nay.`,
      body: `${weatherLabel}. ${shortShelf.name} có hạn dùng ngắn và đang cao hơn mức tối thiểu. Hãy tạo một combo bán nhanh để giảm rủi ro hỏng nguyên liệu.`,
      actionLabel: 'Tạo combo xả hàng ngay',
      actionKind: 'combo',
      weatherLabel,
      severity: 'urgent',
      burnRate,
    };
  }
  return {
    greeting: hour < 12 ? 'CHÀO BUỔI SÁNG · INSIGHT ENGINE' : 'AI COMPANION · CẬP NHẬT MỚI',
    title: hour < 12 ? 'Chuẩn bị đủ đá cho nhóm đồ uống trái cây.' : 'Ca bán hàng đang đi đúng nhịp.',
    body: `${weatherLabel}. Dựa trên tốc độ bán ${money(burnRate)}/suất và dự báo ${forecast.confidence}% tin cậy, ${shortage ? `hãy bổ sung ${shortage.name} trước giờ cao điểm.` : 'tồn kho hiện tại đủ cho kế hoạch ngày mai.'}`,
    actionLabel: shortage ? 'Mở danh sách đi chợ' : 'Kiểm tra tốc độ bán',
    actionKind: shortage ? 'restock' : 'audit',
    weatherLabel,
    severity: shortage ? 'watch' : 'calm',
    burnRate,
  };
}

function App() {
  const [authStatus, setAuthStatus] = useState<AuthStatus>('signed-in');
  const [authUser, setAuthUser] = useState<AuthUser | null>(() => ({
    id: 'mock-admin',
    tenantId: 'AURA-01',
    username: 'admin',
    displayName: 'Chủ quán',
    role: 'manager',
  }));
  const [authError, setAuthError] = useState('');
  const [showSplash, setShowSplash] = useState(true);
  const [view, setView] = useState<View>(() => {
    const requested = normalizeWorkspace(new URLSearchParams(window.location.search).get('view'));
    return requested;
  });
  const [transactions, setTransactions] = useState<Transaction[]>(() => readStorage('so-quan-transactions', seedTransactions));
  const [orders, setOrders] = useState<Order[]>(() => readStorage('resto-ai-orders', seedOrders));
  const [ingredients, setIngredients] = useState<Ingredient[]>(() => {
    const stored = readStorage<Ingredient[]>('so-quan-ingredients', seedIngredients);
    const missing = seedIngredients.filter((seed) => !stored.some((item) => item.id === seed.id));
    return [...stored, ...missing];
  });
  const [profile, setProfile] = useState<Profile>(() => readStorage('so-quan-profile', seedProfile));
  const [fixedCosts, setFixedCosts] = useState<FixedCost[]>(() => readStorage('so-quan-fixed-costs', seedFixedCosts));
  const [role, setRole] = useState<Role>('manager');
  const [roleTarget, setRoleTarget] = useState<View | null>(null);
  const [rolePin, setRolePin] = useState('');
  const [roleError, setRoleError] = useState('');
  const [pendingDeleteId, setPendingDeleteId] = useState<string | null>(null);
  const [profileMenuOpen, setProfileMenuOpen] = useState(false);
  const [quickPinOpen, setQuickPinOpen] = useState(false);
  const [adminSettingsOpen, setAdminSettingsOpen] = useState(false);
  const [salesHistory] = useState<SalesDay[]>(() => readStorage('so-quan-sales-history', createSalesHistory()));
  const [forecastRuns, setForecastRuns] = useState<ForecastRun[]>(() => {
    const history = readStorage('so-quan-sales-history', createSalesHistory());
    const stored = readStorage<ForecastRun[]>('so-quan-forecast-runs', []);
    const tomorrow = new Date();
    tomorrow.setDate(tomorrow.getDate() + 1);
    const targetDate = dateInput(tomorrow);
    if (stored.length && stored[0].targetDate === targetDate) return stored;
    return [createForecast(targetDate, history), ...stored].slice(0, 8);
  });
  const [modal, setModal] = useState<Modal>(null);
  const [editingTransaction, setEditingTransaction] = useState<Transaction | null>(null);
  const [adjusting, setAdjusting] = useState<Ingredient | null>(null);
  const [ingredientDetail, setIngredientDetail] = useState<Ingredient | null>(null);
  const [toast, setToast] = useState('');
  const [toastTone, setToastTone] = useState<ToastTone>('success');
  const [isOnline, setIsOnline] = useState(() => typeof navigator === 'undefined' ? true : navigator.onLine);
  const [mobileNav, setMobileNav] = useState(false);
  const [installPrompt, setInstallPrompt] = useState<InstallPromptEvent | null>(null);
  const [showInstallPrompt, setShowInstallPrompt] = useState(false);
  const [mlForecast, setMlForecast] = useState<MlForecast | null>(null);
  const [mlForecastLoading, setMlForecastLoading] = useState(false);
  const [mlForecastError, setMlForecastError] = useState('');
  const [notifications, setNotifications] = useState<AuraNotification[]>(() => readStorage(notificationStorageKey, []));
  const [notificationCenterOpen, setNotificationCenterOpen] = useState(false);
  const [showPermissionPrompt, setShowPermissionPrompt] = useState(false);
  const [copilotOpen, setCopilotOpen] = useState(false);
  const [successBurstKey, setSuccessBurstKey] = useState(0);
  const notificationsRef = useRef(notifications);
  // Prevent the initial ML request from restarting forever when the API is offline or fails.
  const mlForecastAutoStartedRef = useRef(false);
  const notify = (message: string, tone: ToastTone = 'success') => {
    setToastTone(tone);
    setToast(message);
  };
  useEffect(() => {
    if (!new URLSearchParams(window.location.search).get('view')) setView('overview');
    setAuthStatus('signed-in');
  }, []);
  useEffect(() => {
    const handleOnline = () => setIsOnline(true);
    const handleOffline = () => setIsOnline(false);
    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);
    return () => {
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
    };
  }, []);
  const recordAuraNotification = useCallback((input: AuraNotificationInput) => {
    const item: AuraNotification = {
      id: input.id ?? uid('notification'),
      kind: input.kind,
      title: input.title,
      body: input.body,
      view: input.view,
      createdAt: new Date().toISOString(),
      read: false,
    };
    if (notificationsRef.current.some((existing) => existing.id === item.id)) return null;
    notificationsRef.current = [item, ...notificationsRef.current].slice(0, 60);
    setNotifications(notificationsRef.current);
    return item;
  }, []);
  const pushAuraNotification = useCallback(async (input: AuraNotificationInput) => {
    const item = recordAuraNotification(input);
    if (item) await showSystemNotification(item);
  }, [recordAuraNotification]);

  useEffect(() => localStorage.setItem('so-quan-transactions', JSON.stringify(transactions)), [transactions]);
  useEffect(() => localStorage.setItem('resto-ai-orders', JSON.stringify(orders)), [orders]);
  useEffect(() => localStorage.setItem('so-quan-ingredients', JSON.stringify(ingredients)), [ingredients]);
  useEffect(() => localStorage.setItem('so-quan-profile', JSON.stringify(profile)), [profile]);
  useEffect(() => localStorage.setItem('so-quan-fixed-costs', JSON.stringify(fixedCosts)), [fixedCosts]);
  useEffect(() => localStorage.setItem('so-quan-sales-history', JSON.stringify(salesHistory)), [salesHistory]);
  useEffect(() => localStorage.setItem('so-quan-forecast-runs', JSON.stringify(forecastRuns)), [forecastRuns]);
  useEffect(() => {
    notificationsRef.current = notifications;
    localStorage.setItem(notificationStorageKey, JSON.stringify(notifications));
  }, [notifications]);
  useEffect(() => {
    const reducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
    const timer = window.setTimeout(() => setShowSplash(false), reducedMotion ? 450 : 3000);
    return () => window.clearTimeout(timer);
  }, []);
  useEffect(() => {
    const root = document.querySelector('.app-grain');
    if (!root) return;
    const pressedButtons = new Set<HTMLElement>();
    const handlePointerDown = (event: Event) => {
      const pointerEvent = event as PointerEvent;
      const target = event.target instanceof Element ? event.target.closest<HTMLElement>('button, [role="button"]') : null;
      if (!target || target.getAttribute('aria-disabled') === 'true' || target instanceof HTMLButtonElement && target.disabled) return;
      target.classList.add('is-pressed');
      pressedButtons.add(target);
      const bounds = target.getBoundingClientRect();
      const ripple = document.createElement('span');
      ripple.className = 'motion-ripple';
      ripple.style.left = `${pointerEvent.clientX - bounds.left}px`;
      ripple.style.top = `${pointerEvent.clientY - bounds.top}px`;
      ripple.addEventListener('animationend', () => ripple.remove(), { once: true });
      target.append(ripple);
    };
    const releaseButton = (event: Event) => {
      const target = event.target instanceof Element ? event.target.closest<HTMLElement>('button, [role="button"]') : null;
      if (target) {
        target.classList.remove('is-pressed');
        pressedButtons.delete(target);
      }
      if (event.type === 'pointerup' || event.type === 'pointercancel' || event.type === 'pointerleave') {
        pressedButtons.forEach((button) => button.classList.remove('is-pressed'));
        pressedButtons.clear();
      }
    };
    root.addEventListener('pointerdown', handlePointerDown);
    root.addEventListener('pointerup', releaseButton);
    root.addEventListener('pointercancel', releaseButton);
    root.addEventListener('pointerleave', releaseButton);
    return () => {
      root.removeEventListener('pointerdown', handlePointerDown);
      root.removeEventListener('pointerup', releaseButton);
      root.removeEventListener('pointercancel', releaseButton);
      root.removeEventListener('pointerleave', releaseButton);
      pressedButtons.forEach((button) => button.classList.remove('is-pressed'));
    };
  }, []);
  useEffect(() => {
    if (!isPhoneDevice() || isStandaloneMode() || localStorage.getItem('so-quan-pwa-dismissed') === '1') return;

    const showPrompt = () => setShowInstallPrompt(true);
    const handleBeforeInstallPrompt = (event: Event) => {
      event.preventDefault();
      setInstallPrompt(event as InstallPromptEvent);
      showPrompt();
    };
    const handleAppInstalled = () => {
      setInstallPrompt(null);
      setShowInstallPrompt(false);
    };

    window.addEventListener('beforeinstallprompt', handleBeforeInstallPrompt);
    window.addEventListener('appinstalled', handleAppInstalled);
    const timer = window.setTimeout(showPrompt, 900);

    return () => {
      window.clearTimeout(timer);
      window.removeEventListener('beforeinstallprompt', handleBeforeInstallPrompt);
      window.removeEventListener('appinstalled', handleAppInstalled);
    };
  }, []);
  useEffect(() => {
    if (!toast) return;
    const timer = window.setTimeout(() => setToast(''), 3000);
    return () => window.clearTimeout(timer);
  }, [toast]);

  const changeView = (next: View) => {
    if (next !== 'pos' && role !== 'manager') {
      setRoleTarget(next);
      setRolePin('');
      setRoleError('');
      return;
    }
    setView(next);
    setMobileNav(false);
  };
  const unlockManager = async () => {
    setRoleError('');
    try {
      const response = await fetch('/api/auth/pin/switch', {
        method: 'POST',
        credentials: 'include',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ tenantId: authUser?.tenantId ?? 'AURA-01', pin: rolePin }),
      });
      const payload = await response.json() as { user?: AuthUser; error?: string };
      if (!response.ok || !payload.user) throw new Error(payload.error ?? 'Mã PIN không đúng.');
      setAuthUser(payload.user);
      setRole(payload.user.role);
      setRoleTarget(null);
      setQuickPinOpen(false);
      setRolePin('');
      setRoleError('');
      notify(payload.user.role === 'manager' ? 'Đã chuyển sang Manager Mode' : 'Đã chuyển sang Staff Mode');
      if (pendingDeleteId && payload.user.role === 'manager') {
        const id = pendingDeleteId;
        setPendingDeleteId(null);
        setView('ledger');
        window.setTimeout(() => deleteTransactionAsManager(id), 0);
      } else if (roleTarget) {
        setView(roleTarget);
        setMobileNav(false);
      }
    } catch (error) {
      setRoleError(error instanceof Error ? error.message : 'Mã PIN không đúng.');
    }
  };
  const switchToStaff = () => {
    setQuickPinOpen(true);
    setRolePin('');
    setRoleError('');
  };
  const handleLogin = async (payload: { tenantId: string; username: string; password: string; rememberMe: boolean }) => {
    setAuthError('');
    const response = await fetch('/api/auth/login', {
      method: 'POST',
      credentials: 'include',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload),
    });
    const result = await response.json() as { user?: AuthUser; error?: string };
    if (!response.ok || !result.user) throw new Error(result.error ?? 'Không thể đăng nhập.');
    setAuthUser(result.user);
    setRole(result.user.role);
    setView('pos');
    setAuthStatus('signed-in');
    if (payload.rememberMe) {
      localStorage.setItem(authRememberKey, JSON.stringify({ tenantId: payload.tenantId, username: payload.username }));
    } else {
      localStorage.removeItem(authRememberKey);
    }
    setShowSplash(false);
  };
  const handleLogout = async () => {
    await fetch('/api/auth/logout', { method: 'POST', credentials: 'include' }).catch(() => undefined);
    setAuthUser(null);
    setRole('staff');
    setView('pos');
    setProfileMenuOpen(false);
    setQuickPinOpen(false);
    setRoleTarget(null);
    setPendingDeleteId(null);
    localStorage.removeItem(authRememberKey);
    setAuthStatus('signed-out');
    notify('Đã đăng xuất khỏi phiên làm việc');
  };
  useEffect(() => {
    if (!isNotificationSupported() || Notification.permission !== 'default' || localStorage.getItem(notificationPromptKey) === '1') return;
    const timer = window.setTimeout(() => setShowPermissionPrompt(true), 3300);
    return () => window.clearTimeout(timer);
  }, []);
  useEffect(() => {
    if (!('serviceWorker' in navigator)) return;
    const handleServiceWorkerMessage = (event: MessageEvent) => {
      const message = event.data as { type?: string; notification?: Omit<AuraNotificationInput, 'view'> & { view?: string }; view?: string } | undefined;
      const notification = message?.notification
        ? { ...message.notification, view: normalizeWorkspace(message.notification.view) }
        : null;
      if (message?.type === 'AURABITE_NOTIFICATION_RECEIVED' && notification) {
        recordAuraNotification(notification);
      }
      if (message?.type === 'AURABITE_NOTIFICATION_OPENED' && notification) {
        recordAuraNotification(notification);
      }
      if (message?.type === 'AURABITE_NAVIGATE' || message?.type === 'AURABITE_NOTIFICATION_OPENED') {
        changeView(normalizeWorkspace(message.view ?? message.notification?.view));
        setNotificationCenterOpen(false);
      }
    };
    navigator.serviceWorker.addEventListener('message', handleServiceWorkerMessage);
    return () => navigator.serviceWorker.removeEventListener('message', handleServiceWorkerMessage);
  }, [recordAuraNotification]);
  useEffect(() => {
    let timeoutId = 0;
    const scheduleNextDailyReminder = () => {
      const now = new Date();
      const target = new Date(now);
      target.setHours(6, 0, 0, 0);
      if (target <= now) target.setDate(target.getDate() + 1);
      timeoutId = window.setTimeout(() => {
        const dateKey = dateInput(target);
        void pushAuraNotification({
          id: `shopping-${dateKey}`,
          kind: 'shopping',
          title: '☀️ Nhắc việc đi chợ',
          body: 'Resto.AI đã tính toán xong danh sách đi chợ hôm nay. Bấm để xem ngay để không lỡ việc!',
           view: 'ledger',
        });
        scheduleNextDailyReminder();
      }, Math.max(1000, target.getTime() - now.getTime()));
    };
    scheduleNextDailyReminder();
    return () => window.clearTimeout(timeoutId);
  }, [pushAuraNotification]);
  const refreshForecast = () => {
    const tomorrow = new Date();
    tomorrow.setDate(tomorrow.getDate() + 1);
    const next = createForecast(dateInput(tomorrow), salesHistory);
    setForecastRuns((current) => [next, ...current].slice(0, 8));
    notify('Resto.AI đã cập nhật dự báo cho ngày mai');
  };
  const runMlForecast = async (request: PredictRequest, announce = true) => {
    setMlForecastLoading(true);
    setMlForecastError('');
    try {
      const legacy = request as unknown as Record<string, unknown>;
      const normalizedRequest: PredictRequest = {
        nhiet_do: Number(request.nhiet_do ?? 32),
        luong_mua: Number(request.luong_mua ?? legacy.thoi_tiet ?? 0),
        ngay_trong_tuan: Number(request.ngay_trong_tuan ?? legacy.thu_trong_tuan ?? 0),
        la_ngay_le: Number(request.la_ngay_le ?? 0) as PredictRequest['la_ngay_le'],
        su_kien_dac_biet: Number(request.su_kien_dac_biet ?? legacy.su_kien_dia_phuong ?? 0) as PredictRequest['su_kien_dac_biet'],
        inventory: request.inventory ?? ingredients.map((item) => ({
          name: item.name,
          unit: item.unit,
          quantity: item.current,
          shelf_life_days: item.shelfLifeDays ?? 7,
        })),
      };
      const result = await predictIngredientDemand(normalizedRequest);
      setMlForecast(result);
      setSuccessBurstKey((key) => key + 1);
      const anomaly = result.shopping_list.find((item) => item.forecast_need > 0 && item.inventory < item.forecast_need * .9);
      if (anomaly) {
        const anomalyKey = `anomaly-${dateInput(new Date())}-${anomaly.name}`;
        if (localStorage.getItem(anomalyKey) !== '1') {
          localStorage.setItem(anomalyKey, '1');
          void pushAuraNotification({
            id: anomalyKey,
            kind: 'anomaly',
            title: '🚨 CẢNH BÁO: Hao hụt bất thường',
            body: `Tồn kho ${anomaly.name} hao hụt bất thường so với định mức bán ra. Hãy kiểm tra ngay!`,
             view: 'forecast',
          });
        }
      }
      const flashSignal = result.operational_alerts.find((advice) => advice.type === 'weather' || advice.type === 'peak_hour' || advice.type === 'surge');
      if (flashSignal) {
        const flashKey = `flash-${dateInput(new Date())}-${flashSignal.type}`;
        if (localStorage.getItem(flashKey) !== '1') {
          localStorage.setItem(flashKey, '1');
          void pushAuraNotification({
            id: flashKey,
            kind: 'flash',
            title: '🌧️ Flash Action',
            body: 'Dự báo sắp có mưa lớn, nhấn vào đây để xem AI gợi ý xả hàng chống ế!',
             view: 'forecast',
          });
        }
      }
       if (announce) notify(`Resto.AI đã chạy ${result.model} trên ${result.training_days} ngày dữ liệu`);
    } catch {
      const message = navigator.onLine
        ? 'Resto.AI chưa nhận diện được dữ liệu, chủ quán vui lòng nhập lại nhé!'
        : 'Đang offline: giao diện và dữ liệu đã lưu vẫn dùng được; dự báo AI mới sẽ chạy khi có mạng.';
      setMlForecastError(message);
      if (announce) notify(message, 'warning');
    } finally {
      setMlForecastLoading(false);
    }
  };
  useEffect(() => {
    if (authStatus !== 'signed-in' || mlForecast || mlForecastLoading || mlForecastAutoStartedRef.current) return;
    mlForecastAutoStartedRef.current = true;
    const tomorrow = new Date();
    tomorrow.setDate(tomorrow.getDate() + 1);
    const targetDate = dateInput(tomorrow);
    const weather = weatherFor(targetDate);
    void runMlForecast({
      nhiet_do: weather === 'mưa' ? 25 : weather === 'nhiều mây' ? 28 : 32,
      luong_mua: weather === 'mưa' ? 35 : weather === 'nhiều mây' ? 12 : 0,
      ngay_trong_tuan: weekdayCode(targetDate),
      la_ngay_le: 0,
      su_kien_dac_biet: 0,
      inventory: ingredients.map((item) => ({
        name: item.name,
        unit: item.unit,
        quantity: item.current,
        shelf_life_days: item.shelfLifeDays ?? 7,
      })),
    }, false);
  }, [authStatus, ingredients, mlForecast, mlForecastLoading, pushAuraNotification]);
  const adjustForecastRecommendation = (id: string, quantity: number) => {
    setForecastRuns((current) => current.map((run, index) => index === 0
      ? { ...run, recommendations: run.recommendations.map((item) => item.id === id ? { ...item, quantity: Math.max(.1, Number(quantity.toFixed(1))) } : item) }
      : run));
  };
  const confirmForecastRecommendation = (recommendation: ForecastRecommendation) => {
    const aliases: Record<string, string[]> = {
      'Bánh phở': ['bánh phở tươi'],
      'Thịt bò': ['thịt bò thăn'],
      Gạo: ['gạo tẻ'],
      'Cà phê': ['cà phê'],
      Sữa: ['sữa'],
      Đá: ['đá'],
    };
    const match = ingredients.find((item) => (aliases[recommendation.name] ?? [recommendation.name]).some((alias) => item.name.toLowerCase().includes(alias)));
    if (match) {
      setIngredients((current) => current.map((item) => item.id === match.id ? { ...item, current: Number((item.current + recommendation.quantity).toFixed(1)), updated: today } : item));
    } else {
      setIngredients((current) => [...current, {
        id: uid('ing'),
        name: recommendation.name,
        unit: recommendation.unit,
        current: recommendation.quantity,
        minimum: recommendation.quantity * .65,
        price: recommendation.price,
        updated: today,
      }]);
    }
    setForecastRuns((current) => current.map((run, index) => index === 0
      ? { ...run, recommendations: run.recommendations.map((item) => item.id === recommendation.id ? { ...item, confirmed: true } : item) }
      : run));
    notify(`Resto.AI đã xác nhận nhập ${recommendation.quantity} ${recommendation.unit} ${recommendation.name.toLowerCase()}`);
  };
  const openAddTransaction = () => {
    setEditingTransaction(null);
    setModal('transaction');
  };
  const openEditTransaction = (item: Transaction) => {
    setEditingTransaction(item);
    setModal('transaction');
  };
  const saveTransaction = (data: Omit<Transaction, 'id'>) => {
    setTransactions((current) => editingTransaction
      ? current.map((item) => item.id === editingTransaction.id ? { ...data, id: item.id } : item)
      : [{ ...data, id: uid('tx') }, ...current]);
    setModal(null);
    notify(editingTransaction ? 'Resto.AI đã cập nhật giao dịch' : 'Resto.AI đã thêm giao dịch mới');
  };
  const deleteTransactionAsManager = (id: string) => {
    if (role !== 'manager') return;
    if (!window.confirm('Bạn có chắc muốn xóa giao dịch này không?')) return;
    setTransactions((current) => current.filter((item) => item.id !== id));
    notify('Resto.AI đã xóa giao dịch');
  };
  const deleteTransaction = (id: string) => {
    if (role !== 'manager') {
      setPendingDeleteId(id);
      setRoleTarget('ledger');
      setRolePin('');
      setRoleError('Nhập PIN quản lý để xác nhận thao tác nhạy cảm.');
      return;
    }
    deleteTransactionAsManager(id);
  };
  const saveIngredient = (data: Omit<Ingredient, 'id' | 'updated'>) => {
    setIngredients((current) => [{ ...data, id: uid('ing'), updated: today }, ...current]);
    setModal(null);
    notify('Resto.AI đã thêm nguyên liệu vào kho');
  };
  const adjustIngredient = (id: string, amount: number) => {
    setIngredients((current) => current.map((item) => item.id === id
      ? { ...item, current: Math.max(0, amount), updated: today }
      : item));
    setModal(null);
    setAdjusting(null);
    notify('Resto.AI đã cập nhật tồn kho');
  };
  const toggleLowStock = (id: string) => {
    setIngredients((current) => current.map((item) => item.id === id
      ? { ...item, minimum: item.current > item.minimum ? item.current + 1 : Math.max(0, item.current - 1) }
      : item));
    notify('Resto.AI đã cập nhật ngưỡng cảnh báo');
  };
  const saveFixedCost = (data: Omit<FixedCost, 'id'>) => {
    setFixedCosts((current) => [{ ...data, id: uid('cost') }, ...current]);
    setModal(null);
    notify(`Đã thêm chi phí cố định: ${data.name}`);
  };
  const checkoutOrder = (lines: CartLine[], total: number) => {
    const usage = new Map<string, number>();
    lines.forEach((line) => line.bom.forEach((item) => usage.set(item.ingredientId, (usage.get(item.ingredientId) ?? 0) + item.quantity * line.quantity)));
    setIngredients((current) => current.map((item) => usage.has(item.id)
      ? { ...item, current: Math.max(0, Number((item.current - (usage.get(item.id) ?? 0)).toFixed(2))), updated: today }
      : item));
    setTransactions((current) => [{
      id: uid('tx'),
      type: 'thu',
      category: 'Bán hàng',
      note: `POS · ${lines.map((line) => line.name).slice(0, 2).join(' + ')}`,
      amount: total,
      date: today,
      hour: new Date().getHours(),
    }, ...current]);
    setSuccessBurstKey((key) => key + 1);
    notify(`Đã thanh toán ${money(total)} · BOM đã trừ tồn kho`);
  };
  const dismissInstallPrompt = () => {
    localStorage.setItem('so-quan-pwa-dismissed', '1');
    setShowInstallPrompt(false);
  };
  const installPwa = async () => {
    if (!installPrompt) {
      dismissInstallPrompt();
      return;
    }
    await installPrompt.prompt();
    const { outcome } = await installPrompt.userChoice;
    setInstallPrompt(null);
    if (outcome === 'accepted') {
      setShowInstallPrompt(false);
    } else {
      dismissInstallPrompt();
    }
  };
  const requestNotifications = async () => {
    localStorage.setItem(notificationPromptKey, '1');
    setShowPermissionPrompt(false);
    if (!isNotificationSupported()) {
      notify('Trình duyệt này chưa hỗ trợ thông báo đẩy.', 'warning');
      return;
    }
    const permission = await Notification.requestPermission();
    if (permission === 'granted') notify('Resto.AI đã bật thông báo chủ động');
    else notify('Bạn có thể bật lại thông báo trong cài đặt trình duyệt.', 'warning');
  };
  const dismissNotificationPrompt = () => {
    localStorage.setItem(notificationPromptKey, '1');
    setShowPermissionPrompt(false);
  };
  const unreadNotificationCount = notifications.filter((item) => !item.read).length;
  const openNotification = (item: AuraNotification) => {
    setNotifications((current) => current.map((notification) => notification.id === item.id ? { ...notification, read: true } : notification));
    changeView(item.view);
    setNotificationCenterOpen(false);
  };
  const markAllNotificationsRead = () => {
    setNotifications((current) => current.map((notification) => ({ ...notification, read: true })));
  };

  if (authStatus === 'loading') return <AuthLoadingScreen />;
  if (authStatus === 'signed-out') {
    const remembered = readStorage<{ tenantId?: string; username?: string }>(authRememberKey, {});
    return <EnterpriseLoginScreen remembered={remembered} error={authError} onSubmit={async (payload) => {
      try {
        await handleLogin(payload);
      } catch (error) {
        setAuthError(error instanceof Error ? error.message : 'Không thể đăng nhập.');
      }
    }} />;
  }

  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <ErrorBoundary resetKey={view}>
            <div className={`app-grain min-h-[100dvh] overflow-x-hidden bg-background ${showSplash ? 'motion-locked' : 'motion-ready'}`}>
            <div className="flex min-h-[100dvh]">
              <WorkspaceSidebar view={view} role={role} onChange={changeView} mobileOpen={mobileNav} onClose={() => setMobileNav(false)} />
              <main className="min-w-0 flex-1">
                {!isOnline && (
                  <div role="status" className="sticky top-0 z-20 flex items-center justify-center gap-2 bg-amber-100 px-4 py-2 text-center text-xs font-semibold text-amber-900 shadow-sm">
                    Đang offline · Dữ liệu đã lưu vẫn dùng được; AI và đồng bộ sẽ chờ khi có mạng.
                  </div>
                )}
                <header className="sticky top-0 z-10 flex h-[72px] items-center justify-between border-b border-border/70 bg-background/90 px-5 backdrop-blur-md md:px-10">
                  <div data-testid="brand-resto-header" className="pointer-events-none absolute left-1/2 hidden -translate-x-1/2 items-center gap-2 md:flex">
                    <BrandMark size={30} testId="logo-resto-header" />
                    <span><span className="brand-wordmark block text-lg leading-none text-foreground"><strong>Resto</strong><span className="brand-ai">.AI</span></span><span className="mt-1 block text-[8px] font-semibold tracking-[.08em] text-muted-foreground">AI vận hành · Tối ưu lợi nhuận</span></span>
                  </div>
                  <div className="flex items-center gap-3">
                    <button data-testid="button-open-menu" aria-label="Mở POS" onClick={() => changeView('pos')} className="rounded-xl p-1 md:hidden"><BrandMark size={34} testId="logo-resto-mobile" /></button>
                    <div>
                      <p className="font-mono text-[10px] uppercase tracking-[.18em] text-muted-foreground">{weekdayLabel(today)} · {dateLabel(today)}</p>
                      <h1 className="mt-0.5 font-serif text-xl text-foreground md:text-2xl">{pageTitle(view)}</h1>
                    </div>
                  </div>
                  <div className="flex items-center gap-2">
                    <button data-testid="button-role-mode" onClick={() => role === 'manager' ? switchToStaff() : (setQuickPinOpen(true), setRolePin(''), setRoleError(''))} className={`hidden items-center gap-2 rounded-xl border px-3 py-2 text-xs font-bold sm:flex ${role === 'manager' ? 'border-primary/25 bg-primary/10 text-primary' : 'border-border bg-card text-muted-foreground'}`}>
                      {role === 'manager' ? <Unlock size={14} /> : <Lock size={14} />}
                      {role === 'manager' ? 'Manager Mode' : 'Staff Mode'}
                    </button>
                    <div className="relative">
                      <button data-testid="button-notifications" aria-label="Mở trung tâm thông báo" aria-expanded={notificationCenterOpen} onClick={() => setNotificationCenterOpen((open) => !open)} className="relative rounded-xl p-2.5 text-muted-foreground transition-colors hover:bg-muted hover:text-foreground">{unreadNotificationCount ? <BellRing size={18} /> : <Bell size={18} />}{unreadNotificationCount > 0 && <span data-testid="notification-unread-dot" className="absolute right-2 top-2 h-1.5 w-1.5 rounded-full bg-accent ring-2 ring-background" />}</button>
                      {notificationCenterOpen && <NotificationCenter notifications={notifications} onClose={() => setNotificationCenterOpen(false)} onOpen={openNotification} onMarkAllRead={markAllNotificationsRead} />}
                    </div>
                    <div className="hidden h-8 w-px bg-border sm:block" />
                    <div className="relative">
                      <button data-testid="button-profile-header" aria-expanded={profileMenuOpen} onClick={() => setProfileMenuOpen((open) => !open)} className="flex items-center gap-2 rounded-xl p-1.5 pr-2 transition-colors hover:bg-muted">
                        <span className="grid h-8 w-8 place-items-center rounded-lg bg-secondary font-serif text-sm text-secondary-foreground">{authUser?.displayName.slice(0, 2).toUpperCase() ?? 'AB'}</span>
                        <span className="hidden text-left sm:block"><span className="block text-xs font-bold">{authUser?.displayName ?? 'Resto.AI'}</span><span className="block text-[10px] text-muted-foreground">{role === 'manager' ? 'Chủ quán' : 'Nhân viên'}</span></span>
                        <ChevronDown size={14} className="hidden text-muted-foreground sm:block" />
                      </button>
                      {profileMenuOpen && <div data-testid="profile-menu" className="absolute right-0 top-12 z-40 w-60 rounded-2xl border border-border bg-card p-2 shadow-2xl">
                        <div className="border-b border-border/70 px-3 py-2"><p className="text-xs font-bold">{authUser?.username}</p><p className="mt-1 text-[10px] text-muted-foreground">{authUser?.tenantId} · {role === 'manager' ? 'Manager' : 'Staff'}</p></div>
                        <button data-testid="button-quick-pin-switch" onClick={() => { setProfileMenuOpen(false); setQuickPinOpen(true); setRolePin(''); setRoleError(''); }} className="mt-1 flex w-full items-center gap-2 rounded-xl px-3 py-2.5 text-left text-xs font-semibold hover:bg-muted"><ArrowLeftRight size={15} />Đổi ca / Chuyển nhân viên</button>
                        {role === 'manager' && <button data-testid="button-admin-settings" onClick={() => { setProfileMenuOpen(false); setAdminSettingsOpen(true); }} className="flex w-full items-center gap-2 rounded-xl px-3 py-2.5 text-left text-xs font-semibold hover:bg-muted"><Settings size={15} />Cài đặt quản trị</button>}
                        <button data-testid="button-logout" onClick={() => void handleLogout()} className="flex w-full items-center gap-2 rounded-xl px-3 py-2.5 text-left text-xs font-semibold text-destructive hover:bg-destructive/10"><Unlock size={15} />Đăng xuất</button>
                      </div>}
                    </div>
                  </div>
                </header>
                <div className="mx-auto max-w-[1480px] p-5 pb-24 md:p-10 md:pb-12">
                  {view === 'overview' && <Dashboard ingredients={ingredients} transactions={transactions} orders={orders} mlForecast={mlForecast} onViewForecast={() => changeView('forecast')} onViewInventory={() => changeView('ledger')} onViewShopping={() => changeView('shopping')} onViewLedger={() => changeView('ledger')} onViewInvoices={() => changeView('orders')} onOpenCopilot={() => setCopilotOpen(true)} />}
                  {view === 'pos' && <PosWorkspace role={role} onCheckout={checkoutOrder} onRequireManagerPin={() => { setQuickPinOpen(true); setRolePin(''); setRoleError('Giảm giá sâu cần PIN quản lý.'); }} />}
                  {view === 'orders' && <OrdersWorkspace orders={orders} onUpdateStatus={(id, status) => { setOrders((current) => current.map((order) => order.id === id ? { ...order, status } : order)); notify('Đã cập nhật trạng thái đơn hàng'); }} onOpenPos={() => changeView('pos')} />}
                  {view === 'shopping' && <ShoppingWorkspace ingredients={ingredients} mlForecast={mlForecast} onRefresh={() => { void runMlForecast({ nhiet_do: 32, luong_mua: 0, ngay_trong_tuan: weekdayCode(today), la_ngay_le: 0, su_kien_dac_biet: 0, inventory: ingredients.map((item) => ({ name: item.name, unit: item.unit, quantity: item.current, shelf_life_days: item.shelfLifeDays ?? 7 })) }); }} onConfirm={confirmForecastRecommendation} onNotify={notify} />}
                  {view === 'ledger' && <LedgerWorkspace role={role} transactions={transactions} ingredients={ingredients} fixedCosts={fixedCosts} onAddTransaction={openAddTransaction} onEditTransaction={openEditTransaction} onDeleteTransaction={deleteTransaction} onAddIngredient={() => setModal('ingredient')} onAdjustIngredient={(item) => { setAdjusting(item); setModal('adjust'); }} onViewIngredient={setIngredientDetail} onToggleLow={toggleLowStock} onSaveStocktake={adjustIngredient} onAddFixedCost={() => setModal('fixed-cost')} onStocktakeAlert={(name, variance) => { void pushAuraNotification({ id: `stocktake-${today}-${name}`, kind: 'anomaly', title: 'Cảnh báo chênh lệch kiểm kho', body: `${name} đang lệch ${variance}% so với tồn lý thuyết. Hãy kiểm tra hao hụt trước khi chốt ca.`, view: 'forecast' }); notify(`Đã gửi cảnh báo AI cho ${name}`, 'warning'); }} />}
                  {view === 'forecast' && forecastRuns[0] && <ForecastWorkspace forecast={forecastRuns[0]} history={salesHistory} runs={forecastRuns} ingredients={ingredients} transactions={transactions} mlForecast={mlForecast} mlForecastLoading={mlForecastLoading} mlForecastError={mlForecastError} onMlForecast={runMlForecast} onRefresh={refreshForecast} onAdjust={adjustForecastRecommendation} onConfirm={confirmForecastRecommendation} onAction={(kind) => { if (kind === 'restock') changeView('shopping'); else if (kind === 'combo') notify('Đã tạo nháp combo xả hàng từ nguyên liệu ngắn hạn'); else notify('Đã mở checklist kiểm kho cuối ngày'); }} />}
                  {view === 'reports' && <Reports transactions={transactions} restaurant={profile.restaurant} onExport={() => notify('Đã tải báo cáo xuống máy')} />}
                  {view === 'more' && <MoreWorkspace role={role} onChange={changeView} onSettings={() => setAdminSettingsOpen(true)} onLogout={() => void handleLogout()} />}
                </div>
              </main>
            </div>
            {modal === 'transaction' && <TransactionModal initial={editingTransaction} onClose={() => setModal(null)} onSave={saveTransaction} />}
            {modal === 'ingredient' && <IngredientModal onClose={() => setModal(null)} onSave={saveIngredient} />}
            {modal === 'adjust' && adjusting && <AdjustModal ingredient={adjusting} onClose={() => { setModal(null); setAdjusting(null); }} onSave={(amount) => adjustIngredient(adjusting.id, amount)} />}
            {modal === 'fixed-cost' && <FixedCostModal onClose={() => setModal(null)} onSave={saveFixedCost} />}
            {ingredientDetail && <IngredientDetailsModal ingredient={ingredientDetail} onClose={() => setIngredientDetail(null)} />}
            {roleTarget && <RolePinModal pin={rolePin} error={roleError} target={roleTarget} onPinChange={setRolePin} onClose={() => { setRoleTarget(null); setPendingDeleteId(null); }} onSubmit={unlockManager} />}
            {quickPinOpen && <QuickPinModal currentRole={role} pin={rolePin} error={roleError} onPinChange={setRolePin} onClose={() => { setQuickPinOpen(false); setRolePin(''); setRoleError(''); }} onSubmit={unlockManager} />}
            {adminSettingsOpen && authUser && <AdminSettingsModal profile={profile} user={authUser} onClose={() => setAdminSettingsOpen(false)} onSave={(next) => { setProfile(next); setAdminSettingsOpen(false); notify('Đã lưu cài đặt quản trị'); }} />}
            <MobileNav view={view} role={role} onChange={changeView} />
            <QuickFab label="Thêm khoản thu chi" onClick={openAddTransaction} onOpenCopilot={() => setCopilotOpen(true)} showCreate={view === 'ledger' && role === 'manager'} />
            {copilotOpen && <AiCopilotSheet orders={orders} ingredients={ingredients} transactions={transactions} onClose={() => setCopilotOpen(false)} />}
            <ParticleExplosion burstKey={successBurstKey} global />
            {toast && <div role="status" aria-live="polite" data-testid="status-toast" className={`status-toast status-toast-${toastTone} fixed bottom-[calc(5.5rem+env(safe-area-inset-bottom))] left-1/2 z-50 flex max-w-[calc(100vw-2rem)] -translate-x-1/2 items-center gap-2 rounded-2xl border px-4 py-3 text-sm font-semibold shadow-xl md:bottom-5`}><span className="grid h-6 w-6 shrink-0 place-items-center rounded-full bg-current/10">{toastTone === 'success' ? <Check size={15} /> : <AlertTriangle size={15} />}</span>{toast}</div>}
            {showInstallPrompt && <InstallPromptBanner canInstall={Boolean(installPrompt)} onInstall={installPwa} onDismiss={dismissInstallPrompt} />}
             {showPermissionPrompt && <NotificationPermissionPrompt onAllow={requestNotifications} onDismiss={dismissNotificationPrompt} />}
            {showSplash && <SplashScreen />}
          </div>
        </ErrorBoundary>
        <Toaster />
      </TooltipProvider>
    </QueryClientProvider>
  );
}

function pageTitle(view: View) {
  return ({ overview: 'Tổng quan & AI Insights', pos: 'POS · Bán hàng', orders: 'Quản lý đơn hàng', shopping: 'Đi chợ AI', ledger: 'Sổ quỹ & Kho', forecast: 'Trợ lý AI Command Center', reports: 'Báo cáo tài chính', more: 'Mở rộng' })[view];
}

function BrandMark({ size = 40, testId }: { size?: number; testId?: string }) {
  const gradientId = `${testId ?? 'resto-mark'}-sunset-cyber`;
  return <svg data-testid={testId} width={size} height={size} viewBox="0 0 48 48" fill="none" role="img" aria-label="Logo Resto.AI" xmlns="http://www.w3.org/2000/svg">
    <defs><linearGradient id={gradientId} x1="7" y1="7" x2="42" y2="42"><stop stopColor="#FF9B3D" /><stop offset=".52" stopColor="#FF6B35" /><stop offset="1" stopColor="#22D3EE" /></linearGradient></defs>
    <rect width="48" height="48" rx="14" fill={`url(#${gradientId})`} />
    <path d="M10 30.5h28M13.5 30.5c.7-7.4 4.7-11.7 10.5-11.7s9.8 4.3 10.5 11.7" stroke="#07111F" strokeWidth="2.35" strokeLinecap="round" />
    <path d="M16 34.5h16" stroke="#07111F" strokeWidth="2.35" strokeLinecap="round" />
    <path d="M24 14v-3M20.5 12.5h7" stroke="#F8FAFC" strokeWidth="1.8" strokeLinecap="round" />
    <path d="M12.5 18 15 20.5M35.5 18 33 20.5" stroke="#F8FAFC" strokeWidth="1.6" strokeLinecap="round" />
    <circle cx="10.5" cy="16" r="1.7" fill="#F8FAFC" /><circle cx="37.5" cy="16" r="1.7" fill="#F8FAFC" />
    <circle cx="24" cy="8.5" r="1.7" fill="#22D3EE" />
  </svg>;
}

function SplashScreen() {
  const [burst, setBurst] = useState(false);
  useEffect(() => {
    const reducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
    const timer = window.setTimeout(() => setBurst(true), reducedMotion ? 240 : 1900);
    return () => window.clearTimeout(timer);
  }, []);
  const particles = Array.from({ length: 40 }, (_, index) => ({
    angle: `${index * 9}deg`,
    distance: `${108 + (index % 8) * 18}px`,
    delay: `${(index % 8) * 18}ms`,
    size: `${index % 7 === 0 ? 9 : index % 4 === 0 ? 7 : index % 3 === 0 ? 5 : 3}px`,
    color: index % 5 === 0 ? '#F8FAFC' : index % 3 === 0 ? '#22D3EE' : index % 2 === 0 ? '#FFB15C' : '#FF6B35',
  }));
  return <div data-testid="splash-screen" className={`splash-screen ${burst ? 'splash-burst' : ''}`} aria-label="Resto.AI đang khởi động">
    <div className="splash-energy" aria-hidden="true" />
    <div className="splash-orbit" aria-hidden="true" />
    <div className="splash-particles" aria-hidden="true">{particles.map((particle, index) => <span key={index} className="splash-particle" style={{ '--particle-angle': particle.angle, '--particle-distance': particle.distance, '--particle-delay': particle.delay, '--particle-size': particle.size, '--particle-color': particle.color } as CSSProperties} />)}</div>
    <div className="splash-content">
      <SplashLogo />
      <div className="splash-wordmark"><strong>Resto</strong><span>.AI</span></div>
      <div className="splash-slogan">AI vận hành · Tối ưu lợi nhuận</div>
    </div>
  </div>;
}

function SplashLogo() {
  return <svg data-testid="logo-resto-splash" className="splash-svg" viewBox="0 0 208 208" role="img" aria-label="Logo Resto.AI" xmlns="http://www.w3.org/2000/svg">
    <rect className="splash-icon-bg" x="8" y="8" width="192" height="192" rx="52" />
    <g className="splash-drawing" fill="none" stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="8">
      <path className="splash-draw" d="M57 124c5-28 25-48 47-48s42 20 47 48" />
      <path className="splash-draw" d="M47 140h114M62 157h84" />
      <path className="splash-draw splash-spark" d="M104 62v-14M97 55h14" />
      <path className="splash-draw splash-spark" d="m53 83 6-12 6 12 12 6-12 6-6 12-6-12-12-6 12-6ZM154 76l5-10 5 10 10 5-10 5-5 10-5-10-10-5 10-5ZM143 112l4-8 4 8 8 4-8 4-4 8-4-8-8-4 8-4Z" />
    </g>
  </svg>;
}

function NotificationPermissionPrompt({ onAllow, onDismiss }: { onAllow: () => Promise<void>; onDismiss: () => void }) {
  return <aside data-testid="notification-permission-prompt" role="dialog" aria-labelledby="notification-permission-title" className="fixed inset-x-4 bottom-[calc(5.5rem+env(safe-area-inset-bottom)+8.5rem)] z-[70] overflow-hidden rounded-3xl border border-primary/20 bg-card/95 p-5 shadow-2xl backdrop-blur-xl sm:left-auto sm:right-5 sm:max-w-sm md:bottom-5">
    <div className="absolute -right-8 -top-10 h-28 w-28 rounded-full bg-primary/10 blur-2xl" />
    <div className="relative flex items-start gap-3">
      <span className="grid h-11 w-11 shrink-0 place-items-center rounded-2xl bg-primary text-primary-foreground shadow-lg shadow-primary/20"><BellRing size={20} /></span>
      <div className="min-w-0 flex-1">
        <p className="font-mono text-[10px] uppercase tracking-[.18em] text-primary">Resto.AI chủ động</p>
        <h2 id="notification-permission-title" className="mt-1 font-serif text-xl">Để Resto.AI nhắc đúng lúc</h2>
        <p className="mt-2 text-xs leading-5 text-muted-foreground">Nhận nhắc đi chợ, cảnh báo hao hụt và gợi ý xử lý khi thời tiết hoặc nhu cầu thay đổi.</p>
        <div className="mt-4 flex gap-2">
          <button data-testid="button-allow-notifications" onClick={() => void onAllow()} className="rounded-xl bg-primary px-3.5 py-2.5 text-xs font-bold text-primary-foreground">Bật thông báo</button>
          <button data-testid="button-dismiss-notification-prompt" onClick={onDismiss} className="rounded-xl border border-border px-3.5 py-2.5 text-xs font-bold text-muted-foreground">Để sau</button>
        </div>
      </div>
      <button data-testid="button-close-notification-prompt" aria-label="Đóng popup thông báo" onClick={onDismiss} className="rounded-lg p-1 text-muted-foreground hover:bg-muted"><X size={16} /></button>
    </div>
  </aside>;
}

function NotificationCenter({ notifications, onClose, onOpen, onMarkAllRead }: { notifications: AuraNotification[]; onClose: () => void; onOpen: (notification: AuraNotification) => void; onMarkAllRead: () => void }) {
  const todayKey = dateInput(new Date());
  const todayNotifications = notifications.filter((notification) => dateInput(new Date(notification.createdAt)) === todayKey);
  return <section data-testid="notification-center" aria-label="Trung tâm thông báo" className="absolute right-0 top-12 z-40 w-[min(92vw,390px)] overflow-hidden rounded-2xl border border-card-border bg-card/95 text-left shadow-2xl backdrop-blur-xl">
    <div className="flex items-start justify-between border-b border-border/70 p-4">
      <div><p className="font-mono text-[10px] uppercase tracking-[.18em] text-primary">Trung tâm thông báo</p><h2 className="mt-1 font-serif text-xl">Thông báo hôm nay</h2></div>
      <div className="flex items-center gap-1"><button data-testid="button-mark-notifications-read" onClick={onMarkAllRead} className="rounded-lg px-2 py-1.5 text-[10px] font-bold text-primary hover:bg-primary/10">Đã xem hết</button><button data-testid="button-close-notification-center" aria-label="Đóng trung tâm thông báo" onClick={onClose} className="rounded-lg p-1.5 text-muted-foreground hover:bg-muted"><X size={16} /></button></div>
    </div>
    <div className="max-h-[min(60vh,420px)] overflow-y-auto p-2">
      {todayNotifications.length === 0 ? <div data-testid="notification-center-empty" className="px-4 py-8 text-center"><span className="mx-auto grid h-11 w-11 place-items-center rounded-2xl bg-secondary text-secondary-foreground"><Bell size={19} /></span><p className="mt-3 text-sm font-bold">Chưa có thông báo mới</p><p className="mt-1 text-xs leading-5 text-muted-foreground">Resto.AI sẽ lưu lại các cảnh báo AI trong ngày tại đây.</p></div> : todayNotifications.map((notification) => <button data-testid={`notification-item-${notification.id}`} key={notification.id} onClick={() => onOpen(notification)} className={`flex w-full items-start gap-3 rounded-xl p-3 text-left transition-colors hover:bg-muted ${notification.read ? 'opacity-65' : 'bg-primary/[.045]'}`}><span className={`mt-0.5 grid h-9 w-9 shrink-0 place-items-center rounded-xl ${notification.kind === 'anomaly' ? 'bg-accent/12 text-accent' : 'bg-primary/10 text-primary'}`}>{notification.kind === 'anomaly' ? <AlertTriangle size={17} /> : notification.kind === 'flash' ? <CloudRain size={17} /> : <ShoppingBasket size={17} />}</span><span className="min-w-0 flex-1"><span className="flex items-start justify-between gap-2"><span className="text-xs font-bold leading-5">{notification.title}</span><span className="shrink-0 font-mono text-[9px] text-muted-foreground">{notificationDate(notification.createdAt)}</span></span><span className="mt-1 block text-[11px] leading-5 text-muted-foreground">{notification.body}</span><span className="mt-2 block text-[10px] font-bold text-primary">{notification.view === 'ledger' ? 'Mở Sổ quỹ & kho' : 'Mở AI Forecast & chỉ huy'}</span></span></button>)}
    </div>
  </section>;
}

function InstallPromptBanner({ canInstall, onInstall, onDismiss }: { canInstall: boolean; onInstall: () => void; onDismiss: () => void }) {
  return <aside role="dialog" aria-label="Cài Resto.AI vào màn hình chính" className="fixed inset-x-4 bottom-[calc(5.5rem+env(safe-area-inset-bottom))] z-50 rounded-2xl border border-card-border bg-card p-4 shadow-2xl md:bottom-4 sm:left-auto sm:right-5 sm:max-w-sm">
    <div className="flex items-start gap-3">
      <span className="grid h-10 w-10 shrink-0 place-items-center rounded-xl bg-primary text-primary-foreground"><Download size={18} /></span>
      <div className="min-w-0 flex-1">
        <div className="flex items-start justify-between gap-2">
          <p className="text-sm font-bold text-foreground">Thêm Resto.AI vào màn hình chính</p>
          <button data-testid="button-dismiss-install-prompt" aria-label="Đóng gợi ý cài đặt" onClick={onDismiss} className="rounded-lg p-1 text-muted-foreground hover:bg-muted"><X size={16} /></button>
        </div>
        <p className="mt-1 text-xs leading-5 text-muted-foreground">{canInstall ? 'Mở app nhanh hơn và dùng như một ứng dụng trên điện thoại.' : 'Chạm nút Chia sẻ của trình duyệt rồi chọn “Thêm vào màn hình chính”.'}</p>
        <button data-testid="button-install-pwa" onClick={onInstall} className="mt-3 rounded-lg bg-primary px-3 py-2 text-xs font-bold text-primary-foreground hover:opacity-90">{canInstall ? 'Cài ngay' : 'Đã hiểu'}</button>
      </div>
    </div>
  </aside>;
}

function OperationsFilterBar({ label = 'Bộ lọc vận hành', onPeriodChange }: { label?: string; onPeriodChange?: (period: string) => void }) {
  const [period, setPeriod] = useState('Hôm nay');
  const [branch, setBranch] = useState('Bếp Nhà Mình');
  return <div data-testid="operations-filter-bar" className="sticky-filter flex flex-col gap-3 rounded-2xl border border-border/70 bg-card/90 p-2.5 shadow-[var(--shadow-card)] backdrop-blur-xl sm:flex-row sm:items-center sm:justify-between">
    <div className="flex items-center gap-2 px-2"><SlidersHorizontal size={15} className="text-primary" /><span className="text-xs font-bold">{label}</span></div>
    <div className="flex min-w-0 gap-2 overflow-x-auto">
      <div className="flex shrink-0 rounded-xl bg-muted p-1">{['Hôm nay', 'Hôm qua', 'Tuần này', 'Tháng này'].map((item) => <button data-testid={`filter-period-${item}`} key={item} onClick={() => { setPeriod(item); onPeriodChange?.(item); }} className={`whitespace-nowrap rounded-lg px-2.5 py-1.5 text-[10px] font-bold transition-colors ${period === item ? 'bg-card text-primary shadow-sm' : 'text-muted-foreground hover:text-foreground'}`}>{item}</button>)}</div>
      <select data-testid="select-branch-filter" value={branch} onChange={(event) => setBranch(event.target.value)} className="h-9 shrink-0 rounded-xl border border-input bg-background px-3 text-[10px] font-bold text-foreground outline-none focus:border-primary"><option>Bếp Nhà Mình</option><option>Tất cả chi nhánh</option></select>
    </div>
  </div>;
}

function QuickActionRow({ onInventory, onShopping, onLedger, onInvoices }: { onInventory: () => void; onShopping: () => void; onLedger: () => void; onInvoices: () => void }) {
  const actions = [
    { label: 'Kiểm kho', icon: ClipboardCheck, onClick: onInventory },
    { label: 'Nhập hàng', icon: Truck, onClick: onShopping },
    { label: 'Thu chi', icon: CircleDollarSign, onClick: onLedger },
    { label: 'Hóa đơn', icon: ReceiptText, onClick: onInvoices },
  ];
  return <section data-testid="quick-action-row" className="workspace-card flex flex-wrap items-center justify-between gap-3 p-3 md:px-4"><p className="px-1 text-xs font-bold text-muted-foreground">Truy cập nhanh</p><div className="flex flex-1 justify-end gap-2 sm:gap-3">{actions.map(({ label, icon: Icon, onClick }) => <button data-testid={`quick-action-${label}`} key={label} onClick={onClick} className="group flex min-w-[4.3rem] flex-col items-center gap-1.5 rounded-xl px-2 py-1.5 text-[10px] font-bold text-muted-foreground transition-colors hover:bg-primary/8 hover:text-primary"><span className="grid h-9 w-9 place-items-center rounded-full border border-border bg-background text-primary shadow-sm transition-transform group-hover:-translate-y-0.5"><Icon size={16} /></span>{label}</button>)}</div></section>;
}

function RevenueTrend({ transactions }: { transactions: Transaction[] }) {
  const points = Array.from({ length: 8 }, (_, index) => transactions.filter((item) => item.type === 'thu' && laborHourForTransaction(item) >= index * 2 + 7 && laborHourForTransaction(item) < index * 2 + 9).reduce((sum, item) => sum + item.amount, 0));
  const max = Math.max(...points, 1);
  const path = points.map((value, index) => `${index * 14.28},${92 - (value / max) * 72}`).join(' ');
  return <section data-testid="revenue-trend-card" className="workspace-card overflow-hidden p-4 md:p-5"><div className="flex items-start justify-between gap-3"><div><p className="workspace-eyebrow text-primary">Revenue analytics</p><h3 className="mt-1 font-serif text-2xl">Doanh thu theo khung giờ</h3></div><span className="rounded-full bg-primary/10 px-2.5 py-1 text-[10px] font-bold text-primary">06:00–23:00</span></div><div className="mt-4 overflow-hidden rounded-2xl bg-muted/45 p-3"><svg viewBox="0 0 100 100" className="h-36 w-full" role="img" aria-label="Biểu đồ doanh thu theo giờ"><defs><linearGradient id="revenue-area" x1="0" x2="0" y1="0" y2="1"><stop offset="0%" stopColor="hsl(var(--primary))" stopOpacity=".3" /><stop offset="100%" stopColor="hsl(var(--primary))" stopOpacity="0" /></linearGradient></defs><path d={`M 0 100 L ${path} L 100 100 Z`} fill="url(#revenue-area)" /><polyline points={path} fill="none" stroke="hsl(var(--primary))" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round" vectorEffect="non-scaling-stroke" />{points.map((value, index) => <circle key={index} cx={index * 14.28} cy={92 - (value / max) * 72} r="1.8" fill="hsl(var(--card))" stroke="hsl(var(--primary))" strokeWidth="1.2" vectorEffect="non-scaling-stroke" />)}</svg><div className="flex justify-between px-1 text-[10px] text-muted-foreground"><span>06:00</span><span>10:00</span><span>14:00</span><span>18:00</span><span>22:00</span></div></div></section>;
}

function SpotlightSurface({ children, className = '' }: { children: ReactNode; className?: string }) {
  const [spotlight, setSpotlight] = useState({ x: '50%', y: '50%' });
  return <article className={`spotlight-surface ${className}`} onPointerMove={(event) => { const rect = event.currentTarget.getBoundingClientRect(); setSpotlight({ x: `${event.clientX - rect.left}px`, y: `${event.clientY - rect.top}px` }); }} style={{ '--spotlight-x': spotlight.x, '--spotlight-y': spotlight.y } as CSSProperties}>{children}<span className="spotlight-glow" aria-hidden="true" /></article>;
}

function ParticleExplosion({ burstKey, global = false }: { burstKey: number; global?: boolean }) {
  if (!burstKey) return null;
  return <div key={burstKey} className={`success-explosion ${global ? 'success-explosion-global' : ''}`} aria-hidden="true">{Array.from({ length: 18 }, (_, index) => <span key={index} className="success-particle" style={{ '--particle-angle': `${index * 20}deg`, '--particle-distance': `${42 + (index % 4) * 12}px`, '--particle-delay': `${(index % 5) * 18}ms`, '--particle-color': index % 2 ? '#FF8A3D' : '#22D3EE' } as CSSProperties} />)}</div>;
}

function RestoInsights({ onCreateRestock, onOpenCopilot }: { onCreateRestock: () => void; onOpenCopilot: () => void }) {
  const [restockCreated, setRestockCreated] = useState(false);
  const [burstKey, setBurstKey] = useState(0);
  const createRestock = () => {
    setRestockCreated(true);
    setBurstKey((key) => key + 1);
    onCreateRestock();
  };
  return <SpotlightSurface className="resto-insights-card" ><div className="relative z-10"><div className="flex flex-col justify-between gap-4 md:flex-row md:items-start"><div className="flex items-start gap-3"><span className="resto-insights-icon"><Bot size={21} /></span><div><p className="workspace-eyebrow resto-cyan-text">Resto.AI Insights</p><h3 className="mt-1 font-serif text-2xl md:text-3xl">Phân tích thông minh cho ca tiếp theo</h3><p className="mt-1 text-xs leading-5 text-muted-foreground">AI kết hợp thời tiết, nhu cầu món và dòng tiền để gợi ý việc nên làm.</p></div></div><button data-testid="button-open-copilot-insights" onClick={onOpenCopilot} className="motion-action-button flex w-fit items-center gap-2 rounded-xl border border-cyan-400/25 bg-cyan-400/10 px-3 py-2.5 text-xs font-bold text-cyan-600 dark:text-cyan-300"><Bot size={15} />Hỏi AI Co-pilot</button></div><div className="mt-5 grid gap-3 lg:grid-cols-2"><div className="resto-insight-widget resto-insight-widget-warm"><div className="flex items-start gap-3"><span className="grid h-9 w-9 shrink-0 place-items-center rounded-xl bg-orange-400/15 text-orange-500"><CloudRain size={17} /></span><div><p className="text-xs font-extrabold">Dự báo nguyên liệu</p><p className="mt-2 text-xs leading-5 text-muted-foreground">AI dự đoán cuối tuần này trời mưa, nhu cầu <strong className="text-foreground">Lẩu Thái tăng 30%</strong>. Gợi ý nhập thêm <strong className="text-foreground">5kg Nấm</strong> và <strong className="text-foreground">10kg Bò</strong>.</p></div></div><button data-testid="button-auto-restock" onClick={createRestock} className="motion-action-button mt-4 flex w-full items-center justify-center gap-2 rounded-xl bg-orange-500 px-3 py-2.5 text-xs font-extrabold text-white shadow-lg shadow-orange-500/15">{restockCreated ? <><CheckCircle2 size={15} />Đã tạo nháp nhập hàng</> : <><ShoppingBasket size={15} />Tạo phiếu nhập tự động</>}</button></div><div className="resto-insight-widget resto-insight-widget-cool"><div className="flex items-start gap-3"><span className="grid h-9 w-9 shrink-0 place-items-center rounded-xl bg-cyan-400/15 text-cyan-600 dark:text-cyan-300"><TrendingUp size={17} /></span><div><p className="text-xs font-extrabold">Phân tích dòng tiền</p><p className="mt-2 text-xs leading-5 text-muted-foreground">Chi phí nguyên liệu đang chiếm <strong className="text-foreground">45% doanh thu</strong>, cao hơn mức an toàn <strong className="text-foreground">35%</strong>.</p></div></div><div className="mt-4 flex items-center justify-between gap-3 rounded-xl bg-background/55 px-3 py-2.5"><span className="text-[11px] font-bold text-muted-foreground">Cần kiểm tra lại định lượng món</span><span className="font-mono text-sm font-extrabold text-orange-500">+10%</span></div></div></div></div><ParticleExplosion burstKey={burstKey} /></SpotlightSurface>;
}

function QuickFab({ label, onClick, onOpenCopilot, showCreate }: { label: string; onClick: () => void; onOpenCopilot: () => void; showCreate: boolean }) {
  return <div className="quick-fab-group fixed bottom-[calc(5.5rem+env(safe-area-inset-bottom))] right-4 z-30 flex items-end gap-2 md:bottom-6 md:right-7"><button data-testid="button-open-ai-copilot" aria-label="Hỏi AI Co-pilot" onClick={onOpenCopilot} className="quick-fab quick-fab-ai grid h-11 w-11 place-items-center rounded-full text-cyan-950 shadow-[0_10px_24px_rgba(34,211,238,.3)]"><Bot size={19} /><span className="sr-only">Hỏi AI Co-pilot</span></button>{showCreate && <button data-testid="button-quick-fab" aria-label={label} onClick={onClick} className="quick-fab grid h-14 w-14 place-items-center rounded-full bg-primary text-primary-foreground shadow-[0_12px_28px_hsl(var(--primary)/.34)] transition-transform hover:-translate-y-1 active:scale-95"><Plus size={24} /><span className="sr-only">{label}</span></button>}</div>;
}

function AiCopilotSheet({ orders, ingredients, transactions, onClose }: { orders: Order[]; ingredients: Ingredient[]; transactions: Transaction[]; onClose: () => void }) {
  const [input, setInput] = useState('');
  const lowStock = ingredients.filter((item) => item.current < item.minimum);
  const activeOrders = orders.filter((order) => order.status !== 'hoan-tat');
  const revenue = transactions.filter((item) => item.type === 'thu').reduce((sum, item) => sum + item.amount, 0);
  const expenses = transactions.filter((item) => item.type === 'chi').reduce((sum, item) => sum + item.amount, 0);
  const [messages, setMessages] = useState([{ from: 'ai', text: 'Chào chủ quán, tôi là trợ lý ảo Resto.AI. Bạn muốn hỏi về báo cáo hôm nay hay cần gợi ý lên chiến dịch khuyến mãi?' }]);
  const [typing, setTyping] = useState(false);
  const ask = (question = input) => {
    const next = question.trim();
    if (!next || typing) return;
    setInput('');
    setMessages((current) => [...current, { from: 'user', text: next }]);
    setTyping(true);
    window.setTimeout(() => {
      const lower = next.toLowerCase();
      const response = lower.includes('đơn')
        ? `Hiện có ${activeOrders.length} đơn chưa hoàn tất${activeOrders.length ? `; cần ưu tiên ${activeOrders.filter((order) => order.status === 'cho-thanh-toan').length} đơn chờ thu tiền.` : '.'}`
        : lower.includes('kho') || lower.includes('nguyên liệu') || lower.includes('nhập')
          ? (lowStock.length ? `Có ${lowStock.length} nguyên liệu dưới ngưỡng: ${lowStock.slice(0, 3).map((item) => item.name).join(', ')}. Tôi đề xuất mở kế hoạch nhập và ưu tiên hàng có hạn dùng ngắn.` : 'Kho đang nằm trên mức tối thiểu. Tôi đề xuất kiểm tra hàng sắp hết hạn và đối chiếu định lượng món.')
          : lower.includes('doanh thu') || lower.includes('lợi nhuận') || lower.includes('tiền')
            ? `Doanh thu ghi nhận là ${money(revenue)}, chi phí ${money(expenses)}, chênh lệch ${money(revenue - expenses)}. Tôi có thể bóc tách theo ca, món hoặc chi phí nguyên liệu.`
            : lower.includes('nhân viên') || lower.includes('ca')
              ? 'AI đề xuất phân công 1 người kiểm soát đơn online và 1 người chốt thu tiền cuối ca; hãy theo dõi khung 13:00–15:00 để tối ưu nhân sự.'
              : lower.includes('khuyến')
                ? 'Resto.AI gợi ý combo cuối tuần: ưu tiên món có tồn kho ngắn hạn, giới hạn giảm giá theo biên lợi nhuận và theo dõi tỷ lệ chuyển đổi theo ca.'
                : 'Tôi đang theo dõi 4 lớp vận hành: doanh thu, đơn hàng, kho và nhân sự. Hãy hỏi tôi “đơn nào đang tồn?”, “kho cần nhập gì?” hoặc “doanh thu hôm nay?”.';
      setMessages((current) => [...current, { from: 'ai', text: response }]);
      setTyping(false);
    }, 360);
  };
  return <div data-testid="ai-copilot-sheet" className="copilot-morph-layer" role="presentation" onMouseDown={(event) => { if (event.target === event.currentTarget) onClose(); }}><section className="copilot-morph-sheet" role="dialog" aria-modal="true" aria-labelledby="copilot-sheet-title"><div className="copilot-sheet-handle" /><div className="flex items-start justify-between gap-3"><div className="flex items-center gap-3"><span className="copilot-avatar"><Bot size={20} /></span><div><p className="workspace-eyebrow resto-cyan-text">Resto.AI Co-pilot</p><h2 id="copilot-sheet-title" className="mt-1 font-serif text-2xl">Trợ lý trong ca</h2></div></div><button data-testid="button-close-ai-copilot" aria-label="Đóng AI Co-pilot" onClick={onClose} className="rounded-xl p-2 text-muted-foreground hover:bg-muted"><X size={18} /></button></div><div className="copilot-sheet-messages mt-5 space-y-3" aria-live="polite">{messages.map((message, index) => <div key={`${message.from}-${index}`} className={`copilot-sheet-message ${message.from === 'user' ? 'copilot-sheet-message-user' : 'copilot-sheet-message-ai'}`}>{message.text}</div>)}{typing && <div className="copilot-sheet-message copilot-sheet-message-ai typing-dots"><span /><span /><span /></div>}</div><div className="mt-4 flex flex-wrap gap-2"><button onClick={() => ask('Đơn nào đang tồn?')} className="command-question">Đơn nào đang tồn?</button><button onClick={() => ask('Kho cần nhập gì?')} className="command-question">Kho cần nhập gì?</button><button onClick={() => ask('Doanh thu hôm nay?')} className="command-question">Doanh thu hôm nay?</button><button onClick={() => ask('Tối ưu ca nhân viên')} className="command-question">Tối ưu ca</button></div><div className="mt-4 flex gap-2"><input data-testid="input-floating-ai-copilot" value={input} onChange={(event) => setInput(event.target.value)} onKeyDown={(event) => { if (event.key === 'Enter') ask(); }} placeholder="Hỏi Resto.AI..." className="min-w-0 flex-1 rounded-xl border border-input bg-background px-3 py-3 text-sm outline-none focus:border-primary" /><button data-testid="button-send-floating-ai" aria-label="Gửi câu hỏi" onClick={() => ask()} className="motion-action-button grid h-12 w-12 shrink-0 place-items-center rounded-xl bg-primary text-primary-foreground"><Send size={17} /></button></div></section></div>;
}

function MoreWorkspace({ role, onChange, onSettings, onLogout }: { role: Role; onChange: (view: View) => void; onSettings: () => void; onLogout: () => void }) {
  const groups = [
    { title: 'Thực đơn & bán hàng', note: 'Tạo món, thiết lập giá và phục vụ', items: [
      { label: 'Món & nhóm món', detail: 'Quản lý menu, giá bán và định lượng BOM', icon: ShoppingBasket, action: () => onChange('pos'), status: 'Đang dùng' },
      { label: 'Phòng bàn & gọi món QR', detail: 'Sơ đồ bàn, QR gọi món, giao đi', icon: Store, action: () => onChange('pos'), status: 'POS hiện tại' },
      { label: 'Hóa đơn & trả hàng', detail: 'Tra cứu đơn, hoàn tiền và điều chỉnh', icon: ReceiptText, action: () => onChange('orders'), status: 'Đơn hàng' },
    ] },
    { title: 'Kho hàng & mua hàng', note: 'Kiểm soát tồn, nhập và luân chuyển', items: [
      { label: 'Kho hàng', detail: 'Tồn lý thuyết, tồn thực tế và cảnh báo thấp', icon: Boxes, action: () => onChange('ledger'), status: 'Đang dùng' },
      { label: 'Kiểm kho & xuất hủy', detail: 'Đối chiếu chênh lệch, ghi nhận hao hụt', icon: ClipboardCheck, action: () => onChange('ledger'), status: 'Đang dùng' },
      { label: 'Nhập hàng & nhà cung cấp', detail: 'Lập kế hoạch mua và theo dõi giá nhập', icon: Truck, action: () => onChange('shopping'), status: 'AI hỗ trợ' },
      { label: 'Chuyển hàng giữa kho', detail: 'Chuẩn bị cho mô hình nhiều chi nhánh', icon: ArrowLeftRight, action: () => onChange('shopping'), status: 'Đang hoàn thiện' },
    ] },
    { title: 'Khách hàng & nhân viên', note: 'Dữ liệu con người để quản trị ca', items: [
      { label: 'Khách hàng', detail: 'Lịch sử mua, nhóm khách và chăm sóc lại', icon: Users, action: () => onChange('reports'), status: 'Đang hoàn thiện' },
      { label: 'Nhân viên & phân quyền', detail: 'Vai trò chủ quán, quản lý, thu ngân, bếp', icon: Lock, action: onSettings, status: 'Manager PIN' },
      { label: 'Lịch làm việc & chấm công', detail: 'Xếp ca, theo dõi giờ và chuẩn bị bảng lương', icon: CalendarDays, action: onSettings, status: 'Đang hoàn thiện' },
    ] },
    { title: 'Tài chính & báo cáo', note: 'Đối soát tiền và đo hiệu quả', items: [
      { label: 'Sổ quỹ tiền mặt / ngân hàng', detail: 'Đầu kỳ, thu, chi và cuối kỳ theo bộ lọc', icon: WalletCards, action: () => onChange('ledger'), status: 'Đang dùng' },
      { label: 'Báo cáo cuối ngày', detail: 'Chốt ca, doanh thu, chi phí và lợi nhuận', icon: FileDown, action: () => onChange('reports'), status: 'Đang dùng' },
      { label: 'Thuế & hóa đơn điện tử', detail: 'Khu vực kết nối dịch vụ khi triển khai thật', icon: ReceiptText, action: onSettings, status: 'Chưa kết nối' },
    ] },
    { title: 'Trợ lý & hệ thống', note: 'AI, thiết bị và lịch sử thao tác', items: [
      { label: 'AI Co-pilot & dự báo', detail: 'Hỏi dữ liệu quán, dự báo và action queue', icon: MessageCircle, action: () => onChange('forecast'), status: 'Đang dùng' },
      { label: 'Thiết bị & cài đặt quán', detail: 'PWA, máy in, máy POS và cấu hình chung', icon: Smartphone, action: onSettings, status: 'Cài đặt' },
      { label: 'Lịch sử thao tác', detail: 'Theo dõi ai tạo, sửa, hủy hoặc duyệt giao dịch', icon: History, action: onSettings, status: 'Đang hoàn thiện' },
      { label: 'Đăng xuất', detail: 'Kết thúc phiên trên thiết bị này', icon: Unlock, action: onLogout, status: 'Tài khoản', danger: true },
    ] },
  ];
  return <div data-testid="workspace-more" className="workspace-page space-y-5 md:space-y-6"><section className="workspace-hero"><p className="workspace-eyebrow text-primary">Trung tâm nghiệp vụ · {role === 'manager' ? 'Manager Mode' : 'Staff Mode'}</p><h2 className="mt-2 font-serif text-3xl md:text-4xl">Mọi chức năng ở đúng một chỗ.</h2><p className="mt-2 max-w-2xl text-sm leading-6 text-muted-foreground">Các nhóm được sắp xếp theo quy trình nhà hàng: bán hàng → kho → con người → tài chính → hệ thống. Nhãn trạng thái cho biết phần nào đang dùng được và phần nào còn cần kết nối dữ liệu thật.</p></section>{groups.map((group) => <section key={group.title} className="workspace-card overflow-hidden"><div className="flex items-end justify-between gap-3 border-b border-border/70 px-4 py-3 md:px-5"><div><p className="workspace-eyebrow text-muted-foreground">{group.title}</p><p className="mt-1 text-xs text-muted-foreground">{group.note}</p></div><span className="rounded-full bg-muted px-2 py-1 text-[10px] font-bold text-muted-foreground">{group.items.length} mục</span></div><div className="grid gap-px bg-border/60 sm:grid-cols-2">{group.items.map(({ label, detail, icon: Icon, action, status, danger }) => <button data-testid={`more-item-${label}`} key={label} onClick={action} className={`flex min-h-[92px] items-start gap-3 bg-card px-4 py-4 text-left transition-colors hover:bg-muted/50 md:px-5 ${danger ? 'text-destructive' : 'text-foreground'}`}><span className={`grid h-9 w-9 shrink-0 place-items-center rounded-xl ${danger ? 'bg-destructive/10' : 'bg-primary/10 text-primary'}`}><Icon size={16} /></span><span className="min-w-0 flex-1"><span className="flex items-start justify-between gap-2"><span className="text-sm font-bold">{label}</span><ChevronRight size={15} className="mt-0.5 shrink-0 text-muted-foreground" /></span><span className="mt-1 block text-[11px] leading-5 text-muted-foreground">{detail}</span><span className={`mt-2 inline-flex rounded-full px-2 py-0.5 text-[9px] font-bold ${status === 'Đang dùng' || status === 'POS hiện tại' || status === 'AI hỗ trợ' ? 'bg-primary/10 text-primary' : status === 'Chưa kết nối' ? 'bg-muted text-muted-foreground' : 'bg-accent/10 text-accent'}`}>{status}</span></span></button>)}</div></section>)}</div>;
}

function WorkspaceSidebar({ view, role, onChange, mobileOpen, onClose }: { view: View; role: Role; onChange: (view: View) => void; mobileOpen: boolean; onClose: () => void }) {
  const links: { id: View; label: string; icon: typeof LayoutDashboard; note?: string }[] = [
    { id: 'overview', label: 'Tổng quan', icon: LayoutDashboard },
    { id: 'pos', label: 'POS · Bán hàng', icon: ShoppingBasket },
    { id: 'orders', label: 'Đơn hàng', icon: ClipboardList },
    { id: 'shopping', label: 'Đi chợ AI', icon: ShoppingBasket, note: 'AI' },
    { id: 'ledger', label: 'Sổ quỹ & Kho', icon: ArrowLeftRight },
    { id: 'forecast', label: 'Trợ lý AI Command Center', icon: Lightbulb, note: 'AI' },
    { id: 'reports', label: 'Báo cáo tài chính', icon: FileDown },
    { id: 'more', label: 'Mở rộng', icon: MoreHorizontal },
  ];
  return (
    <>
      {mobileOpen && <button data-testid="button-close-overlay" aria-label="Đóng menu" onClick={onClose} className="fixed inset-0 z-30 hidden bg-foreground/30 md:hidden" />}
      <aside className="hidden w-[260px] shrink-0 flex-col bg-sidebar text-sidebar-foreground md:flex">
        <div className="flex h-[94px] items-center justify-between border-b border-sidebar-border px-7">
          <button data-testid="button-brand" onClick={() => onChange('pos')} className="flex items-center gap-3 text-left">
            <span className="grid h-10 w-10 place-items-center rounded-xl bg-sidebar-primary text-sidebar-primary-foreground"><BrandMark size={40} testId="logo-so-quan-sidebar" /></span>
            <span><span className="brand-wordmark block text-[22px] leading-none"><strong>Resto</strong><span className="brand-ai">.AI</span></span><span className="mt-1 block font-mono text-[9px] uppercase tracking-[.16em] text-sidebar-foreground/60">AI Ops, Maximize Profit</span></span>
          </button>
          <button data-testid="button-close-menu" aria-label="Đóng menu" onClick={onClose} className="hidden rounded-lg p-1 text-sidebar-foreground/70 hover:bg-sidebar-accent md:hidden"><X size={19} /></button>
        </div>
        <div className="px-4 pt-8">
          <p className="px-3 pb-3 font-mono text-[10px] uppercase tracking-[.18em] text-sidebar-foreground/45">Không gian làm việc</p>
          <nav className="space-y-1">
            {links.map(({ id, label, icon: Icon, note }) => { const locked = role !== 'manager' && id !== 'pos'; return <button data-testid={`nav-${id}`} key={id} onClick={() => onChange(id)} className={`flex w-full items-center justify-between rounded-xl px-3 py-3 text-sm transition-colors ${view === id ? 'bg-sidebar-primary font-bold text-sidebar-primary-foreground' : 'text-sidebar-foreground/75 hover:bg-sidebar-accent hover:text-sidebar-foreground'}`}><span className="flex items-center gap-3"><Icon size={18} strokeWidth={view === id ? 2.4 : 1.8} />{label}</span>{locked ? <Lock size={13} className="opacity-60" /> : note && <span className={`rounded-md px-1.5 py-0.5 font-mono text-[10px] ${view === id ? 'bg-sidebar-primary-foreground/20' : 'bg-sidebar-foreground/10'}`}>{note}</span>}</button>; })}
          </nav>
        </div>
        <div className="mt-auto p-4">
          <div className="mb-4 rounded-2xl border border-sidebar-border bg-sidebar-accent/70 p-4">
            <div className="mb-3 flex items-center justify-between"><span className="font-mono text-[10px] uppercase tracking-wider text-sidebar-foreground/55">Mẹo hôm nay</span><span className="h-2 w-2 rounded-full bg-sidebar-primary" /></div>
            <p className="text-xs leading-5 text-sidebar-foreground/80">Kiểm tra rau thơm trước ca tối để tránh thiếu món bán chạy.</p>
          </div>
          <button data-testid="sidebar-forecast-tip" onClick={() => onChange('forecast')} className="flex w-full items-center gap-3 rounded-xl px-3 py-3 text-sm text-sidebar-foreground/70 transition-colors hover:bg-sidebar-accent"><TrendingUp size={18} />Mở Command Center</button>
          <div className="mt-5 flex items-center gap-3 border-t border-sidebar-border px-3 pt-5"><span className="grid h-9 w-9 place-items-center rounded-lg bg-sidebar-foreground/10 font-serif text-sm">MA</span><div><p className="text-xs font-bold">Minh Anh</p><p className="text-[10px] text-sidebar-foreground/55">Chủ quán</p></div><MoreHorizontal size={17} className="ml-auto text-sidebar-foreground/50" /></div>
        </div>
      </aside>
    </>
  );
}

function MobileNav({ view, role, onChange }: { view: View; role: Role; onChange: (view: View) => void }) {
  const links: { id: View; label: string; icon: typeof LayoutDashboard }[] = [
    { id: role === 'manager' ? 'overview' : 'pos', label: role === 'manager' ? 'Tổng quan' : 'Bán hàng', icon: role === 'manager' ? LayoutDashboard : ShoppingBasket },
    { id: 'orders', label: 'Đơn hàng', icon: ClipboardList },
    { id: 'ledger', label: 'Sổ quỹ & kho', icon: ArrowLeftRight },
    { id: 'forecast', label: 'Trợ lý AI', icon: Lightbulb },
    { id: 'more', label: 'Mở rộng', icon: MoreHorizontal },
  ];
  return <nav data-testid="nav-mobile-bottom" aria-label="Điều hướng chính" className="safe-bottom fixed inset-x-0 bottom-0 z-40 flex items-center justify-around border-t border-border/80 bg-card/95 px-2 pt-2 shadow-[0_-10px_28px_rgba(69,53,27,.08)] backdrop-blur-xl md:hidden">
    {links.map(({ id, label, icon: Icon }) => { const locked = role !== 'manager' && id !== 'pos'; return <button data-testid={`mobile-nav-${id}`} aria-current={view === id ? 'page' : undefined} key={id} onClick={() => onChange(id)} className={`flex min-w-0 flex-1 flex-col items-center gap-1 rounded-xl px-1 py-1.5 text-[10px] font-bold transition-colors ${view === id ? 'text-primary' : 'text-muted-foreground'}`}>
      <span className={`grid h-8 w-10 place-items-center rounded-xl transition-colors ${view === id ? 'bg-primary/10' : ''}`}>{locked ? <Lock size={15} /> : <Icon size={18} strokeWidth={view === id ? 2.4 : 1.8} />}</span>
      <span className="truncate">{label}</span>
    </button>; })}
  </nav>;
}

function SectionHeading({ eyebrow, title, action, onAction }: { eyebrow?: string; title: string; action?: string; onAction?: () => void }) {
  return <div className="mb-5 flex items-end justify-between gap-3"><div>{eyebrow && <p className="mb-1 font-mono text-[10px] uppercase tracking-[.18em] text-muted-foreground">{eyebrow}</p>}<h2 className="font-serif text-xl text-foreground md:text-2xl">{title}</h2></div>{action && onAction && <button data-testid={`button-${action}`} onClick={onAction} className="flex items-center gap-1.5 text-xs font-bold text-primary transition-colors hover:text-accent">{action === 'them-giao-dich' ? <Plus size={15} /> : null}{action === 'xem-tat-ca' ? 'Xem tất cả' : 'Thêm giao dịch'}</button>}</div>;
}

function TiltCard({ children, className = '', testId }: { children: ReactNode; className?: string; testId: string }) {
  const cardRef = useRef<HTMLDivElement>(null);
  const frameRef = useRef<number | null>(null);
  const baseStyle = { '--tilt-x': '0deg', '--tilt-y': '0deg', '--glare-x': '50%', '--glare-y': '50%' } as CSSProperties;
  const updateTilt = (clientX: number, clientY: number) => {
    const node = cardRef.current;
    if (!node) return;
    if (frameRef.current) cancelAnimationFrame(frameRef.current);
    frameRef.current = requestAnimationFrame(() => {
      const bounds = node.getBoundingClientRect();
      const percentX = Math.max(0, Math.min(1, (clientX - bounds.left) / bounds.width));
      const percentY = Math.max(0, Math.min(1, (clientY - bounds.top) / bounds.height));
      node.style.setProperty('--tilt-x', `${(0.5 - percentY) * 9}deg`);
      node.style.setProperty('--tilt-y', `${(percentX - 0.5) * 11}deg`);
      node.style.setProperty('--glare-x', `${percentX * 100}%`);
      node.style.setProperty('--glare-y', `${percentY * 100}%`);
      node.classList.add('tilt-active');
    });
  };
  const resetTilt = () => {
    if (frameRef.current) cancelAnimationFrame(frameRef.current);
    const node = cardRef.current;
    if (!node) return;
    node.style.setProperty('--tilt-x', '0deg');
    node.style.setProperty('--tilt-y', '0deg');
    node.style.setProperty('--glare-x', '50%');
    node.style.setProperty('--glare-y', '50%');
    node.classList.remove('tilt-active');
  };
  return <div ref={cardRef} data-testid={testId} style={baseStyle} className={`tilt-card ${className}`} onPointerMove={(event) => updateTilt(event.clientX, event.clientY)} onPointerLeave={resetTilt} onPointerCancel={resetTilt} onPointerUp={resetTilt}>
    <div className="tilt-card-glare" aria-hidden="true" />
    <div className="tilt-card-content">{children}</div>
  </div>;
}

type PosDish = { id: string; name: string; category: string; price: number; accent: string; short: string };

const posDishes: PosDish[] = [
  { id: 'pho-bo', name: 'Phở bò tái', category: 'Món nước', price: 65000, accent: 'from-emerald-100 to-teal-200', short: 'PB' },
  { id: 'pho-ga', name: 'Phở gà', category: 'Món nước', price: 58000, accent: 'from-amber-100 to-orange-200', short: 'PG' },
  { id: 'com-suon', name: 'Cơm sườn nướng', category: 'Món no', price: 72000, accent: 'from-rose-100 to-red-200', short: 'CS' },
  { id: 'bun-cha', name: 'Bún chả Hà Nội', category: 'Món no', price: 68000, accent: 'from-yellow-100 to-lime-200', short: 'BC' },
  { id: 'ca-phe', name: 'Cà phê sữa', category: 'Đồ uống', price: 32000, accent: 'from-stone-200 to-amber-300', short: 'CF' },
  { id: 'tra-sua', name: 'Trà sữa ô long', category: 'Đồ uống', price: 45000, accent: 'from-pink-100 to-fuchsia-200', short: 'TS' },
  { id: 'nuoc-chanh', name: 'Nước chanh tươi', category: 'Đồ uống', price: 28000, accent: 'from-lime-100 to-green-200', short: 'NC' },
  { id: 'banh-flan', name: 'Bánh flan caramel', category: 'Tráng miệng', price: 26000, accent: 'from-orange-100 to-yellow-200', short: 'BF' },
];

function LegacyPosWorkspace({ onCheckout }: { onCheckout: (total: number) => void }) {
  const [cart, setCart] = useState<Record<string, number>>({});
  const cartLines = posDishes.filter((dish) => cart[dish.id]).map((dish) => ({ ...dish, quantity: cart[dish.id] }));
  const total = cartLines.reduce((sum, item) => sum + item.price * item.quantity, 0);
  const itemCount = cartLines.reduce((sum, item) => sum + item.quantity, 0);
  const addToCart = (id: string) => setCart((current) => ({ ...current, [id]: (current[id] ?? 0) + 1 }));
  const updateQuantity = (id: string, quantity: number) => setCart((current) => {
    const next = { ...current };
    if (quantity <= 0) delete next[id];
    else next[id] = quantity;
    return next;
  });
  const checkout = () => {
    if (!total) return;
    onCheckout(total);
    setCart({});
  };
  return <div data-testid="workspace-pos" className="workspace-page space-y-5 md:space-y-6">
    <section className="workspace-hero flex flex-col justify-between gap-4 md:flex-row md:items-end">
      <div><p className="workspace-eyebrow text-primary">Ca bán hàng · Bàn phục vụ</p><h2 className="mt-2 font-serif text-3xl text-foreground md:text-4xl">Bắt đầu một đơn mới</h2><p className="mt-2 text-sm text-muted-foreground">Chạm vào món để thêm nhanh vào giỏ. Màn hình này chỉ dành cho thao tác bán hàng.</p></div>
      <div className="flex items-center gap-2 text-xs font-semibold text-muted-foreground"><span className="h-2 w-2 rounded-full bg-primary" />Đang mở ca · {itemCount} món trong giỏ</div>
    </section>
    <div className="grid items-start gap-5 xl:grid-cols-[minmax(0,1fr)_360px]">
      <section className="workspace-card p-4 md:p-5">
        <div className="mb-4 flex items-center justify-between gap-3"><div><p className="workspace-eyebrow text-muted-foreground">Thực đơn hôm nay</p><h3 className="mt-1 font-serif text-2xl">Danh sách món</h3></div><span className="rounded-full bg-muted px-3 py-1.5 text-xs font-semibold text-muted-foreground">{posDishes.length} món</span></div>
        <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 lg:grid-cols-4">
          {posDishes.map((dish) => <button data-testid={`pos-dish-${dish.id}`} key={dish.id} onClick={() => addToCart(dish.id)} className="pos-dish-card group text-left">
            <span className={`pos-dish-visual bg-gradient-to-br ${dish.accent}`}><span>{dish.short}</span></span>
            <span className="mt-3 block truncate text-sm font-bold text-foreground">{dish.name}</span>
            <span className="mt-1 block text-[11px] text-muted-foreground">{dish.category}</span>
            <span className="mt-3 block font-mono text-sm font-bold text-primary">{money(dish.price)}</span>
          </button>)}
        </div>
      </section>
      <aside data-testid="pos-cart" className="workspace-card overflow-hidden xl:sticky xl:top-24">
        <div className="flex items-center justify-between border-b border-border/70 px-4 py-4 md:px-5"><div><p className="workspace-eyebrow text-primary">Đơn đang chọn</p><h3 className="mt-1 font-serif text-2xl">Giỏ hàng</h3></div><span className="grid h-9 w-9 place-items-center rounded-xl bg-primary/10 text-sm font-bold text-primary">{itemCount}</span></div>
        <div className="max-h-[min(44vh,420px)] overflow-y-auto px-4 md:px-5">
          {cartLines.length === 0 ? <div className="grid min-h-52 place-items-center py-10 text-center"><span className="grid h-12 w-12 place-items-center rounded-2xl bg-muted text-muted-foreground"><ShoppingBasket size={21} /></span><div><p className="mt-3 text-sm font-bold">Chưa có món trong giỏ</p><p className="mt-1 text-xs leading-5 text-muted-foreground">Chọn món ở bên trái để bắt đầu đơn.</p></div></div> : <div className="divide-y divide-border/70">{cartLines.map((item) => <div data-testid={`pos-cart-item-${item.id}`} key={item.id} className="flex items-center gap-3 py-4"><span className={`grid h-10 w-10 shrink-0 place-items-center rounded-xl bg-gradient-to-br text-xs font-black text-slate-700 ${item.accent}`}>{item.short}</span><div className="min-w-0 flex-1"><p className="truncate text-sm font-bold">{item.name}</p><p className="mt-1 font-mono text-xs text-muted-foreground">{money(item.price)}</p></div><div className="flex items-center gap-2"><button aria-label={`Giảm ${item.name}`} onClick={() => updateQuantity(item.id, item.quantity - 1)} className="grid h-7 w-7 place-items-center rounded-lg border border-border text-muted-foreground hover:bg-muted"><Minus size={13} /></button><span className="w-5 text-center font-mono text-sm font-bold">{item.quantity}</span><button aria-label={`Tăng ${item.name}`} onClick={() => updateQuantity(item.id, item.quantity + 1)} className="grid h-7 w-7 place-items-center rounded-lg border border-border text-muted-foreground hover:bg-muted"><Plus size={13} /></button></div></div>)}</div>}
        </div>
        <div className="border-t border-border/70 bg-muted/45 p-4 md:p-5"><div className="flex items-center justify-between text-sm text-muted-foreground"><span>Tạm tính</span><span className="font-mono font-bold text-foreground">{money(total)}</span></div><div className="mt-3 flex items-end justify-between"><span className="text-sm font-bold">Tổng thanh toán</span><span data-testid="pos-cart-total" className="font-mono text-2xl font-bold text-primary">{money(total)}</span></div><button data-testid="button-pos-checkout" onClick={checkout} disabled={!total} className="mt-5 flex h-14 w-full items-center justify-center gap-2 rounded-2xl bg-primary text-base font-black text-primary-foreground shadow-lg shadow-primary/20 transition-transform hover:-translate-y-0.5 disabled:cursor-not-allowed disabled:opacity-45"><CheckCircle2 size={19} />THANH TOÁN</button></div>
      </aside>
    </div>
  </div>;
}

function PosWorkspace({ role, onCheckout, onRequireManagerPin }: { role: Role; onCheckout: (lines: CartLine[], total: number) => void; onRequireManagerPin: () => void }) {
  const [cart, setCart] = useState<CartLine[]>([]);
  const [selectedDish, setSelectedDish] = useState<MenuDish | null>(null);
  const [selectedVariantId, setSelectedVariantId] = useState('');
  const [selectedModifierIds, setSelectedModifierIds] = useState<string[]>([]);
  const [note, setNote] = useState('');
  const [discountPercent, setDiscountPercent] = useState(0);
  const cartTotal = cart.reduce((sum, item) => sum + item.unitPrice * item.quantity, 0);
  const itemCount = cart.reduce((sum, item) => sum + item.quantity, 0);
  const openDish = (dish: MenuDish) => {
    setSelectedDish(dish);
    setSelectedVariantId(dish.variants[0]?.id ?? '');
    setSelectedModifierIds([]);
    setNote('');
  };
  const addConfiguredDish = () => {
    if (!selectedDish) return;
    const variant = selectedDish.variants.find((item) => item.id === selectedVariantId) ?? selectedDish.variants[0];
    if (!variant) return;
    const modifiers = selectedDish.modifiers.filter((item) => selectedModifierIds.includes(item.id));
    const bom = [...selectedDish.baseBom, ...variant.bom, ...modifiers.flatMap((item) => item.bom)];
    const line: CartLine = {
      id: uid('line'),
      dishId: selectedDish.id,
      name: selectedDish.name,
      variant,
      modifiers,
      note,
      quantity: 1,
      unitPrice: selectedDish.basePrice + variant.priceDelta + modifiers.reduce((sum, item) => sum + item.price, 0),
      accent: selectedDish.accent,
      short: selectedDish.short,
      bom,
    };
    setCart((current) => [...current, line]);
    setSelectedDish(null);
  };
  const updateLine = (id: string, quantity: number) => setCart((current) => quantity <= 0 ? current.filter((item) => item.id !== id) : current.map((item) => item.id === id ? { ...item, quantity } : item));
  const checkout = () => {
    if (!cart.length || !cartTotal) return;
    onCheckout(cart, Math.round(cartTotal * (1 - discountPercent / 100)));
    setCart([]);
    setDiscountPercent(0);
  };
  return <div data-testid="workspace-pos" className="workspace-page space-y-5 md:space-y-6">
    <section className="workspace-hero flex flex-col justify-between gap-4 md:flex-row md:items-end">
      <div><p className="workspace-eyebrow text-primary">Staff Mode · Bán hàng nhanh</p><h2 className="mt-2 font-serif text-3xl text-foreground md:text-4xl">Tạo đơn mới</h2><p className="mt-2 text-sm text-muted-foreground">Chọn món, size, topping và ghi chú phục vụ. Định lượng BOM sẽ được trừ kho khi thanh toán.</p></div>
      <div className="flex items-center gap-2 text-xs font-semibold text-muted-foreground"><span className="h-2 w-2 rounded-full bg-primary" />{itemCount} món · {cart.length} dòng hàng</div>
    </section>
    <div className="grid items-start gap-5 xl:grid-cols-[minmax(0,1fr)_380px]">
      <section className="workspace-card p-4 md:p-5">
        <div className="mb-4 flex items-center justify-between gap-3"><div><p className="workspace-eyebrow text-muted-foreground">Menu có định lượng</p><h3 className="mt-1 font-serif text-2xl">Chọn món</h3></div><span className="rounded-full bg-muted px-3 py-1.5 text-xs font-semibold text-muted-foreground">{menuDishes.length} món</span></div>
        <div className="grid grid-cols-2 gap-3 sm:grid-cols-3">
          {menuDishes.map((dish) => <button data-testid={`pos-dish-${dish.id}`} key={dish.id} onClick={() => openDish(dish)} className="pos-dish-card group text-left">
            <span className={`pos-dish-visual bg-gradient-to-br ${dish.accent}`}><span>{dish.short}</span></span>
            <span className="mt-3 block truncate text-sm font-bold text-foreground">{dish.name}</span>
            <span className="mt-1 block text-[11px] text-muted-foreground">{dish.category}</span>
            <span className="mt-3 block font-mono text-sm font-bold text-primary">Từ {money(dish.basePrice)}</span>
          </button>)}
        </div>
      </section>
      <aside data-testid="pos-cart" className="workspace-card overflow-hidden xl:sticky xl:top-24">
        <div className="flex items-center justify-between border-b border-border/70 px-4 py-4 md:px-5"><div><p className="workspace-eyebrow text-primary">Đơn đang chọn</p><h3 className="mt-1 font-serif text-2xl">Giỏ hàng</h3></div><span className="grid h-9 w-9 place-items-center rounded-xl bg-primary/10 text-sm font-bold text-primary">{itemCount}</span></div>
        <div className="max-h-[min(44vh,420px)] overflow-y-auto px-4 md:px-5">
          {cart.length === 0 ? <div className="grid min-h-52 place-items-center py-10 text-center"><span className="grid h-12 w-12 place-items-center rounded-2xl bg-muted text-muted-foreground"><ShoppingBasket size={21} /></span><div><p className="mt-3 text-sm font-bold">Chưa có món trong giỏ</p><p className="mt-1 text-xs leading-5 text-muted-foreground">Chọn món để mở tuỳ chỉnh size và topping.</p></div></div> : <div className="divide-y divide-border/70">{cart.map((item) => <div data-testid={`pos-cart-item-${item.id}`} key={item.id} className="flex items-start gap-3 py-4"><span className={`grid h-10 w-10 shrink-0 place-items-center rounded-xl bg-gradient-to-br text-xs font-black text-slate-700 ${item.accent}`}>{item.short}</span><div className="min-w-0 flex-1"><p className="truncate text-sm font-bold">{item.name}</p><p className="mt-1 text-[11px] text-muted-foreground">{item.variant.label}{item.modifiers.length ? ` · ${item.modifiers.map((modifier) => modifier.label).join(', ')}` : ''}</p>{item.note && <p className="mt-1 truncate text-[11px] italic text-muted-foreground">“{item.note}”</p>}<p className="mt-2 font-mono text-xs font-bold text-primary">{money(item.unitPrice)}</p></div><div className="flex items-center gap-1.5"><button aria-label={`Giảm ${item.name}`} onClick={() => updateLine(item.id, item.quantity - 1)} className="grid h-7 w-7 place-items-center rounded-lg border border-border text-muted-foreground hover:bg-muted"><Minus size={13} /></button><span className="w-4 text-center font-mono text-sm font-bold">{item.quantity}</span><button aria-label={`Tăng ${item.name}`} onClick={() => updateLine(item.id, item.quantity + 1)} className="grid h-7 w-7 place-items-center rounded-lg border border-border text-muted-foreground hover:bg-muted"><Plus size={13} /></button></div></div>)}</div>}
        </div>
        <div className="border-t border-border/70 bg-muted/45 p-4 md:p-5"><div className="flex items-center justify-between text-sm text-muted-foreground"><span>Tạm tính</span><span className="font-mono font-bold text-foreground">{money(cartTotal)}</span></div><button data-testid="button-deep-discount" disabled={!cart.length} onClick={() => role === 'manager' ? setDiscountPercent((current) => current ? 0 : 20) : onRequireManagerPin()} className="mt-3 flex w-full items-center justify-between rounded-xl border border-border bg-card px-3 py-2.5 text-xs font-bold text-muted-foreground disabled:cursor-not-allowed disabled:opacity-45"><span className="flex items-center gap-2"><SlidersHorizontal size={14} />{discountPercent ? `Đang giảm ${discountPercent}%` : 'Giảm giá sâu'}</span><span>{role === 'manager' ? (discountPercent ? 'Bỏ giảm' : 'Manager') : 'PIN'}</span></button>{discountPercent > 0 && <div className="mt-2 flex items-center justify-between text-xs text-accent"><span>Ưu đãi Manager</span><span className="font-mono font-bold">-{money(cartTotal - Math.round(cartTotal * (1 - discountPercent / 100)))}</span></div>}<div className="mt-3 flex items-end justify-between"><span className="text-sm font-bold">Tổng thanh toán</span><span data-testid="pos-cart-total" className="font-mono text-2xl font-bold text-primary">{money(Math.round(cartTotal * (1 - discountPercent / 100)))}</span></div><button data-testid="button-pos-checkout" onClick={checkout} disabled={!cart.length} className="mt-5 flex h-14 w-full items-center justify-center gap-2 rounded-2xl bg-primary text-base font-black text-primary-foreground shadow-lg shadow-primary/20 transition-transform hover:-translate-y-0.5 disabled:cursor-not-allowed disabled:opacity-45"><CheckCircle2 size={19} />THANH TOÁN</button></div>
      </aside>
    </div>
    {selectedDish && <div data-testid="pos-configurator" className="fixed inset-0 z-50 grid place-items-end bg-foreground/35 p-3 backdrop-blur-sm md:place-items-center"><div role="dialog" aria-modal="true" className="w-full max-w-lg rounded-3xl border border-border bg-card p-5 shadow-2xl md:p-6"><div className="flex items-start justify-between gap-3"><div><p className="workspace-eyebrow text-primary">Tuỳ chỉnh món</p><h3 className="mt-1 font-serif text-2xl">{selectedDish.name}</h3></div><button aria-label="Đóng tuỳ chỉnh" onClick={() => setSelectedDish(null)} className="rounded-xl p-2 text-muted-foreground hover:bg-muted"><X size={18} /></button></div><div className="mt-5"><p className="text-xs font-bold text-muted-foreground">Kích cỡ / định lượng</p><div className="mt-2 grid grid-cols-2 gap-2">{selectedDish.variants.map((variant) => <button data-testid={`pos-variant-${variant.id}`} key={variant.id} onClick={() => setSelectedVariantId(variant.id)} className={`rounded-xl border p-3 text-left ${selectedVariantId === variant.id ? 'border-primary bg-primary/10 text-primary' : 'border-border hover:bg-muted'}`}><span className="block text-sm font-bold">{variant.label}</span><span className="mt-1 block font-mono text-xs">{variant.priceDelta ? `+${money(variant.priceDelta)}` : 'Giá cơ bản'}</span></button>)}</div></div><div className="mt-5"><p className="text-xs font-bold text-muted-foreground">Topping / modifier</p><div className="mt-2 space-y-2">{selectedDish.modifiers.map((modifier) => <label key={modifier.id} className="flex cursor-pointer items-center gap-3 rounded-xl border border-border p-3 hover:bg-muted"><input data-testid={`pos-modifier-${modifier.id}`} type="checkbox" checked={selectedModifierIds.includes(modifier.id)} onChange={() => setSelectedModifierIds((current) => current.includes(modifier.id) ? current.filter((id) => id !== modifier.id) : [...current, modifier.id])} className="h-4 w-4 accent-[hsl(var(--primary))]" /><span className="flex-1 text-sm font-semibold">{modifier.label}</span><span className="font-mono text-xs text-muted-foreground">+{money(modifier.price)}</span></label>)}</div></div><label className="mt-5 block text-xs font-bold text-muted-foreground">Ghi chú phục vụ<textarea data-testid="pos-order-note" value={note} onChange={(event) => setNote(event.target.value)} placeholder="Ví dụ: Ít đá, nhiều đường" className="mt-2 min-h-20 w-full resize-none rounded-xl border border-input bg-background p-3 text-sm outline-none focus:border-primary" /></label><button data-testid="button-add-configured-dish" onClick={addConfiguredDish} className="mt-5 flex h-12 w-full items-center justify-center gap-2 rounded-xl bg-primary font-bold text-primary-foreground"><Plus size={17} />Thêm vào giỏ</button></div></div>}
  </div>;
}

function LegacyLedgerWorkspace({ transactions, ingredients, onAddTransaction, onEditTransaction, onDeleteTransaction, onAddIngredient, onAdjustIngredient, onToggleLow }: { transactions: Transaction[]; ingredients: Ingredient[]; onAddTransaction: () => void; onEditTransaction: (item: Transaction) => void; onDeleteTransaction: (id: string) => void; onAddIngredient: () => void; onAdjustIngredient: (item: Ingredient) => void; onToggleLow: (id: string) => void }) {
  const [range, setRange] = useState<'day' | 'week' | 'month'>('day');
  const filtered = useMemo(() => {
    const now = new Date(`${today}T12:00:00`);
    const start = new Date(now);
    if (range === 'week') start.setDate(start.getDate() - 6);
    if (range === 'month') start.setDate(start.getDate() - 29);
    return transactions.filter((item) => {
      const date = new Date(`${item.date}T12:00:00`);
      return date >= start && date <= now;
    });
  }, [range, transactions]);
  const revenue = filtered.filter((item) => item.type === 'thu').reduce((sum, item) => sum + item.amount, 0);
  const expense = filtered.filter((item) => item.type === 'chi').reduce((sum, item) => sum + item.amount, 0);
  const lowStock = ingredients.filter((item) => item.current < item.minimum);
  return <div data-testid="workspace-ledger" className="workspace-page space-y-5 md:space-y-6">
    <section className="workspace-hero flex flex-col justify-between gap-4 md:flex-row md:items-end"><div><p className="workspace-eyebrow text-secondary-foreground">Quản lý vận hành</p><h2 className="mt-2 font-serif text-3xl text-foreground md:text-4xl">Sổ quỹ & kho</h2><p className="mt-2 text-sm text-muted-foreground">Theo dõi dòng tiền và tồn kho trong cùng một không gian dành cho chủ quán.</p></div><button data-testid="button-add-ledger-transaction" onClick={onAddTransaction} className="flex w-fit items-center gap-2 rounded-xl bg-primary px-4 py-3 text-sm font-bold text-primary-foreground shadow-sm"><Plus size={16} />Thêm khoản thu/chi</button></section>
    <section className="grid gap-3 sm:grid-cols-3"><div className="workspace-metric border-primary/20"><span className="workspace-metric-icon bg-primary/10 text-primary"><ArrowUpRight size={17} /></span><p className="mt-4 text-xs text-muted-foreground">Khoản thu</p><p data-testid="ledger-revenue-total" className="mt-1 font-mono text-2xl font-bold text-primary">{money(revenue)}</p></div><div className="workspace-metric border-accent/25"><span className="workspace-metric-icon bg-accent/10 text-accent"><ArrowDownRight size={17} /></span><p className="mt-4 text-xs text-muted-foreground">Khoản chi</p><p data-testid="ledger-expense-total" className="mt-1 font-mono text-2xl font-bold text-accent">{money(expense)}</p></div><div className="workspace-metric"><span className="workspace-metric-icon bg-secondary text-secondary-foreground"><Boxes size={17} /></span><p className="mt-4 text-xs text-muted-foreground">Cần nhập kho</p><p data-testid="ledger-low-stock-total" className="mt-1 font-mono text-2xl font-bold">{lowStock.length} <span className="text-sm font-semibold text-muted-foreground">mặt hàng</span></p></div></section>
    <section className="workspace-card overflow-hidden"><div className="flex flex-col gap-3 border-b border-border/70 p-4 md:flex-row md:items-center md:justify-between md:px-5"><div><p className="workspace-eyebrow text-muted-foreground">Dòng tiền</p><h3 className="mt-1 font-serif text-2xl">Lịch sử thu & chi</h3></div><div className="flex w-full rounded-xl bg-muted p-1 md:w-auto">{(['day', 'week', 'month'] as const).map((item) => <button data-testid={`ledger-filter-${item}`} key={item} onClick={() => setRange(item)} className={`flex-1 rounded-lg px-3 py-2 text-xs font-bold md:flex-none ${range === item ? 'bg-card text-foreground shadow-sm' : 'text-muted-foreground'}`}>{item === 'day' ? 'Hôm nay' : item === 'week' ? '7 ngày' : '30 ngày'}</button>)}</div></div><div className="overflow-x-auto"><TransactionTable transactions={filtered} onEdit={onEditTransaction} onDelete={onDeleteTransaction} /></div></section>
    <section className="workspace-card overflow-hidden"><div className="flex items-center justify-between border-b border-border/70 p-4 md:px-5"><div><p className="workspace-eyebrow text-muted-foreground">Quản lý nguyên liệu</p><h3 className="mt-1 font-serif text-2xl">Tồn kho hiện tại</h3></div><button data-testid="button-add-ledger-ingredient" onClick={onAddIngredient} className="flex items-center gap-1.5 rounded-xl border border-border px-3 py-2 text-xs font-bold text-primary hover:bg-muted"><Plus size={14} />Thêm nguyên liệu</button></div><div className="grid gap-3 p-4 md:grid-cols-2 md:p-5 xl:grid-cols-3">{ingredients.map((item) => { const low = item.current < item.minimum; return <article data-testid={`ledger-stock-${item.id}`} key={item.id} className="flex items-center gap-3 rounded-2xl border border-border/70 bg-background/55 p-3"><span className={`grid h-10 w-10 shrink-0 place-items-center rounded-xl ${low ? 'bg-accent/10 text-accent' : 'bg-secondary text-secondary-foreground'}`}><ShoppingBasket size={16} /></span><div className="min-w-0 flex-1"><p className="truncate text-sm font-bold">{item.name}</p><p className="mt-1 font-mono text-xs text-muted-foreground">{item.current} {item.unit} · min {item.minimum} {item.unit}</p><div className="mt-2 h-1.5 overflow-hidden rounded-full bg-muted"><span className={`block h-full rounded-full ${low ? 'bg-accent' : 'bg-primary'}`} style={{ width: `${Math.min(100, (item.current / Math.max(item.minimum, 1)) * 100)}%` }} /></div></div><div className="flex flex-col items-end gap-2"><span className={`rounded-full px-2 py-1 text-[10px] font-bold ${low ? 'bg-accent/10 text-accent' : 'bg-primary/10 text-primary'}`}>{low ? 'Cần nhập' : 'Đủ dùng'}</span><button data-testid={`button-ledger-adjust-${item.id}`} onClick={() => onAdjustIngredient(item)} className="text-[11px] font-bold text-primary hover:underline">Điều chỉnh</button></div></article>; })}</div></section>
  </div>;
}

function IngredientDetailsModal({ ingredient, onClose }: { ingredient: Ingredient; onClose: () => void }) {
  const history = priceHistoryForIngredient(ingredient);
  const maxPrice = Math.max(...history.map((item) => item.price), 1);
  const change = priceChangePercent(ingredient);
  const supplier = supplierForIngredient(ingredient);
  return <ModalFrame title={`Chi tiết giá · ${ingredient.name}`} subtitle={`${supplier} · cập nhật ${dateLabel(ingredient.updated)}`} onClose={onClose}>
    <div data-testid={`ingredient-price-detail-${ingredient.id}`} className="space-y-5">
      <div className={`rounded-2xl border p-4 ${change > 5 ? 'border-destructive/25 bg-destructive/5' : 'border-primary/20 bg-primary/5'}`}>
        <div className="flex items-start gap-3"><span className={`grid h-10 w-10 shrink-0 place-items-center rounded-xl ${change > 5 ? 'bg-destructive/10 text-destructive' : 'bg-primary/10 text-primary'}`}><TrendingUp size={17} /></span><div><p className="text-sm font-bold">{change > 5 ? `Nhà cung cấp ${supplier} vừa tăng giá ${change}% so với tháng trước` : 'Giá nhập đang trong vùng ổn định'}</p><p className="mt-1 text-xs leading-5 text-muted-foreground">Giá hiện tại <span className="font-mono font-bold text-foreground">{money(ingredient.price)}/{ingredient.unit}</span></p></div></div>
      </div>
      <div className="rounded-2xl border border-border/70 bg-background/55 p-4">
        <div className="flex items-center justify-between"><div><p className="workspace-eyebrow text-muted-foreground">Supplier price tracker</p><h3 className="mt-1 font-serif text-xl">Lịch sử giá nhập</h3></div><History size={18} className="text-primary" /></div>
        <div className="mt-5 flex h-44 items-end gap-3 border-b border-border/70 px-1 pb-0">
          {history.map((point) => <div key={`${point.date}-${point.price}`} className="flex min-w-0 flex-1 flex-col items-center justify-end gap-2"><span className="font-mono text-[10px] font-bold text-foreground">{compactMoney(point.price)}</span><div className={`w-full max-w-12 rounded-t-lg ${point === history.at(-1) ? 'bg-primary' : 'bg-secondary-foreground/25'}`} style={{ height: `${Math.max(16, (point.price / maxPrice) * 112)}px` }} /><span className="max-w-20 truncate text-[10px] text-muted-foreground">{point.date}</span></div>)}
        </div>
        <p className="mt-4 text-xs leading-5 text-muted-foreground">Theo dõi chênh lệch từng đợt nhập để chọn thời điểm mua và nhà cung cấp phù hợp hơn.</p>
      </div>
    </div>
  </ModalFrame>;
}

function LedgerWorkspace({ role, transactions, ingredients, fixedCosts, onAddTransaction, onEditTransaction, onDeleteTransaction, onAddIngredient, onAdjustIngredient, onViewIngredient, onToggleLow, onSaveStocktake, onAddFixedCost, onStocktakeAlert }: { role: Role; transactions: Transaction[]; ingredients: Ingredient[]; fixedCosts: FixedCost[]; onAddTransaction: () => void; onEditTransaction: (item: Transaction) => void; onDeleteTransaction: (id: string) => void; onAddIngredient: () => void; onAdjustIngredient: (item: Ingredient) => void; onViewIngredient: (item: Ingredient) => void; onToggleLow: (id: string) => void; onSaveStocktake: (id: string, amount: number) => void; onAddFixedCost: () => void; onStocktakeAlert: (name: string, variance: number) => void }) {
  const [range, setRange] = useState<'day' | 'week' | 'month'>('month');
  const [stocktake, setStocktake] = useState<Record<string, string>>({});
  const now = new Date(`${today}T12:00:00`);
  const filtered = useMemo(() => {
    const start = new Date(now);
    if (range === 'week') start.setDate(start.getDate() - 6);
    if (range === 'month') start.setDate(start.getDate() - 29);
    return transactions.filter((item) => {
      const date = new Date(`${item.date}T12:00:00`);
      return date >= start && date <= now;
    });
  }, [range, transactions]);
  const revenue = filtered.filter((item) => item.type === 'thu').reduce((sum, item) => sum + item.amount, 0);
  const ingredientExpense = filtered.filter((item) => item.type === 'chi' && item.category === 'Nguyên liệu').reduce((sum, item) => sum + item.amount, 0);
  const otherExpense = filtered.filter((item) => item.type === 'chi' && item.category !== 'Nguyên liệu').reduce((sum, item) => sum + item.amount, 0);
  const grossProfit = revenue - ingredientExpense;
  const fixedCostTotal = fixedCosts.reduce((sum, item) => sum + item.amount, 0);
  const netProfit = grossProfit - otherExpense - fixedCostTotal;
  const stockStatus = (item: Ingredient) => {
    const ratio = item.current / Math.max(item.minimum, 0.01);
    if (ratio < .65) return { label: 'Nguy hiểm', tone: 'danger' };
    if (ratio < 1) return { label: 'Sắp hết', tone: 'watch' };
    return { label: 'An toàn', tone: 'safe' };
  };
  const submitStocktake = (item: Ingredient) => {
    const actual = Number(stocktake[item.id]);
    if (!Number.isFinite(actual) || actual < 0) return;
    const variance = Math.abs(actual - item.current) / Math.max(item.current, .01);
    if (variance > .1) onStocktakeAlert(item.name, Math.round(variance * 100));
    onSaveStocktake(item.id, actual);
    setStocktake((current) => ({ ...current, [item.id]: '' }));
  };
  const toneClass = (tone: string) => tone === 'danger' ? 'bg-destructive/10 text-destructive' : tone === 'watch' ? 'bg-amber-500/12 text-amber-700' : 'bg-primary/10 text-primary';
  return <div data-testid="workspace-ledger" className="workspace-page space-y-5 md:space-y-6">
    <OperationsFilterBar label="Sổ quỹ & kho · Bộ lọc thời gian" onPeriodChange={(period) => setRange(period === 'Tuần này' ? 'week' : period === 'Tháng này' ? 'month' : 'day')} />
    <section className="workspace-hero flex flex-col justify-between gap-4 md:flex-row md:items-end"><div><p className="workspace-eyebrow text-secondary-foreground">Manager Mode · Data Core</p><h2 className="mt-2 font-serif text-3xl text-foreground md:text-4xl">Sổ quỹ & kho</h2><p className="mt-2 text-sm text-muted-foreground">Gross Profit, Net Profit và tồn kho lý thuyết trong một màn hình vận hành.</p></div><div className="flex flex-wrap gap-2"><button data-testid="button-add-fixed-cost" onClick={onAddFixedCost} className="flex items-center gap-2 rounded-xl border border-border bg-card px-3 py-3 text-xs font-bold text-foreground"><SlidersHorizontal size={15} />Thêm chi phí cố định</button><button data-testid="button-add-ledger-transaction" onClick={onAddTransaction} className="flex items-center gap-2 rounded-xl bg-primary px-4 py-3 text-sm font-bold text-primary-foreground shadow-sm"><Plus size={16} />Thêm khoản thu/chi</button></div></section>
    <section className="grid gap-3 sm:grid-cols-2 xl:grid-cols-4"><div className="workspace-metric border-primary/20"><span className="workspace-metric-icon bg-primary/10 text-primary"><ArrowUpRight size={17} /></span><p className="mt-4 text-xs text-muted-foreground">Doanh thu</p><p data-testid="ledger-revenue-total" className="mt-1 font-mono text-2xl font-bold text-primary">{money(revenue)}</p></div><div className="workspace-metric border-primary/20"><span className="workspace-metric-icon bg-primary/10 text-primary"><TrendingUp size={17} /></span><p className="mt-4 text-xs text-muted-foreground">Gross Profit</p><p data-testid="ledger-gross-profit" className="mt-1 font-mono text-2xl font-bold text-primary">{money(grossProfit)}</p></div><div className="workspace-metric border-secondary"><span className="workspace-metric-icon bg-secondary text-secondary-foreground"><CircleDollarSign size={17} /></span><p className="mt-4 text-xs text-muted-foreground">Chi phí cố định</p><p data-testid="ledger-fixed-cost-total" className="mt-1 font-mono text-2xl font-bold">{money(fixedCostTotal)}</p></div><div className={`workspace-metric ${netProfit < 0 ? 'border-destructive/25' : 'border-primary/20'}`}><span className={`workspace-metric-icon ${netProfit < 0 ? 'bg-destructive/10 text-destructive' : 'bg-primary/10 text-primary'}`}><CircleDollarSign size={17} /></span><p className="mt-4 text-xs text-muted-foreground">Net Profit</p><p data-testid="ledger-net-profit" className={`mt-1 font-mono text-2xl font-bold ${netProfit < 0 ? 'text-destructive' : 'text-primary'}`}>{money(netProfit)}</p></div></section>
    <section className="workspace-card overflow-hidden"><div className="flex flex-col gap-3 border-b border-border/70 p-4 md:flex-row md:items-center md:justify-between md:px-5"><div><p className="workspace-eyebrow text-muted-foreground">Dòng tiền</p><h3 className="mt-1 font-serif text-2xl">Sổ quỹ Thu & Chi</h3></div><div className="flex w-full rounded-xl bg-muted p-1 md:w-auto">{(['day', 'week', 'month'] as const).map((item) => <button data-testid={`ledger-filter-${item}`} key={item} onClick={() => setRange(item)} className={`flex-1 rounded-lg px-3 py-2 text-xs font-bold md:flex-none ${range === item ? 'bg-card text-foreground shadow-sm' : 'text-muted-foreground'}`}>{item === 'day' ? 'Ngày' : item === 'week' ? 'Tuần' : 'Tháng'}</button>)}</div></div><div className="overflow-x-auto"><TransactionTable transactions={filtered} onEdit={onEditTransaction} onDelete={onDeleteTransaction} /></div></section>
    <section className="grid gap-5 xl:grid-cols-[.7fr_1.3fr]"><div className="workspace-card p-4 md:p-5"><div className="flex items-center justify-between"><div><p className="workspace-eyebrow text-muted-foreground">Fixed costs</p><h3 className="mt-1 font-serif text-2xl">Chi phí định kỳ</h3></div><span className="rounded-full bg-muted px-2.5 py-1 text-[10px] font-bold">{fixedCosts.length} khoản</span></div><div className="mt-4 divide-y divide-border/70">{fixedCosts.map((cost) => <div key={cost.id} className="flex items-center justify-between gap-3 py-3 first:pt-0"><span className="text-sm font-semibold">{cost.name}<span className="ml-2 text-[10px] font-normal text-muted-foreground">/{cost.frequency}</span></span><span className="font-mono text-sm font-bold">{money(cost.amount)}</span></div>)}</div></div><div className="workspace-card overflow-hidden"><div className="flex items-center justify-between border-b border-border/70 p-4 md:px-5"><div><p className="workspace-eyebrow text-muted-foreground">Inventory control</p><h3 className="mt-1 font-serif text-2xl">Kiểm kho cuối ngày</h3></div><div className="flex gap-2"><button data-testid="button-add-ledger-ingredient" onClick={onAddIngredient} className="flex items-center gap-1.5 rounded-xl border border-border px-3 py-2 text-xs font-bold text-primary hover:bg-muted"><Plus size={14} />Nguyên liệu</button><span className="hidden items-center gap-1 text-[10px] font-semibold text-muted-foreground sm:flex"><ClipboardCheck size={14} />Sai lệch &gt;10% sẽ cảnh báo AI</span></div></div><div className="grid gap-3 p-4 md:grid-cols-2 md:p-5">{ingredients.map((item) => { const status = stockStatus(item); const supplier = supplierForIngredient(item); const priceChange = priceChangePercent(item); return <article data-testid={`ledger-stock-${item.id}`} key={item.id} className="rounded-2xl border border-border/70 bg-background/55 p-3"><div className="flex items-start gap-3"><span className={`grid h-10 w-10 shrink-0 place-items-center rounded-xl ${toneClass(status.tone)}`}><ShoppingBasket size={16} /></span><div className="min-w-0 flex-1"><div className="flex items-center justify-between gap-2"><p className="truncate text-sm font-bold">{item.name}</p><span className={`rounded-full px-2 py-1 text-[10px] font-bold ${toneClass(status.tone)}`}>{status.label}</span></div><p className="mt-1 font-mono text-xs text-muted-foreground">Lý thuyết {item.current} {item.unit} · min {item.minimum} {item.unit}</p><p className="mt-1 truncate text-[10px] text-muted-foreground">{supplier} · {priceChange > 5 ? `Tăng ${priceChange}% so với tháng trước` : 'Giá ổn định'}</p></div></div><div className="mt-3 flex items-center gap-2"><input data-testid={`input-stocktake-${item.id}`} type="number" min="0" step="0.1" value={stocktake[item.id] ?? ''} onChange={(event) => setStocktake((current) => ({ ...current, [item.id]: event.target.value }))} placeholder={`Kiểm thực tế (${item.unit})`} className="h-9 min-w-0 flex-1 rounded-lg border border-input bg-background px-2 text-xs outline-none focus:border-primary" /><button data-testid={`button-price-history-${item.id}`} onClick={() => onViewIngredient(item)} className="rounded-lg border border-border px-2.5 py-2 text-[11px] font-bold text-primary hover:bg-primary/5"><History size={13} />Giá</button><button data-testid={`button-stocktake-${item.id}`} onClick={() => submitStocktake(item)} className="rounded-lg bg-secondary px-3 py-2 text-xs font-bold text-secondary-foreground hover:bg-primary/15 hover:text-primary">Đối chiếu</button></div></article>; })}</div></div></section>
  </div>;
}

function LegacyForecastWorkspace({ forecast, history, runs, ingredients, transactions, mlForecast, mlForecastLoading, mlForecastError, onMlForecast, onRefresh, onAdjust, onConfirm }: { forecast: ForecastRun; history: SalesDay[]; runs: ForecastRun[]; ingredients: Ingredient[]; transactions: Transaction[]; mlForecast: MlForecast | null; mlForecastLoading: boolean; mlForecastError: string; onMlForecast: (request: PredictRequest) => Promise<void>; onRefresh: () => void; onAdjust: (id: string, quantity: number) => void; onConfirm: (item: ForecastRecommendation) => void }) {
  const fallbackShopping = ingredients.filter((item) => item.current < item.minimum).map((item) => ({ ...item, to_buy: Number((item.minimum - item.current).toFixed(1)) }));
  const shopping = mlForecast?.shopping_list.filter((item) => item.to_buy > 0) ?? fallbackShopping;
  const totalServings = forecast.dishes.reduce((sum, item) => sum + item.servings, 0);
  const expectedRevenue = totalServings * 62000;
  const topDish = [...forecast.dishes].sort((a, b) => b.servings - a.servings)[0];
  const revenueBaseline = transactions.filter((item) => item.type === 'thu').reduce((sum, item) => sum + item.amount, 0);
  return <div data-testid="workspace-forecast" className="workspace-page space-y-5 md:space-y-6">
    <section className="workspace-hero forecast-workspace-hero flex flex-col justify-between gap-4 md:flex-row md:items-end"><div><p className="workspace-eyebrow text-primary">Command center · {dateLabel(forecast.targetDate)}</p><h2 className="mt-2 max-w-3xl font-serif text-3xl text-foreground md:text-5xl">Biết ngày mai bán gì trước khi mở cửa.</h2><p className="mt-3 max-w-2xl text-sm leading-6 text-muted-foreground">AI Forecast gom dữ liệu bán hàng, thời tiết và tồn kho để biến dự báo thành quyết định nhập hàng rõ ràng.</p></div><button data-testid="button-command-refresh" onClick={onRefresh} className="flex w-fit items-center gap-2 rounded-xl bg-primary px-4 py-3 text-sm font-bold text-primary-foreground shadow-lg shadow-primary/15"><RefreshCw size={16} />Cập nhật dự báo</button></section>
    <section className="grid gap-4 xl:grid-cols-3"><article data-testid="forecast-kpi-revenue" className="forecast-kpi border-primary/20 bg-primary text-primary-foreground"><div className="flex items-start justify-between"><span className="grid h-10 w-10 place-items-center rounded-xl bg-primary-foreground/12"><TrendingUp size={19} /></span><span className="rounded-full bg-primary-foreground/12 px-2.5 py-1 text-[10px] font-bold">Ngày mai</span></div><p className="mt-8 text-sm text-primary-foreground/70">Doanh thu dự kiến</p><p className="mt-1 font-mono text-3xl font-bold">{money(expectedRevenue)}</p><p className="mt-2 text-xs text-primary-foreground/70">Dựa trên {totalServings} suất dự báo · mốc hiện tại {money(revenueBaseline)}</p></article><article data-testid="forecast-kpi-shopping" className="forecast-kpi border-accent/25 bg-card"><div className="flex items-start justify-between"><span className="grid h-10 w-10 place-items-center rounded-xl bg-accent/10 text-accent"><ShoppingBasket size={19} /></span><span className="rounded-full bg-accent/10 px-2.5 py-1 text-[10px] font-bold text-accent">{shopping.length} mục</span></div><p className="mt-8 text-sm text-muted-foreground">Lời khuyên đi chợ</p><p className="mt-1 font-serif text-2xl">{shopping.length ? 'Mua đủ, không mua dư' : 'Kho đang đủ dùng'}</p><p className="mt-2 truncate text-xs text-muted-foreground">{shopping.length ? shopping.slice(0, 2).map((item) => item.name).join(' · ') : 'Chưa có nguyên liệu dưới ngưỡng.'}</p></article><article data-testid="forecast-kpi-trend" className="forecast-kpi border-secondary bg-card"><div className="flex items-start justify-between"><span className="grid h-10 w-10 place-items-center rounded-xl bg-secondary text-secondary-foreground"><ArrowUpRight size={19} /></span><span className="rounded-full bg-secondary px-2.5 py-1 text-[10px] font-bold text-secondary-foreground">Top trend</span></div><p className="mt-8 text-sm text-muted-foreground">Xu hướng bán chạy</p><p className="mt-1 font-serif text-2xl">{topDish?.name ?? 'Chưa có dữ liệu'}</p><p className="mt-2 font-mono text-xs text-muted-foreground">{topDish?.servings ?? 0} suất · độ tin cậy {forecast.confidence}%</p></article></section>
    <ForecastView forecast={forecast} history={history} runs={runs} ingredients={ingredients} mlForecast={mlForecast} mlForecastLoading={mlForecastLoading} mlForecastError={mlForecastError} onMlForecast={onMlForecast} onRefresh={onRefresh} onAdjust={onAdjust} onConfirm={onConfirm} />
  </div>;
}

function LegacyCommandForecastWorkspace({ forecast, history, runs, ingredients, transactions, mlForecast, mlForecastLoading, mlForecastError, onMlForecast, onRefresh, onAdjust, onConfirm, onAction }: { forecast: ForecastRun; history: SalesDay[]; runs: ForecastRun[]; ingredients: Ingredient[]; transactions: Transaction[]; mlForecast: MlForecast | null; mlForecastLoading: boolean; mlForecastError: string; onMlForecast: (request: PredictRequest) => Promise<void>; onRefresh: () => void; onAdjust: (id: string, quantity: number) => void; onConfirm: (item: ForecastRecommendation) => void; onAction: (kind: InsightSignal['actionKind']) => void }) {
  const insight = useMemo(() => buildInsight({ forecast, ingredients, transactions }), [forecast, ingredients, transactions]);
  const totalServings = forecast.dishes.reduce((sum, item) => sum + item.servings, 0);
  const expectedRevenue = totalServings * 62000;
  const topDish = [...forecast.dishes].sort((a, b) => b.servings - a.servings)[0];
  const shopping = mlForecast?.shopping_list.filter((item) => item.to_buy > 0) ?? ingredients.filter((item) => item.current < item.minimum).map((item) => ({ name: item.name, unit: item.unit, to_buy: item.minimum - item.current }));
  const [chatInput, setChatInput] = useState('');
  const [chatMessages, setChatMessages] = useState<{ from: 'ai' | 'user'; text: string }[]>([{ from: 'ai', text: 'Tôi đang theo dõi thời tiết, tồn kho và tốc độ bán. Bạn muốn biết điều gì?' }]);
  const askCompanion = () => {
    const prompt = chatInput.trim();
    if (!prompt) return;
    const lower = prompt.toLowerCase();
    const answer = lower.includes('lãi') || lower.includes('lợi nhuận')
      ? `Lợi nhuận ròng ước tính trong kỳ hiện tại là ${money(transactions.filter((item) => item.type === 'thu').reduce((sum, item) => sum + item.amount, 0) - transactions.filter((item) => item.type === 'chi').reduce((sum, item) => sum + item.amount, 0))}.`
      : lower.includes('mua') || lower.includes('sáng mai')
        ? `Danh sách ưu tiên có ${shopping.length} mục. Tôi sẽ ưu tiên ${shopping.slice(0, 2).map((item) => item.name).join(' và ') || 'chưa cần nhập thêm'}.`
        : insight.body;
    setChatMessages((current) => [...current, { from: 'user', text: prompt }, { from: 'ai', text: answer }]);
    setChatInput('');
  };
  return <div data-testid="workspace-forecast" className="workspace-page space-y-5 md:space-y-6">
    <section className="workspace-hero forecast-workspace-hero flex flex-col justify-between gap-4 md:flex-row md:items-end"><div><p className="workspace-eyebrow text-primary">AI Companion · Insight Hub</p><h2 className="mt-2 max-w-3xl font-serif text-3xl text-foreground md:text-5xl">Một người đồng hành hiểu ca bán hàng.</h2><p className="mt-3 max-w-2xl text-sm leading-6 text-muted-foreground">Không cần đọc biểu đồ phức tạp. Insight Engine chuyển thời tiết, tồn kho và burn rate thành một việc cần làm rõ ràng.</p></div><button data-testid="button-command-refresh" onClick={onRefresh} className="flex w-fit items-center gap-2 rounded-xl bg-primary px-4 py-3 text-sm font-bold text-primary-foreground shadow-lg shadow-primary/15"><RefreshCw size={16} />Cập nhật dữ liệu</button></section>
    <section className="grid gap-4 xl:grid-cols-3"><article data-testid="forecast-kpi-revenue" className="forecast-kpi border-primary/20 bg-primary text-primary-foreground"><div className="flex items-start justify-between"><span className="grid h-10 w-10 place-items-center rounded-xl bg-primary-foreground/12"><TrendingUp size={19} /></span><span className="rounded-full bg-primary-foreground/12 px-2.5 py-1 text-[10px] font-bold">Ngày mai</span></div><p className="mt-8 text-sm text-primary-foreground/70">Doanh thu dự kiến</p><p className="mt-1 font-mono text-3xl font-bold">{money(expectedRevenue)}</p><p className="mt-2 text-xs text-primary-foreground/70">Dựa trên {totalServings} suất · độ tin cậy {forecast.confidence}%</p></article><article data-testid="forecast-kpi-shopping" className="forecast-kpi border-accent/25 bg-card"><div className="flex items-start justify-between"><span className="grid h-10 w-10 place-items-center rounded-xl bg-accent/10 text-accent"><ShoppingBasket size={19} /></span><span className="rounded-full bg-accent/10 px-2.5 py-1 text-[10px] font-bold text-accent">{shopping.length} mục</span></div><p className="mt-8 text-sm text-muted-foreground">Lời khuyên đi chợ</p><p className="mt-1 font-serif text-2xl">{shopping.length ? 'Mua đủ, không mua dư' : 'Kho đang đủ dùng'}</p><p className="mt-2 truncate text-xs text-muted-foreground">{shopping.length ? shopping.slice(0, 2).map((item) => item.name).join(' · ') : 'Chưa có nguyên liệu dưới ngưỡng.'}</p></article><article data-testid="forecast-kpi-trend" className="forecast-kpi border-secondary bg-card"><div className="flex items-start justify-between"><span className="grid h-10 w-10 place-items-center rounded-xl bg-secondary text-secondary-foreground"><ArrowUpRight size={19} /></span><span className="rounded-full bg-secondary px-2.5 py-1 text-[10px] font-bold text-secondary-foreground">Top trend</span></div><p className="mt-8 text-sm text-muted-foreground">Xu hướng bán chạy</p><p className="mt-1 font-serif text-2xl">{topDish?.name ?? 'Chưa có dữ liệu'}</p><p className="mt-2 font-mono text-xs text-muted-foreground">{topDish?.servings ?? 0} suất · burn rate {money(insight.burnRate)}/suất</p></article></section>
    <section data-testid="insight-hub" className="insight-hub overflow-hidden rounded-3xl border border-white/50 p-4 shadow-[var(--shadow-card)] md:p-6"><div className="grid gap-5 xl:grid-cols-[1.1fr_.9fr]"><div><div className="flex items-center justify-between gap-3"><div><p className="workspace-eyebrow text-primary">{insight.greeting}</p><h3 className="mt-2 font-serif text-3xl">{insight.title}</h3></div><span className={`grid h-11 w-11 place-items-center rounded-2xl ${insight.severity === 'urgent' ? 'bg-destructive/10 text-destructive' : 'bg-primary/10 text-primary'}`}><Sparkles size={21} /></span></div><p className="mt-5 max-w-2xl text-sm leading-7 text-muted-foreground">{insight.body}</p><div className="mt-5 flex flex-wrap gap-2"><button data-testid="button-insight-action" onClick={() => onAction(insight.actionKind)} className="flex items-center gap-2 rounded-xl bg-primary px-4 py-3 text-xs font-bold text-primary-foreground"><Sparkles size={15} />{insight.actionLabel}</button><button data-testid="button-insight-restock" onClick={() => onAction('restock')} className="flex items-center gap-2 rounded-xl border border-border bg-card/70 px-4 py-3 text-xs font-bold text-foreground"><ShoppingBasket size={15} />Xem danh sách nhập</button></div><div className="mt-6 flex flex-wrap items-center gap-4 text-xs text-muted-foreground"><span className="flex items-center gap-1.5"><CloudSun size={14} />{insight.weatherLabel}</span><span className="flex items-center gap-1.5"><TrendingUp size={14} />Burn rate {money(insight.burnRate)}/suất</span></div></div><div className="rounded-2xl border border-border/70 bg-card/70 p-4 backdrop-blur-md"><div className="flex items-center gap-2"><span className="grid h-8 w-8 place-items-center rounded-xl bg-primary/10 text-primary"><MessageCircle size={16} /></span><div><p className="text-sm font-bold">Hỏi AI Companion</p><p className="text-[10px] text-muted-foreground">Query trực tiếp dữ liệu quán</p></div></div><div className="mt-4 max-h-44 space-y-2 overflow-y-auto">{chatMessages.map((message, index) => <div key={`${message.from}-${index}`} className={`max-w-[92%] rounded-2xl px-3 py-2.5 text-xs leading-5 ${message.from === 'user' ? 'ml-auto bg-primary text-primary-foreground' : 'bg-muted text-foreground'}`}>{message.text}</div>)}</div><div className="mt-3 flex gap-2"><input data-testid="input-insight-chat" value={chatInput} onChange={(event) => setChatInput(event.target.value)} onKeyDown={(event) => { if (event.key === 'Enter') askCompanion(); }} placeholder="Hôm nay lãi bao nhiêu?" className="min-w-0 flex-1 rounded-xl border border-input bg-background px-3 py-2.5 text-xs outline-none focus:border-primary" /><button data-testid="button-insight-chat" onClick={askCompanion} className="grid h-10 w-10 shrink-0 place-items-center rounded-xl bg-primary text-primary-foreground"><ArrowUpRight size={16} /></button></div></div></div></section>
    <section className="workspace-card p-4 md:p-5"><div className="flex items-center justify-between"><div><p className="workspace-eyebrow text-muted-foreground">Action queue</p><h3 className="mt-1 font-serif text-2xl">Tín hiệu AI đang theo dõi</h3></div><span className="rounded-full bg-primary/10 px-2.5 py-1 text-[10px] font-bold text-primary">{forecast.confidence}% tin cậy</span></div><div className="mt-4 grid gap-3 md:grid-cols-3"><div className="rounded-2xl bg-muted/60 p-4"><p className="text-xs font-bold">Thời tiết</p><p className="mt-2 text-sm text-muted-foreground">{insight.weatherLabel}</p></div><div className="rounded-2xl bg-muted/60 p-4"><p className="text-xs font-bold">Tồn kho hạn ngắn</p><p className="mt-2 text-sm text-muted-foreground">{ingredients.filter((item) => (item.shelfLifeDays ?? 7) <= 2).length} nguyên liệu cần quan sát</p></div><div className="rounded-2xl bg-muted/60 p-4"><p className="text-xs font-bold">Tốc độ bán</p><p className="mt-2 text-sm text-muted-foreground">{topDish?.name ?? 'Chưa đủ dữ liệu'} đang dẫn đầu ngày mai</p></div></div></section>
  </div>;
}

function orderStatusLabel(status: OrderStatus) {
  return ({ moi: 'Mới', 'dang-lam': 'Đang chế biến', 'cho-thanh-toan': 'Chờ thanh toán', 'hoan-tat': 'Hoàn tất' })[status];
}
function orderStatusTone(status: OrderStatus) {
  return status === 'hoan-tat' ? 'bg-primary/10 text-primary' : status === 'cho-thanh-toan' ? 'bg-accent/10 text-accent' : status === 'dang-lam' ? 'bg-secondary text-secondary-foreground' : 'bg-cyan-400/10 text-cyan-700';
}
function OrdersWorkspace({ orders, onUpdateStatus, onOpenPos }: { orders: Order[]; onUpdateStatus: (id: string, status: OrderStatus) => void; onOpenPos: () => void }) {
  const [filter, setFilter] = useState<'tat-ca' | OrderStatus>('tat-ca');
  const visible = filter === 'tat-ca' ? orders : orders.filter((order) => order.status === filter);
  const active = orders.filter((order) => order.status !== 'hoan-tat');
  const revenue = orders.filter((order) => order.status === 'hoan-tat').reduce((sum, order) => sum + order.total, 0);
  const advanceStatus = (order: Order) => {
    const next: Record<OrderStatus, OrderStatus> = { moi: 'dang-lam', 'dang-lam': 'cho-thanh-toan', 'cho-thanh-toan': 'hoan-tat', 'hoan-tat': 'hoan-tat' };
    onUpdateStatus(order.id, next[order.status]);
  };
  return <div data-testid="workspace-orders" className="workspace-page space-y-5 md:space-y-6">
    <OperationsFilterBar label="Đơn hàng · Theo dõi theo thời gian thực" />
    <section className="workspace-hero flex flex-col justify-between gap-4 md:flex-row md:items-end"><div><p className="workspace-eyebrow text-primary">Order control tower · Bếp Nhà Mình</p><h2 className="mt-2 font-serif text-3xl md:text-5xl">Tất cả đơn, một luồng xử lý.</h2><p className="mt-3 max-w-2xl text-sm leading-6 text-muted-foreground">Theo dõi đơn tại quán, mang đi và online theo từng trạng thái. Không bỏ sót đơn, không để bếp chờ thông tin.</p></div><button onClick={onOpenPos} className="flex w-fit items-center gap-2 rounded-xl bg-primary px-4 py-3 text-sm font-bold text-primary-foreground"><Plus size={16} />Tạo đơn mới</button></section>
    <section className="grid gap-3 sm:grid-cols-2 xl:grid-cols-4"><StatCard label="Đơn đang xử lý" value={String(active.length)} note="Cần theo dõi ngay" icon={ClipboardList} tone="orange" /><StatCard label="Chờ thanh toán" value={String(orders.filter((order) => order.status === 'cho-thanh-toan').length)} note="Thu tiền trước khi đóng đơn" icon={WalletCards} tone="sand" /><StatCard label="Doanh thu đã chốt" value={money(revenue)} note="Từ các đơn hoàn tất" icon={ArrowUpRight} tone="orange" /><StatCard label="Bình quân / đơn" value={money(orders.length ? orders.reduce((sum, order) => sum + order.total, 0) / orders.length : 0)} note={`${orders.reduce((sum, order) => sum + order.items, 0)} món trong ca`} icon={TrendingUp} tone="sand" /></section>
    <section className="grid gap-5 xl:grid-cols-[1.35fr_.65fr]"><div className="workspace-card overflow-hidden"><div className="flex flex-col justify-between gap-3 border-b border-border/70 p-4 md:flex-row md:items-center md:px-5"><div><p className="workspace-eyebrow text-muted-foreground">Order pipeline</p><h3 className="mt-1 font-serif text-2xl">Luồng đơn hàng</h3></div><div className="flex gap-1 overflow-x-auto rounded-xl bg-muted p-1">{(['tat-ca', 'moi', 'dang-lam', 'cho-thanh-toan', 'hoan-tat'] as const).map((item) => <button key={item} onClick={() => setFilter(item)} className={`whitespace-nowrap rounded-lg px-2.5 py-1.5 text-[10px] font-bold ${filter === item ? 'bg-card text-primary shadow-sm' : 'text-muted-foreground'}`}>{item === 'tat-ca' ? 'Tất cả' : orderStatusLabel(item)}</button>)}</div></div><div className="divide-y divide-border/70">{visible.map((order) => <article key={order.id} className="flex flex-col gap-3 p-4 md:flex-row md:items-center md:justify-between md:px-5"><div className="flex min-w-0 items-start gap-3"><span className="grid h-10 w-10 shrink-0 place-items-center rounded-xl bg-primary/10 text-primary"><ChefHat size={17} /></span><div className="min-w-0"><div className="flex flex-wrap items-center gap-2"><p className="font-mono text-xs font-bold">{order.id}</p><span className={`rounded-full px-2 py-1 text-[10px] font-bold ${orderStatusTone(order.status)}`}>{orderStatusLabel(order.status)}</span></div><p className="mt-1 text-sm font-bold">{order.table} · {order.channel}</p><p className="mt-1 text-[11px] text-muted-foreground">{order.customer} · {order.items} món · {order.createdAt} · {order.branch}</p></div></div><div className="flex items-center justify-between gap-3 md:justify-end"><span className="font-mono text-sm font-bold">{money(order.total)}</span>{order.status !== 'hoan-tat' && <button onClick={() => advanceStatus(order)} className="rounded-xl bg-secondary px-3 py-2 text-[11px] font-bold text-secondary-foreground">{order.status === 'moi' ? 'Nhận bếp' : order.status === 'dang-lam' ? 'Báo món xong' : 'Thu tiền & đóng đơn'}</button>}</div></article>)}{!visible.length && <EmptyState title="Không có đơn ở trạng thái này" text="Các đơn mới sẽ xuất hiện tại đây khi POS ghi nhận giao dịch." />}</div></div><aside className="workspace-card command-alert-rail p-5"><div className="flex items-center gap-3"><span className="grid h-10 w-10 place-items-center rounded-xl bg-primary/10 text-primary"><Bot size={18} /></span><div><p className="workspace-eyebrow text-primary">AI Order Manager</p><h3 className="mt-1 font-serif text-xl">AI đang canh luồng đơn</h3></div></div><div className="mt-5 space-y-3"><div className="rounded-xl bg-accent/[.07] p-3"><p className="text-[10px] font-bold uppercase tracking-wider text-accent">Ưu tiên</p><p className="mt-1 text-sm font-semibold">{orders.filter((order) => order.status === 'cho-thanh-toan').length ? 'Có đơn đã xong món nhưng chưa thu tiền.' : 'Không có đơn tồn đọng cần thu tiền.'}</p></div><div className="rounded-xl bg-muted/60 p-3"><p className="text-[10px] font-bold uppercase tracking-wider text-muted-foreground">Nhịp bếp</p><p className="mt-1 text-sm font-semibold">{orders.filter((order) => order.status === 'dang-lam').length} đơn đang chế biến · {orders.filter((order) => order.channel === 'Online').length} đơn online.</p></div><p className="text-xs leading-5 text-muted-foreground">AI sẽ ưu tiên cảnh báo đơn chậm, lệch trạng thái và doanh thu chưa chốt — thay vì chỉ trả lời khi chủ quán hỏi.</p></div></aside></section>
  </div>;
}
function ManagementControlTower({ ingredients, transactions, orders, onOrders, onInventory, onShopping, onOpenCopilot }: { ingredients: Ingredient[]; transactions: Transaction[]; orders: Order[]; onOrders: () => void; onInventory: () => void; onShopping: () => void; onOpenCopilot: () => void }) {
  const lowStock = ingredients.filter((item) => item.current < item.minimum);
  const activeOrders = orders.filter((order) => order.status !== 'hoan-tat');
  const revenue = transactions.filter((item) => item.type === 'thu').reduce((sum, item) => sum + item.amount, 0);
  const actions = [
    lowStock.length ? { title: `Bổ sung ${lowStock.length} nguyên liệu dưới ngưỡng`, detail: `${lowStock.slice(0, 2).map((item) => item.name).join(' và ')} cần xử lý trước ca.`, label: 'Mở kho', icon: Boxes, onClick: onInventory, tone: 'accent' } : { title: 'Tồn kho đang trong ngưỡng an toàn', detail: 'Không có nguyên liệu nào dưới mức tối thiểu.', label: 'Xem kho', icon: Boxes, onClick: onInventory, tone: 'primary' },
    activeOrders.length ? { title: `${activeOrders.length} đơn chưa hoàn tất`, detail: 'Theo dõi bếp và thu tiền để không đọng doanh thu.', label: 'Mở đơn hàng', icon: ClipboardList, onClick: onOrders, tone: 'primary' } : { title: 'Không có đơn tồn', detail: 'Luồng đơn đang sạch, có thể tập trung bán thêm.', label: 'Mở POS', icon: ClipboardList, onClick: onOrders, tone: 'primary' },
    { title: 'AI đề xuất kiểm tra biên lợi nhuận', detail: `Doanh thu ghi nhận ${money(revenue)} · xem định lượng các món bán chạy.`, label: 'Hỏi AI', icon: Sparkles, onClick: onOpenCopilot, tone: 'cyan' },
  ] as const;
  return <section data-testid="management-control-tower" className="workspace-card overflow-hidden border-primary/20 p-4 md:p-5"><div className="flex flex-col justify-between gap-3 sm:flex-row sm:items-end"><div><p className="workspace-eyebrow text-primary">Management control tower</p><h3 className="mt-1 font-serif text-2xl md:text-3xl">AI biến số liệu thành việc phải làm.</h3><p className="mt-1 max-w-2xl text-xs leading-5 text-muted-foreground">Mô hình quản lý theo chuỗi: bán hàng → đơn → bếp → kho → dòng tiền. Chủ quán luôn biết vấn đề nằm ở đâu và bước tiếp theo là gì.</p></div><button onClick={onShopping} className="flex w-fit items-center gap-2 rounded-xl border border-border px-3 py-2 text-xs font-bold text-primary"><Truck size={14} />Kế hoạch nhập hàng</button></div><div className="mt-5 grid gap-3 lg:grid-cols-3">{actions.map((action) => <article key={action.title} className="rounded-2xl border border-border/70 bg-background/55 p-4"><div className="flex items-start justify-between gap-3"><span className={`grid h-9 w-9 place-items-center rounded-xl ${action.tone === 'accent' ? 'bg-accent/10 text-accent' : action.tone === 'cyan' ? 'bg-cyan-400/10 text-cyan-700' : 'bg-primary/10 text-primary'}`}><action.icon size={17} /></span><span className="rounded-full bg-muted px-2 py-1 text-[9px] font-bold">AI ACTION</span></div><p className="mt-4 text-sm font-bold">{action.title}</p><p className="mt-1 min-h-10 text-xs leading-5 text-muted-foreground">{action.detail}</p><button onClick={action.onClick} className="mt-3 flex items-center gap-1.5 text-xs font-bold text-primary">{action.label}<ChevronRight size={14} /></button></article>)}</div></section>;
}
function Dashboard({ ingredients, transactions, orders, mlForecast, onViewForecast, onViewInventory, onViewShopping, onViewLedger, onViewInvoices, onOpenCopilot }: { ingredients: Ingredient[]; transactions: Transaction[]; orders: Order[]; mlForecast: MlForecast | null; onViewForecast: () => void; onViewInventory: () => void; onViewShopping: () => void; onViewLedger: () => void; onViewInvoices: () => void; onOpenCopilot: () => void }) {
  const [period, setPeriod] = useState('Hôm nay');
  const fallbackShopping: ShoppingListItem[] = ingredients
    .filter((item) => item.current < item.minimum)
    .map((item) => ({
      id: item.id,
      name: item.name,
      unit: item.unit,
      forecast_need: item.minimum,
      upper_need: item.minimum,
      inventory: item.current,
      to_buy: Number((item.minimum - item.current).toFixed(2)),
      price: item.price,
      urgent: (item.shelfLifeDays ?? 7) <= 2,
      shelf_life_days: item.shelfLifeDays ?? 7,
    }));
  const shoppingList = mlForecast?.shopping_list ?? fallbackShopping;
  const alerts = mlForecast?.operational_alerts ?? [];
  const urgentCount = shoppingList.filter((item) => item.to_buy > 0 && item.urgent).length;
  const tomorrow = new Date();
  tomorrow.setDate(tomorrow.getDate() + 1);
  const scopedTransactions = useMemo(() => {
    if (period === 'Hôm nay') return transactions.filter((item) => item.date === today);
    if (period === 'Hôm qua') {
      const yesterday = new Date();
      yesterday.setDate(yesterday.getDate() - 1);
      return transactions.filter((item) => item.date === dateInput(yesterday));
    }
    const days = period === 'Tuần này' ? 7 : 30;
    const start = new Date();
    start.setDate(start.getDate() - (days - 1));
    const startDate = dateInput(start);
    return transactions.filter((item) => item.date >= startDate && item.date <= today);
  }, [period, transactions]);
  const revenueToday = scopedTransactions.filter((item) => item.type === 'thu').reduce((sum, item) => sum + item.amount, 0);
  const inventoryValue = ingredients.reduce((sum, item) => sum + item.current * item.price, 0);
  return <div data-testid="workspace-overview" className="workspace-page space-y-5 md:space-y-8">
    <OperationsFilterBar label="Tổng quan · Bộ lọc thời gian" onPeriodChange={setPeriod} />
    <section className="stagger-item stagger-1 flex flex-col justify-between gap-4 md:flex-row md:items-end">
      <div>
        <p className="font-mono text-[10px] uppercase tracking-[.18em] text-primary">Action Board · {dateLabel(dateInput(tomorrow))}</p>
        <h2 data-testid="text-action-board-title" className="mt-2 font-serif text-3xl text-foreground md:text-5xl">Việc cần làm trước giờ mở cửa.</h2>
        <p className="mt-3 max-w-2xl text-sm leading-6 text-muted-foreground">Resto.AI gom dự báo, tồn kho và tín hiệu bất thường thành các việc có thể xử lý ngay cho ca ngày mai.</p>
      </div>
      <button data-testid="button-view-forecast-dashboard" onClick={onViewForecast} className="flex w-fit items-center gap-2 rounded-xl bg-primary px-4 py-3 text-sm font-bold text-primary-foreground shadow-sm transition-transform hover:-translate-y-0.5"><RefreshCw size={16} />Chạy lại dự báo</button>
    </section>

    <section data-testid="section-flash-alerts" className="stagger-item stagger-2 space-y-3">
      <div className="flex items-center justify-between"><div><p className="font-mono text-[10px] uppercase tracking-[.18em] text-accent">Flash Alert</p><h3 className="mt-1 font-serif text-2xl">Cảnh báo cần xử lý</h3></div><span className={`rounded-full px-3 py-1.5 text-[10px] font-bold ${alerts.length ? 'bg-accent/10 text-accent' : 'bg-primary/10 text-primary'}`}>{alerts.length ? `${alerts.length} cảnh báo` : 'Đang ổn định'}</span></div>
      {alerts.length ? <div className="grid gap-3 lg:grid-cols-2">{alerts.map((alert, index) => <FlashAlert key={`${alert.type}-${index}`} alert={alert} index={index} />)}</div> : <div className="flex items-start gap-3 rounded-2xl border border-primary/20 bg-primary/[.045] p-4"><CheckCircle2 size={19} className="mt-0.5 shrink-0 text-primary" /><div><p className="text-sm font-bold">Chưa có cảnh báo khẩn</p><p className="mt-1 text-xs leading-5 text-muted-foreground">{mlForecast ? 'Các tín hiệu thời tiết, giờ cao điểm và tồn kho đang trong ngưỡng theo dõi.' : 'Chưa chạy mô hình ML. Mở mục Dự báo để tạo bảng hành động cho ngày mai.'}</p></div></div>}
    </section>

    <section className="stagger-item stagger-3 grid gap-4 md:grid-cols-2">
      <TiltCard testId="card-dashboard-revenue" className="border-primary/20 bg-card">
        <div className="flex items-start justify-between gap-3"><div><p className="font-mono text-[10px] uppercase tracking-[.18em] text-primary">Dòng tiền hôm nay</p><h3 className="mt-2 font-serif text-2xl">Doanh thu</h3></div><span className="grid h-10 w-10 place-items-center rounded-xl bg-primary/10 text-primary"><ArrowUpRight size={19} /></span></div>
        <p data-testid="value-dashboard-revenue" className="mt-7 font-mono text-3xl tracking-tight">{money(revenueToday)}</p>
        <div className="mt-3 flex items-center justify-between text-xs text-muted-foreground"><span>{scopedTransactions.filter((item) => item.type === 'thu').length} giao dịch · {period.toLowerCase()}</span><span className="rounded-full bg-primary/10 px-2.5 py-1 font-semibold text-primary">+12.8% tuần này</span></div>
      </TiltCard>
      <TiltCard testId="card-dashboard-inventory" className="border-accent/20 bg-card">
        <div className="flex items-start justify-between gap-3"><div><p className="font-mono text-[10px] uppercase tracking-[.18em] text-accent">Giá trị đang giữ</p><h3 className="mt-2 font-serif text-2xl">Tồn kho</h3></div><span className="grid h-10 w-10 place-items-center rounded-xl bg-accent/10 text-accent"><Boxes size={19} /></span></div>
        <p data-testid="value-dashboard-inventory" className="mt-7 font-mono text-3xl tracking-tight">{money(inventoryValue)}</p>
        <div className="mt-3 flex items-center justify-between text-xs text-muted-foreground"><span>{ingredients.length} mặt hàng đang theo dõi</span><span className="rounded-full bg-accent/10 px-2.5 py-1 font-semibold text-accent">{urgentCount} cần chú ý</span></div>
      </TiltCard>
    </section>

    <RevenueTrend transactions={scopedTransactions} />
    <ManagementControlTower ingredients={ingredients} transactions={scopedTransactions} orders={orders} onOrders={onViewInvoices} onInventory={onViewInventory} onShopping={onViewShopping} onOpenCopilot={onOpenCopilot} />
    <RestoInsights onCreateRestock={onViewShopping} onOpenCopilot={onOpenCopilot} />
    <QuickActionRow onInventory={onViewInventory} onShopping={onViewShopping} onLedger={onViewLedger} onInvoices={onViewInvoices} />

    <section className="stagger-item stagger-4 grid gap-5 xl:grid-cols-[1.25fr_.75fr]">
      <div data-testid="card-shopping-checklist" className="rounded-2xl border border-card-border bg-card p-5 shadow-[var(--shadow-card)] md:p-6">
        <div className="flex flex-col justify-between gap-2 sm:flex-row sm:items-end"><div><p className="font-mono text-[10px] uppercase tracking-[.18em] text-primary">Chuẩn bị nguyên liệu</p><h3 className="mt-1 font-serif text-2xl">Danh sách đi chợ rạng sáng mai</h3></div><span className="text-xs text-muted-foreground">{shoppingList.filter((item) => item.to_buy > 0).length} mục cần mua</span></div>
        <div className="mt-5 divide-y divide-border/70">
          {shoppingList.filter((item) => item.to_buy > 0).map((item) => <label data-testid={`checklist-shopping-${item.id}`} key={`${item.id}-${item.unit}`} className="flex cursor-pointer items-center gap-3 py-3 first:pt-0 last:pb-0"><input type="checkbox" className="h-4 w-4 shrink-0 accent-[hsl(var(--primary))]" /><span className={`grid h-9 w-9 shrink-0 place-items-center rounded-lg ${item.urgent ? 'bg-accent/10 text-accent' : 'bg-secondary text-secondary-foreground'}`}><ShoppingBasket size={16} /></span><span className="min-w-0 flex-1"><span className="block text-sm font-bold">{item.name}</span><span className="mt-0.5 block text-[11px] text-muted-foreground">Tồn {item.inventory} {item.unit} · cận trên cần {item.upper_need} {item.unit}</span></span><span className={`whitespace-nowrap font-mono text-sm font-bold ${item.urgent ? 'text-accent' : 'text-primary'}`}>+{item.to_buy} {item.unit}</span></label>)}
          {!shoppingList.some((item) => item.to_buy > 0) && <EmptyState title="Chưa cần đi chợ thêm" text="Tồn kho hiện tại đã đủ theo cận trên dự báo." />}
        </div>
        <button data-testid="button-inventory-dashboard" onClick={onViewInventory} className="mt-5 w-full rounded-xl border border-border py-2.5 text-xs font-bold text-primary transition-colors hover:bg-muted">Mở kho nguyên liệu</button>
      </div>
      <div className="rounded-2xl border border-card-border bg-card p-5 shadow-[var(--shadow-card)] md:p-6">
        <div className="flex items-center justify-between"><div><p className="font-mono text-[10px] uppercase tracking-[.18em] text-muted-foreground">Tóm tắt ca ngày mai</p><h3 className="mt-1 font-serif text-2xl">Ưu tiên trong ngày</h3></div><span className="grid h-10 w-10 place-items-center rounded-xl bg-secondary text-secondary-foreground"><PackageCheck size={19} /></span></div>
        <div className="mt-6 space-y-3">
          <div className="rounded-xl bg-secondary/70 p-4"><p className="text-xs text-muted-foreground">Mô hình</p><p className="mt-1 font-mono text-lg font-bold">{mlForecast ? `${mlForecast.model} · ${mlForecast.confidence}%` : 'Chưa chạy'}</p></div>
          <div className="rounded-xl bg-accent/[.07] p-4"><p className="text-xs text-muted-foreground">Nguyên liệu ngắn hạn cần chú ý</p><p className="mt-1 font-mono text-lg font-bold text-accent">{urgentCount} mục</p></div>
          <button onClick={onViewForecast} className="flex w-full items-center justify-center gap-2 rounded-xl border border-border py-3 text-xs font-bold text-primary hover:bg-muted"><Lightbulb size={15} />Xem chi tiết dự báo</button>
        </div>
      </div>
    </section>
  </div>;
}

function FlashAlert({ alert, index }: { alert: SmartAdvice; index: number }) {
  const isClearance = alert.type === 'clearance';
  return <article data-testid={`card-flash-alert-${index}`} className={`rounded-2xl border p-4 shadow-[var(--shadow-card)] ${alert.severity === 'urgent' ? 'border-accent/40 bg-accent/[.09]' : 'border-primary/30 bg-primary/[.055]'}`}>
    <div className="flex items-start gap-3"><span className={`grid h-10 w-10 shrink-0 place-items-center rounded-xl ${alert.severity === 'urgent' ? 'bg-accent/15 text-accent' : 'bg-primary/12 text-primary'}`}>{isClearance ? <ShoppingBasket size={18} /> : <AlertTriangle size={18} />}</span><div className="min-w-0 flex-1"><div className="flex flex-wrap items-center justify-between gap-2"><p className="text-[10px] font-bold uppercase tracking-[.15em] text-muted-foreground">{alert.title}</p><span className={`rounded-full px-2 py-1 text-[9px] font-bold ${alert.severity === 'urgent' ? 'bg-accent/15 text-accent' : 'bg-primary/10 text-primary'}`}>{adviceSeverityLabel(alert.severity)}</span></div><p className="mt-2 text-sm font-semibold leading-6">{alert.message}</p><p className="mt-3 rounded-lg bg-background/60 px-3 py-2 text-xs font-bold leading-5">Việc nên làm: {alert.action}</p></div></div>
  </article>;
}

function StatCard({ label, value, note, icon: Icon, tone }: { label: string; value: string; note: string; icon: typeof ArrowUpRight; tone: 'orange' | 'sand' }) {
  return <div className="card-lift rounded-2xl border border-card-border bg-card p-6 shadow-[var(--shadow-card)]"><div className="flex items-center justify-between"><p className="text-sm text-muted-foreground">{label}</p><span className={`grid h-9 w-9 place-items-center rounded-lg ${tone === 'orange' ? 'bg-accent/12 text-accent' : 'bg-secondary text-secondary-foreground'}`}><Icon size={18} /></span></div><p className="mt-5 font-mono text-2xl tracking-tight text-foreground">{value}</p><p className="mt-2 text-xs text-muted-foreground">{note}</p></div>;
}

function Transactions({ transactions, onAdd, onEdit, onDelete, onNotify }: { transactions: Transaction[]; onAdd: () => void; onEdit: (item: Transaction) => void; onDelete: (id: string) => void; onNotify: (message: string, tone?: ToastTone) => void }) {
  const [search, setSearch] = useState('');
  const [type, setType] = useState<'tat-ca' | TransactionType>('tat-ca');
  const [range, setRange] = useState('tat-ca');
  const filtered = useMemo(() => transactions.filter((item) => {
    const matchesSearch = `${item.note} ${item.category}`.toLowerCase().includes(search.toLowerCase());
    const matchesType = type === 'tat-ca' || item.type === type;
    const matchesRange = range === 'tat-ca' || (range === 'thu-nay' ? item.date === today : item.date >= '2025-05-21');
    return matchesSearch && matchesType && matchesRange;
  }), [transactions, search, type, range]);
  return <div className="fade-up space-y-6"><div className="flex flex-col justify-between gap-4 md:flex-row md:items-end"><div><p className="text-sm text-muted-foreground">Theo dõi từng đồng vào ra, không bỏ sót một khoản nhỏ.</p></div><button data-testid="button-add-transaction" onClick={onAdd} className="flex w-fit items-center gap-2 rounded-xl bg-primary px-4 py-3 text-sm font-bold text-primary-foreground"><Plus size={17} />Thêm giao dịch</button></div>
    <div className="rounded-2xl border border-card-border bg-card p-4 shadow-[var(--shadow-card)] md:p-5"><div className="flex flex-col gap-3 lg:flex-row"><label className="relative flex-1"><Search size={17} className="absolute left-3 top-3 text-muted-foreground" /><input data-testid="input-search-transactions" value={search} onChange={(event) => setSearch(event.target.value)} placeholder="Tìm theo nội dung hoặc danh mục..." className="h-11 w-full rounded-xl border border-input bg-background pl-10 pr-3 text-sm outline-none transition-colors placeholder:text-muted-foreground/70 focus:border-primary focus:ring-2 focus:ring-primary/10" /></label><div className="flex gap-2 overflow-x-auto"><select data-testid="select-transaction-type" value={type} onChange={(event) => setType(event.target.value as typeof type)} className="h-11 min-w-[130px] rounded-xl border border-input bg-background px-3 text-xs font-semibold outline-none focus:border-primary"><option value="tat-ca">Tất cả loại</option><option value="thu">Khoản thu</option><option value="chi">Khoản chi</option></select><select data-testid="select-transaction-range" value={range} onChange={(event) => setRange(event.target.value)} className="h-11 min-w-[130px] rounded-xl border border-input bg-background px-3 text-xs font-semibold outline-none focus:border-primary"><option value="tat-ca">Mọi thời gian</option><option value="thu-nay">Hôm nay</option><option value="7-ngay">7 ngày qua</option></select></div></div></div>
     <div className="rounded-2xl border border-card-border bg-card shadow-[var(--shadow-card)]"><div className="flex items-center justify-between border-b border-border/70 px-5 py-4"><div><p className="font-serif text-lg">Danh sách giao dịch</p><p className="mt-0.5 text-xs text-muted-foreground">{filtered.length} mục hiển thị</p></div><button data-testid="button-export-transactions" onClick={() => onNotify('Tính năng xuất dữ liệu sẽ được bổ sung trong phiên bản tiếp theo.', 'warning')} className="rounded-lg border border-border px-3 py-2 text-xs font-bold text-muted-foreground hover:bg-muted">Xuất sổ</button></div><TransactionTable transactions={filtered} onEdit={onEdit} onDelete={onDelete} /></div>
  </div>;
}

function csvCell(value: string | number) {
  return `"${String(value).replace(/"/g, '""')}"`;
}

function reportTypeLabel(type: ReportType) {
  return ({ 'tong-hop': 'Tổng hợp thu chi', 'doanh-thu': 'Doanh thu', 'chi-phi': 'Chi phí' })[type];
}

function reportPeriodLabel(period: ReportPeriod, start: string, end: string) {
  if (period === 'thang-05-2025') return '01/05/2025 – 31/05/2025';
  if (period === 'thang-04-2025') return '01/04/2025 – 30/04/2025';
  if (period === 'tat-ca') return 'Toàn bộ thời gian';
  return `${dateLabel(start)} – ${dateLabel(end)}`;
}

function Reports({ transactions, restaurant, onExport }: { transactions: Transaction[]; restaurant: string; onExport: () => void }) {
  const [reportType, setReportType] = useState<ReportType>('tong-hop');
  const [period, setPeriod] = useState<ReportPeriod>('thang-05-2025');
  const [startDate, setStartDate] = useState('2025-05-01');
  const [endDate, setEndDate] = useState('2025-05-31');
  const [error, setError] = useState('');
  const range = useMemo(() => {
    if (period === 'thang-05-2025') return { start: '2025-05-01', end: '2025-05-31' };
    if (period === 'thang-04-2025') return { start: '2025-04-01', end: '2025-04-30' };
    if (period === 'tat-ca') return { start: '', end: '' };
    return { start: startDate, end: endDate };
  }, [period, startDate, endDate]);
  const reportTransactions = useMemo(() => transactions.filter((item) => {
    if (!range.start || !range.end) return true;
    return item.date >= range.start && item.date <= range.end;
  }), [transactions, range]);
  const revenueTransactions = reportTransactions.filter((item) => item.type === 'thu');
  const expenseTransactions = reportTransactions.filter((item) => item.type === 'chi');
  const revenue = revenueTransactions.reduce((sum, item) => sum + item.amount, 0);
  const expenses = expenseTransactions.reduce((sum, item) => sum + item.amount, 0);
  const profit = revenue - expenses;
  const expenseGroups = useMemo(() => {
    const groups = new Map<string, number>();
    expenseTransactions.forEach((item) => groups.set(item.category, (groups.get(item.category) ?? 0) + item.amount));
    return Array.from(groups.entries()).sort((a, b) => b[1] - a[1]);
  }, [expenseTransactions]);
  const displayedTransactions = reportType === 'doanh-thu' ? revenueTransactions : reportType === 'chi-phi' ? expenseTransactions : reportTransactions;
  const periodText = reportPeriodLabel(period, range.start || '2025-05-01', range.end || '2025-05-31');
  const createdAt = new Intl.DateTimeFormat('vi-VN', { dateStyle: 'long', timeStyle: 'short' }).format(new Date());

  const downloadReport = () => {
    if (period === 'tuy-chon' && (!startDate || !endDate || startDate > endDate)) {
      setError('Hãy chọn khoảng ngày hợp lệ trước khi xuất báo cáo.');
      return;
    }
    setError('');
    const rows: (string | number)[][] = [
      [`AURABITE – BÁO CÁO ${reportTypeLabel(reportType).toUpperCase()}`],
      ['Quán', restaurant],
      ['Khoảng thời gian', periodText],
      ['Ngày tạo', createdAt],
      [],
      ['TỔNG QUAN'],
      ['Chỉ số', 'Số tiền'],
      ['Doanh thu', revenue],
      ['Chi phí', expenses],
      ['Lợi nhuận', profit],
      [],
      ['NHÓM CHI PHÍ'],
      ['Nhóm chi phí', 'Số tiền', 'Tỷ trọng'],
      ...expenseGroups.map(([category, amount]) => [category, amount, expenses ? `${((amount / expenses) * 100).toFixed(1)}%` : '0%']),
      ...(expenseGroups.length ? [['Tổng chi phí', expenses, '100%']] : [['Chưa có chi phí', 0, '0%']]),
      [],
      ['CHI TIẾT GIAO DỊCH'],
      ['Ngày', 'Loại', 'Nhóm', 'Nội dung', 'Số tiền'],
      ...displayedTransactions.map((item) => [dateLabel(item.date), item.type === 'thu' ? 'Khoản thu' : 'Khoản chi', item.category, item.note, item.amount]),
    ];
    const csv = `\uFEFF${rows.map((row) => row.map((cell) => csvCell(cell)).join(',')).join('\n')}`;
    const url = URL.createObjectURL(new Blob([csv], { type: 'text/csv;charset=utf-8;' }));
    const link = document.createElement('a');
    link.href = url;
    link.download = `bao-cao-${reportType}-${range.start || 'toan-bo'}-${range.end || 'du-lieu'}.csv`;
    document.body.appendChild(link);
    link.click();
    link.remove();
    URL.revokeObjectURL(url);
    onExport();
  };

  return <div data-testid="workspace-reports" className="workspace-page fade-up space-y-6">
    <div className="flex flex-col justify-between gap-4 md:flex-row md:items-end"><div><p className="max-w-2xl text-sm leading-6 text-muted-foreground">Chọn kỳ đối soát để xem nhanh dòng tiền, nhóm chi phí và lợi nhuận của quán.</p></div><button data-testid="button-export-report" onClick={downloadReport} className="flex w-fit items-center gap-2 rounded-xl bg-primary px-4 py-3 text-sm font-bold text-primary-foreground shadow-sm transition-transform hover:-translate-y-0.5"><Download size={17} />Tải báo cáo CSV</button></div>
    <section className="report-preview rounded-2xl border border-card-border bg-card p-5 shadow-[var(--shadow-card)] md:p-6"><div className="mb-5 flex items-start gap-3"><span className="grid h-10 w-10 shrink-0 place-items-center rounded-xl bg-secondary text-secondary-foreground"><CalendarDays size={19} /></span><div><p className="font-serif text-lg">Thiết lập báo cáo</p><p className="mt-0.5 text-xs text-muted-foreground">Bộ lọc chỉ ảnh hưởng đến phần xem trước và file tải xuống.</p></div></div><div className="grid gap-4 md:grid-cols-2"><label className="block text-xs font-bold text-muted-foreground">Loại báo cáo<select data-testid="select-report-type" value={reportType} onChange={(event) => setReportType(event.target.value as ReportType)} className="mt-2 h-11 w-full rounded-xl border border-input bg-background px-3 text-sm font-semibold outline-none transition-colors focus:border-primary"><option value="tong-hop">Tổng hợp thu chi</option><option value="doanh-thu">Chỉ doanh thu</option><option value="chi-phi">Chỉ chi phí</option></select></label><label className="block text-xs font-bold text-muted-foreground">Khoảng thời gian<select data-testid="select-report-period" value={period} onChange={(event) => setPeriod(event.target.value as ReportPeriod)} className="mt-2 h-11 w-full rounded-xl border border-input bg-background px-3 text-sm font-semibold outline-none transition-colors focus:border-primary"><option value="thang-05-2025">Tháng 05/2025</option><option value="thang-04-2025">Tháng 04/2025</option><option value="tat-ca">Toàn bộ thời gian</option><option value="tuy-chon">Tùy chọn ngày</option></select></label></div>{period === 'tuy-chon' && <div className="mt-4 grid gap-4 sm:grid-cols-2"><label className="block text-xs font-bold text-muted-foreground">Từ ngày<input data-testid="input-report-start-date" type="date" value={startDate} onChange={(event) => setStartDate(event.target.value)} className="mt-2 h-11 w-full rounded-xl border border-input bg-background px-3 text-sm font-medium outline-none focus:border-primary" /></label><label className="block text-xs font-bold text-muted-foreground">Đến ngày<input data-testid="input-report-end-date" type="date" value={endDate} onChange={(event) => setEndDate(event.target.value)} className="mt-2 h-11 w-full rounded-xl border border-input bg-background px-3 text-sm font-medium outline-none focus:border-primary" /></label></div>}{error && <p role="alert" className="mt-3 text-xs font-semibold text-destructive">{error}</p>}</section>
    <section className="grid gap-4 md:grid-cols-2 xl:grid-cols-4"><ReportStat label="Doanh thu" value={money(revenue)} note={`${revenueTransactions.length} khoản thu`} tone="primary" /><ReportStat label="Chi phí" value={money(expenses)} note={`${expenseTransactions.length} khoản chi`} tone="accent" /><ReportStat label="Lợi nhuận" value={money(profit)} note={profit >= 0 ? 'Đang dương trong kỳ' : 'Cần xem lại chi phí'} tone={profit >= 0 ? 'secondary' : 'accent'} /><ReportStat label="Tổng giao dịch" value={String(reportTransactions.length)} note={periodText} tone="muted" /></section>
    <section className="grid gap-5 xl:grid-cols-[1.1fr_.9fr]"><div className="rounded-2xl border border-card-border bg-card shadow-[var(--shadow-card)]"><div className="border-b border-border/70 px-5 py-4"><p className="font-serif text-lg">Tổng quan kỳ báo cáo</p><p className="mt-0.5 text-xs text-muted-foreground">{periodText} · Tạo ngày {createdAt}</p></div><div className="scrollbar-thin overflow-x-auto"><table className="w-full min-w-[480px] text-left"><thead><tr className="border-b border-border/70 text-[10px] uppercase tracking-wider text-muted-foreground"><th className="px-5 py-3 font-mono font-medium">Chỉ số</th><th className="px-5 py-3 text-right font-mono font-medium">Số tiền</th><th className="px-5 py-3 text-right font-mono font-medium">Tỷ trọng</th></tr></thead><tbody><ReportRow label="Doanh thu" amount={revenue} total={revenue + expenses} tone="primary" /><ReportRow label="Chi phí" amount={expenses} total={revenue + expenses} tone="accent" /><ReportRow label="Lợi nhuận" amount={profit} total={revenue || 1} tone={profit >= 0 ? 'primary' : 'accent'} bold /></tbody></table></div></div><div className="rounded-2xl border border-card-border bg-card shadow-[var(--shadow-card)]"><div className="border-b border-border/70 px-5 py-4"><p className="font-serif text-lg">Nhóm chi phí</p><p className="mt-0.5 text-xs text-muted-foreground">Phân bổ theo danh mục đã ghi sổ</p></div><div className="space-y-4 p-5">{expenseGroups.map(([category, amount]) => <div data-testid={`report-expense-group-${category}`} key={category}><div className="mb-1.5 flex items-center justify-between gap-3 text-xs"><span className="font-semibold">{category}</span><span className="font-mono text-accent">{money(amount)}</span></div><div className="h-2 overflow-hidden rounded-full bg-muted"><div className="h-full rounded-full bg-accent" style={{ width: `${expenses ? Math.max(5, (amount / expenses) * 100) : 0}%` }} /></div></div>)}{!expenseGroups.length && <EmptyState title="Chưa có chi phí" text="Không có khoản chi nào trong kỳ này." />}</div></div></section>
    <section className="rounded-2xl border border-card-border bg-card shadow-[var(--shadow-card)]"><div className="flex items-center justify-between border-b border-border/70 px-5 py-4"><div><p className="font-serif text-lg">{reportType === 'tong-hop' ? 'Chi tiết giao dịch' : reportTypeLabel(reportType)}</p><p className="mt-0.5 text-xs text-muted-foreground">{displayedTransactions.length} mục trong báo cáo</p></div><button data-testid="button-export-report-secondary" onClick={downloadReport} className="flex items-center gap-1.5 rounded-lg border border-border px-3 py-2 text-xs font-bold text-primary hover:bg-muted"><Download size={14} />Tải file</button></div>{displayedTransactions.length ? <TransactionTable transactions={displayedTransactions} onEdit={() => {}} onDelete={() => {}} compact /> : <EmptyState title="Chưa có giao dịch trong kỳ" text="Thử chọn khoảng thời gian khác để xem dữ liệu." />}</section>
  </div>;
}

function ReportStat({ label, value, note, tone }: { label: string; value: string; note: string; tone: 'primary' | 'accent' | 'secondary' | 'muted' }) {
  const iconTone = tone === 'primary' ? 'bg-primary/10 text-primary' : tone === 'accent' ? 'bg-accent/10 text-accent' : tone === 'secondary' ? 'bg-secondary text-secondary-foreground' : 'bg-muted text-muted-foreground';
  return <div className="card-lift rounded-2xl border border-card-border bg-card p-5 shadow-[var(--shadow-card)]"><div className="flex items-center justify-between"><p className="text-sm text-muted-foreground">{label}</p><span className={`grid h-8 w-8 place-items-center rounded-lg ${iconTone}`}><CircleDollarSign size={16} /></span></div><p className="mt-4 font-mono text-xl tracking-tight">{value}</p><p className="mt-2 truncate text-[10px] text-muted-foreground">{note}</p></div>;
}

function ReportRow({ label, amount, total, tone, bold = false }: { label: string; amount: number; total: number; tone: 'primary' | 'accent'; bold?: boolean }) {
  return <tr className={`border-b border-border/50 last:border-0 ${bold ? 'font-bold' : ''}`}><td className="px-5 py-4 text-sm">{label}</td><td className={`px-5 py-4 text-right font-mono text-sm ${tone === 'primary' ? 'text-primary' : 'text-accent'}`}>{money(amount)}</td><td className="px-5 py-4 text-right font-mono text-xs text-muted-foreground">{total ? `${Math.abs((amount / total) * 100).toFixed(1)}%` : '0%'}</td></tr>;
}

function TransactionTable({ transactions, onEdit, onDelete, compact = false }: { transactions: Transaction[]; onEdit: (item: Transaction) => void; onDelete: (id: string) => void; compact?: boolean }) {
  if (!transactions.length) return <EmptyState title="Chưa có giao dịch phù hợp" text="Thử đổi bộ lọc hoặc thêm một giao dịch mới." />;
  return <div className="scrollbar-thin overflow-x-auto"><table className="w-full min-w-[620px] text-left"><thead><tr className="border-b border-border/70 text-[10px] uppercase tracking-wider text-muted-foreground"><th className="px-5 py-3 font-mono font-medium">Ngày</th><th className="px-5 py-3 font-mono font-medium">Nội dung</th><th className="px-5 py-3 font-mono font-medium">Danh mục</th><th className="px-5 py-3 text-right font-mono font-medium">Số tiền</th>{!compact && <th className="w-20 px-5 py-3" />}</tr></thead><tbody>{transactions.map((item) => <tr data-testid={`row-transaction-${item.id}`} key={item.id} className="border-b border-border/50 last:border-0 transition-colors hover:bg-muted/35"><td className="whitespace-nowrap px-5 py-4 font-mono text-xs text-muted-foreground">{dateLabel(item.date)}</td><td className="max-w-[280px] px-5 py-4"><div className="flex min-w-0 items-center gap-3"><span className={`grid h-8 w-8 shrink-0 place-items-center rounded-lg ${item.type === 'thu' ? 'bg-primary/10 text-primary' : 'bg-destructive/10 text-destructive'}`}>{item.type === 'thu' ? <ArrowUpRight size={16} /> : <ArrowDownRight size={16} />}</span><span className="block truncate text-sm font-semibold" title={item.note}>{item.note}</span></div></td><td className="px-5 py-4 text-xs text-muted-foreground">{item.category}</td><td className={`px-5 py-4 text-right font-mono text-sm font-medium ${item.type === 'thu' ? 'text-primary' : 'text-destructive'}`}>{item.type === 'thu' ? '+' : '-'}{money(item.amount)}</td>{!compact && <td className="px-5 py-4"><div className="flex justify-end gap-1"><button data-testid={`button-edit-transaction-${item.id}`} aria-label={`Sửa ${item.note}`} onClick={() => onEdit(item)} className="rounded-lg p-2 text-muted-foreground hover:bg-muted hover:text-primary"><Pencil size={15} /></button><button data-testid={`button-delete-transaction-${item.id}`} aria-label={`Xóa ${item.note}`} onClick={() => onDelete(item.id)} className="rounded-lg p-2 text-muted-foreground hover:bg-muted hover:text-destructive"><Trash2 size={15} /></button></div></td>}</tr>)}</tbody></table></div>;
}

function Inventory({ ingredients, onAdd, onAdjust, onToggleLow }: { ingredients: Ingredient[]; onAdd: () => void; onAdjust: (item: Ingredient) => void; onToggleLow: (id: string) => void }) {
  const [search, setSearch] = useState('');
  const [filter, setFilter] = useState('tat-ca');
  const [horizon, setHorizon] = useState('7');
  const lowStock = ingredients.filter((item) => item.current < item.minimum);
  const visible = ingredients.filter((item) => item.name.toLowerCase().includes(search.toLowerCase()) && (filter === 'tat-ca' || (filter === 'thap' && item.current < item.minimum) || (filter === 'du' && item.current >= item.minimum)));
  return <div className="fade-up space-y-6"><div className="flex flex-col justify-between gap-4 md:flex-row md:items-end"><div><p className="text-sm text-muted-foreground">Biết hôm nay còn gì, và ngày mai cần mua gì.</p></div><button data-testid="button-add-ingredient" onClick={onAdd} className="flex w-fit items-center gap-2 rounded-xl bg-primary px-4 py-3 text-sm font-bold text-primary-foreground"><Plus size={17} />Thêm nguyên liệu</button></div>
    <div className="grid gap-4 md:grid-cols-3"><div className="rounded-2xl border border-card-border bg-card p-5 shadow-[var(--shadow-card)]"><div className="flex items-center justify-between"><span className="text-sm text-muted-foreground">Tổng mặt hàng</span><Boxes size={18} className="text-primary" /></div><p data-testid="value-total-ingredients" className="mt-4 font-mono text-3xl">{ingredients.length}</p><p className="mt-1 text-xs text-muted-foreground">đang theo dõi</p></div><div className="rounded-2xl border border-accent/25 bg-accent/5 p-5 shadow-[var(--shadow-card)]"><div className="flex items-center justify-between"><span className="text-sm text-muted-foreground">Sắp hết hàng</span><AlertTriangle size={18} className="text-accent" /></div><p data-testid="value-low-stock" className="mt-4 font-mono text-3xl text-accent">{lowStock.length}</p><p className="mt-1 text-xs text-muted-foreground">cần xử lý hôm nay</p></div><div className="rounded-2xl border border-card-border bg-card p-5 shadow-[var(--shadow-card)]"><div className="flex items-center justify-between"><span className="text-sm text-muted-foreground">Dự kiến mua</span><CalendarDays size={18} className="text-primary" /></div><p data-testid="value-forecast-cost" className="mt-4 font-mono text-2xl">{money(lowStock.reduce((sum, item) => sum + (item.minimum - item.current) * item.price, 0))}</p><p className="mt-1 text-xs text-muted-foreground">cho lần nhập tới</p></div></div>
    <div className="grid gap-5 xl:grid-cols-[1.45fr_1fr]"><div className="rounded-2xl border border-card-border bg-card shadow-[var(--shadow-card)]"><div className="flex flex-col gap-4 border-b border-border/70 p-5 md:flex-row md:items-center md:justify-between"><div><p className="font-serif text-lg">Mức tồn hiện tại</p><p className="mt-0.5 text-xs text-muted-foreground">{visible.length} nguyên liệu</p></div><div className="flex gap-2"><label className="relative flex-1 md:flex-none"><Search size={15} className="absolute left-3 top-2.5 text-muted-foreground" /><input data-testid="input-search-ingredients" value={search} onChange={(event) => setSearch(event.target.value)} placeholder="Tìm nguyên liệu..." className="h-9 w-full rounded-lg border border-input bg-background pl-9 pr-2 text-xs outline-none focus:border-primary md:w-44" /></label><select data-testid="select-stock-filter" value={filter} onChange={(event) => setFilter(event.target.value)} className="h-9 rounded-lg border border-input bg-background px-2 text-xs outline-none focus:border-primary"><option value="tat-ca">Tất cả</option><option value="thap">Sắp hết</option><option value="du">Đủ dùng</option></select></div></div><div className="scrollbar-thin overflow-x-auto"><table className="w-full min-w-[590px] text-left"><thead><tr className="border-b border-border/70 text-[10px] uppercase tracking-wider text-muted-foreground"><th className="px-5 py-3 font-mono font-medium">Nguyên liệu</th><th className="px-5 py-3 font-mono font-medium">Tồn kho</th><th className="px-5 py-3 font-mono font-medium">Trạng thái</th><th className="px-5 py-3" /></tr></thead><tbody>{visible.map((item) => { const low = item.current < item.minimum; return <tr data-testid={`row-ingredient-${item.id}`} key={item.id} className="border-b border-border/50 last:border-0 hover:bg-muted/35"><td className="px-5 py-4"><div className="flex items-center gap-3"><span className={`grid h-8 w-8 place-items-center rounded-lg ${low ? 'bg-accent/10 text-accent' : 'bg-secondary text-secondary-foreground'}`}><ShoppingBasket size={15} /></span><div><p className="text-sm font-bold">{item.name}</p><p className="mt-0.5 text-[10px] text-muted-foreground">{money(item.price)}/{item.unit}</p></div></div></td><td className="px-5 py-4"><p className="font-mono text-sm">{item.current} <span className="text-xs text-muted-foreground">{item.unit}</span></p><div className="mt-1 h-1 w-24 overflow-hidden rounded-full bg-muted"><span className={`block h-full rounded-full ${low ? 'bg-accent' : 'bg-primary'}`} style={{ width: `${Math.min(100, (item.current / (item.minimum * 1.5)) * 100)}%` }} /></div></td><td className="px-5 py-4"><button data-testid={`button-toggle-low-${item.id}`} onClick={() => onToggleLow(item.id)} className={`rounded-full px-2.5 py-1 text-[10px] font-bold ${low ? 'bg-accent/10 text-accent' : 'bg-primary/10 text-primary'}`}>{low ? 'Cần nhập' : 'Đủ dùng'}</button></td><td className="px-5 py-4 text-right"><button data-testid={`button-adjust-ingredient-${item.id}`} onClick={() => onAdjust(item)} className="rounded-lg border border-border px-2.5 py-1.5 text-[11px] font-bold text-primary hover:bg-muted">Điều chỉnh</button></td></tr>; })}</tbody></table>{!visible.length && <EmptyState title="Không tìm thấy nguyên liệu" text="Thử từ khoá khác hoặc thêm nguyên liệu mới." />}</div></div>
      <div className="rounded-2xl border border-card-border bg-card p-5 shadow-[var(--shadow-card)] md:p-6"><div className="flex items-start justify-between gap-3"><div><p className="font-serif text-lg">Dự báo nhập hàng</p><p className="mt-1 text-xs leading-5 text-muted-foreground">Ước tính dựa trên mức tối thiểu và tồn hiện tại.</p></div><select data-testid="select-forecast-horizon" value={horizon} onChange={(event) => setHorizon(event.target.value)} className="rounded-lg border border-input bg-background px-2 py-1.5 text-xs font-bold outline-none focus:border-primary"><option value="3">3 ngày</option><option value="7">7 ngày</option><option value="14">14 ngày</option></select></div><div className="mt-6 space-y-4">{lowStock.map((item) => <div data-testid={`forecast-${item.id}`} key={item.id}><div className="mb-1.5 flex justify-between text-xs"><span className="font-semibold">{item.name}</span><span className="font-mono text-accent">+{Math.ceil(item.minimum - item.current)} {item.unit}</span></div><div className="h-2 overflow-hidden rounded-full bg-muted"><div className="h-full rounded-full bg-accent" style={{ width: `${Math.min(100, ((item.minimum - item.current) / item.minimum) * 100 + 18)}%` }} /></div></div>)}{!lowStock.length && <EmptyState title="Không cần nhập thêm" text="Mức tồn hiện tại đang ổn." />}</div>{lowStock.length > 0 && <div className="mt-6 rounded-xl bg-secondary/70 p-4"><div className="flex gap-3"><CircleDollarSign size={18} className="mt-0.5 text-primary" /><p className="text-xs leading-5 text-secondary-foreground">Với khung {horizon} ngày, nên chuẩn bị khoảng <strong>{money(lowStock.reduce((sum, item) => sum + (item.minimum - item.current) * item.price, 0))}</strong> cho lần nhập tiếp theo.</p></div></div>}</div></div>
  </div>;
}

function weatherIcon(weather: SalesDay['weather'], size = 22) {
  if (weather === 'mưa') return <CloudRain size={size} />;
  if (weather === 'nhiều mây') return <CloudSun size={size} />;
  return <Sun size={size} />;
}
function weekdayLabel(value: string) {
  return new Intl.DateTimeFormat('vi-VN', { weekday: 'long' }).format(new Date(`${value}T12:00:00`));
}
function ForecastView({ forecast, history, runs, ingredients, mlForecast, mlForecastLoading, mlForecastError, onMlForecast, onRefresh, onAdjust, onConfirm }: { forecast: ForecastRun; history: SalesDay[]; runs: ForecastRun[]; ingredients: Ingredient[]; mlForecast: MlForecast | null; mlForecastLoading: boolean; mlForecastError: string; onMlForecast: (request: PredictRequest) => Promise<void>; onRefresh: () => void; onAdjust: (id: string, quantity: number) => void; onConfirm: (item: ForecastRecommendation) => void }) {
  const confirmedCount = forecast.recommendations.filter((item) => item.confirmed).length;
  const recentWaste = history.slice(-7).reduce((sum, item) => sum + item.waste, 0) / Math.max(1, history.slice(-7).length);
  const projectedWaste = recentWaste * .82;
  return <div className="fade-up space-y-6 md:space-y-8">
    <section className="forecast-shell relative overflow-hidden rounded-3xl border border-card-border p-5 shadow-[var(--shadow-card)] md:p-8">
      <div className="pointer-events-none absolute -right-16 -top-20 h-56 w-56 rounded-full border-[28px] border-primary/10" />
      <div className="relative grid gap-7 lg:grid-cols-[1.2fr_.8fr] lg:items-end">
        <div>
          <div className="flex flex-wrap items-center gap-2 text-[10px] font-bold uppercase tracking-[.18em] text-primary"><span className="rounded-full bg-primary/10 px-2.5 py-1">Ngày mai</span><span className="text-muted-foreground">{weekdayLabel(forecast.targetDate)} · {dateLabel(forecast.targetDate)}</span></div>
          <h2 data-testid="text-forecast-title" className="mt-4 max-w-xl font-serif text-3xl leading-tight text-foreground md:text-5xl">Chuẩn bị vừa đủ, để ca ngày mai nhẹ đầu hơn.</h2>
          <p className="mt-4 max-w-xl text-sm leading-6 text-muted-foreground">Dự báo dựa trên 60 ngày bán hàng, nhịp trong tuần và tín hiệu thời tiết mô phỏng. Đây là gợi ý thực tế để bạn quyết định nhanh hơn, không phải con số cố định.</p>
          <div className="mt-6 flex flex-wrap items-center gap-3">
            <button data-testid="button-refresh-forecast" onClick={onRefresh} className="flex items-center gap-2 rounded-xl bg-primary px-4 py-3 text-sm font-bold text-primary-foreground shadow-sm transition-transform hover:-translate-y-0.5"><RefreshCw size={16} />Cập nhật dự báo</button>
            <span className="flex items-center gap-2 rounded-xl border border-border bg-card/70 px-3 py-3 text-xs font-semibold text-muted-foreground"><span className="h-2 w-2 rounded-full bg-primary forecast-pulse" />Cập nhật lúc {new Intl.DateTimeFormat('vi-VN', { hour: '2-digit', minute: '2-digit' }).format(new Date(forecast.createdAt))}</span>
          </div>
        </div>
        <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-1">
          <div data-testid="card-weather-forecast" className="rounded-2xl bg-primary p-5 text-primary-foreground">
            <div className="flex items-start justify-between"><div><p className="text-xs text-primary-foreground/65">Thời tiết mô phỏng</p><p className="mt-2 font-serif text-2xl capitalize">{forecast.weather}</p></div><span className="grid h-11 w-11 place-items-center rounded-xl bg-primary-foreground/10 text-sidebar-primary">{weatherIcon(forecast.weather, 25)}</span></div>
            <p className="mt-5 font-mono text-sm text-primary-foreground/80">{forecast.temperature}°C · dự kiến trong ngày</p>
          </div>
          <div data-testid="card-confidence-forecast" className="rounded-2xl border border-card-border bg-card/80 p-5">
            <div className="flex items-center justify-between"><p className="text-xs text-muted-foreground">Độ tin cậy</p><span className="font-mono text-sm font-bold text-primary">{forecast.confidence}%</span></div>
            <div className="mt-4 h-2 overflow-hidden rounded-full bg-muted"><div className="h-full rounded-full bg-primary" style={{ width: `${forecast.confidence}%` }} /></div>
            <p className="mt-3 text-xs leading-5 text-muted-foreground">Đủ chắc để lên đơn nhập, vẫn nên kiểm tra lại sau ca tối.</p>
          </div>
        </div>
      </div>
    </section>

     <MlForecastPanel targetDate={forecast.targetDate} defaultWeather={forecast.weather} ingredients={ingredients} result={mlForecast} loading={mlForecastLoading} error={mlForecastError} onPredict={onMlForecast} />

    <section className="grid gap-5 xl:grid-cols-[1.35fr_.65fr]">
      <div className="rounded-2xl border border-card-border bg-card p-5 shadow-[var(--shadow-card)] md:p-6">
        <div className="mb-5 flex items-end justify-between gap-3"><div><p className="mb-1 font-mono text-[10px] uppercase tracking-[.18em] text-muted-foreground">Nhu cầu theo món</p><h3 className="font-serif text-2xl">Bếp nên chuẩn bị</h3></div><span className="rounded-full bg-secondary px-3 py-1.5 text-xs font-bold text-secondary-foreground">4 món chủ lực</span></div>
        <div className="grid gap-3 sm:grid-cols-2">
          {forecast.dishes.map((dish) => {
            const change = dish.servings - dish.previous;
            return <article data-testid={`card-dish-forecast-${dish.id}`} key={dish.id} className="rounded-2xl border border-border/70 bg-background/60 p-4 transition-transform hover:-translate-y-0.5">
              <div className="flex items-start justify-between gap-3"><span className="grid h-10 w-10 place-items-center rounded-xl bg-secondary font-serif text-lg text-secondary-foreground">{dish.name.slice(0, 1)}</span><span className={`rounded-full px-2 py-1 font-mono text-[10px] font-bold ${change >= 0 ? 'bg-primary/10 text-primary' : 'bg-accent/10 text-accent'}`}>{change >= 0 ? '+' : ''}{change} suất</span></div>
              <p className="mt-4 text-sm font-bold">{dish.name}</p><p className="mt-1 font-mono text-3xl tracking-tight">{dish.servings}<span className="ml-1 text-xs font-normal text-muted-foreground">suất</span></p>
              <p className="mt-3 border-t border-border/60 pt-3 text-[11px] leading-5 text-muted-foreground">{dish.ingredients}</p>
            </article>;
          })}
        </div>
      </div>
      <div data-testid="card-smart-alert" className="rounded-2xl border border-accent/25 bg-accent/5 p-5 shadow-[var(--shadow-card)] md:p-6">
        <div className="flex items-center gap-3"><span className="grid h-10 w-10 place-items-center rounded-xl bg-accent/12 text-accent"><Lightbulb size={19} /></span><div><p className="font-mono text-[10px] uppercase tracking-[.16em] text-accent">Cảnh báo thông minh</p><h3 className="mt-1 font-serif text-xl">Một việc đáng làm</h3></div></div>
        <div className="mt-6 flex items-center gap-3 rounded-xl bg-card/75 p-3"><span className="grid h-9 w-9 place-items-center rounded-lg bg-secondary text-secondary-foreground">{weatherIcon(forecast.weather, 18)}</span><p className="text-xs font-bold capitalize">{forecast.weather} · {weekdayLabel(forecast.targetDate)}</p></div>
        <p className="mt-5 text-sm leading-6 text-foreground">{forecast.weather === 'mưa' ? 'Giảm khoảng 20% đá và trà sữa đã sơ chế. Tăng 10% bánh phở, nước dùng và thịt bò cho nhu cầu món nóng.' : forecast.weather === 'nhiều mây' ? 'Giữ lượng món nóng cao hơn ngày thường một chút, đồ uống lạnh chuẩn bị theo từng ca để tránh dư.' : 'Trời khô ráo, đặt sẵn thêm đá và sữa cho ca sáng; ưu tiên chia nhỏ mẻ trà sữa để giữ vị.'}</p>
        <p className="mt-5 border-t border-accent/15 pt-4 text-xs leading-5 text-muted-foreground">Tín hiệu được rút ra từ {history.length} ngày lịch sử và thời tiết mô phỏng.</p>
      </div>
    </section>

    <section className="rounded-2xl border border-card-border bg-card p-5 shadow-[var(--shadow-card)] md:p-6">
      <div className="mb-5 flex flex-col justify-between gap-2 sm:flex-row sm:items-end"><div><p className="mb-1 font-mono text-[10px] uppercase tracking-[.18em] text-muted-foreground">Danh sách chuẩn bị</p><h3 className="font-serif text-2xl">Khuyến nghị nhập kho</h3></div><p className="text-xs text-muted-foreground">{confirmedCount}/{forecast.recommendations.length} mục đã xác nhận</p></div>
      <div className="grid gap-3 md:grid-cols-2 xl:grid-cols-3">
        {forecast.recommendations.map((item) => <RecommendationRow key={item.id} item={item} onAdjust={onAdjust} onConfirm={onConfirm} />)}
      </div>
    </section>

    <section className="grid gap-5 xl:grid-cols-[1.2fr_.8fr]">
      <UsageComparison forecast={forecast} />
      <WasteChart history={history} current={projectedWaste} previous={recentWaste} />
    </section>

    <section className="rounded-2xl border border-card-border bg-card p-5 shadow-[var(--shadow-card)] md:p-6">
      <div className="mb-5 flex items-end justify-between gap-3"><div><p className="mb-1 font-mono text-[10px] uppercase tracking-[.18em] text-muted-foreground">Nhật ký dự báo</p><h3 className="font-serif text-2xl">Lần chạy gần đây</h3></div><span className="text-xs text-muted-foreground">{runs.length} lần đã lưu trên thiết bị</span></div>
      <div className="divide-y divide-border/70">
        {runs.slice(0, 4).map((run) => {
          const confirmed = run.recommendations.filter((item) => item.confirmed).length;
          return <div data-testid={`row-forecast-history-${run.id}`} key={run.id} className="flex flex-wrap items-center gap-3 py-3 first:pt-0 last:pb-0"><span className="grid h-9 w-9 place-items-center rounded-lg bg-secondary text-secondary-foreground">{weatherIcon(run.weather, 17)}</span><div className="min-w-0 flex-1"><p className="truncate text-sm font-bold">{dateLabel(run.targetDate)} · {weekdayLabel(run.targetDate)}</p><p className="mt-1 text-[11px] text-muted-foreground">Chạy lúc {new Intl.DateTimeFormat('vi-VN', { hour: '2-digit', minute: '2-digit' }).format(new Date(run.createdAt))} · Độ tin cậy {run.confidence}%</p></div><span className={`flex items-center gap-1.5 rounded-full px-2.5 py-1.5 text-[10px] font-bold ${confirmed ? 'bg-primary/10 text-primary' : 'bg-muted text-muted-foreground'}`}>{confirmed ? <CheckCircle2 size={13} /> : <PackageCheck size={13} />}{confirmed ? `${confirmed} mục đã nhập` : 'Chưa xác nhận nhập kho'}</span></div>;
        })}
      </div>
    </section>
  </div>;
}

function weekdayCode(value: string) {
  return (new Date(`${value}T12:00:00`).getDay() + 6) % 7;
}

function adviceMentionsIngredient(advice: SmartAdvice, ingredientName: string) {
  const normalizedName = ingredientName.trim().toLowerCase();
  return advice.ingredients.some((ingredient) => {
    const normalizedIngredient = ingredient.trim().toLowerCase();
    return Boolean(normalizedIngredient) && (normalizedName.includes(normalizedIngredient) || normalizedIngredient.includes(normalizedName));
  });
}

function adviceSeverityLabel(severity: SmartAdvice['severity']) {
  if (severity === 'urgent') return 'Khẩn cấp';
  if (severity === 'high') return 'Ưu tiên cao';
  return 'Theo dõi';
}

function adviceSeverityClass(severity: SmartAdvice['severity']) {
  if (severity === 'urgent') return 'border-accent/35 bg-accent/[.08] text-accent';
  if (severity === 'high') return 'border-primary/25 bg-primary/[.06] text-primary';
  return 'border-border/70 bg-card text-muted-foreground';
}

function adviceTypeLabel(type: SmartAdvice['type']) {
  if (type === 'weather') return 'Thời tiết';
  if (type === 'clearance') return 'Xả hàng';
  if (type === 'peak_hour') return 'Giờ cao điểm';
  if (type === 'surge') return 'Tăng nhu cầu';
  return 'Tài chính';
}

function MlForecastPanel({ targetDate, defaultWeather, ingredients, result, loading, error, onPredict: onPredictRaw }: { targetDate: string; defaultWeather: SalesDay['weather']; ingredients: Ingredient[]; result: MlForecast | null; loading: boolean; error: string; onPredict: (request: PredictRequest) => Promise<void> }) {
  const [rainfall, setRainfall] = useState(defaultWeather === 'mưa' ? 35 : defaultWeather === 'nhiều mây' ? 12 : 0);
  const [holiday, setHoliday] = useState<PredictRequest['la_ngay_le']>(0);
  const [specialEvent, setSpecialEvent] = useState<PredictRequest['su_kien_dac_biet']>(0);
  const [temperature, setTemperature] = useState(defaultWeather === 'mưa' ? 25 : defaultWeather === 'nhiều mây' ? 28 : 32);
  const weather = 0;
  const localEvent = 0;
  const weekday = weekdayCode(targetDate);
  const weatherLabel = rainfall > 50 ? 'Mưa lớn' : rainfall > 0 ? 'Có mưa' : 'Nắng';
  const onPredict = (_legacy?: unknown) => onPredictRaw({
    ngay_trong_tuan: weekday,
    la_ngay_le: holiday,
    nhiet_do: temperature,
    luong_mua: rainfall,
    su_kien_dac_biet: specialEvent,
    inventory: ingredients.map((item) => ({
      name: item.name,
      unit: item.unit,
      quantity: item.current,
      shelf_life_days: item.shelfLifeDays ?? 7,
    })),
  });
  const chartData = result ? {
    labels: result.shopping_list.map((item) => item.name),
    datasets: [{
      label: 'Khối lượng cần mua',
      data: result.shopping_list.map((item) => item.to_buy),
      backgroundColor: '#2f6f5e',
      borderRadius: 7,
      borderSkipped: false,
    }],
  } : null;

  return <section data-testid="card-ml-forecast" aria-busy={loading} className="rounded-2xl border border-primary/20 bg-primary/[.035] p-5 shadow-[var(--shadow-card)] md:p-6">
    <div className="flex flex-col justify-between gap-4 lg:flex-row lg:items-start">
      <div>
        <div className="flex items-center gap-2"><span className="grid h-9 w-9 place-items-center rounded-xl bg-primary text-primary-foreground"><TrendingUp size={17} /></span><div><p className="font-mono text-[10px] uppercase tracking-[.18em] text-primary">Machine Learning</p><h3 className="mt-1 font-serif text-2xl">Dự báo nguyên liệu bằng dữ liệu thật</h3></div></div>
         <p className="mt-3 max-w-2xl text-xs leading-5 text-muted-foreground">Random Forest học từ 60 ngày bán hàng với nhiệt độ, lượng mưa, ngày trong tuần, ngày lễ và sự kiện đặc biệt. Cận trên dự báo được đối chiếu với tồn kho để tính số lượng cần mua.</p>
      </div>
       <div className="flex shrink-0 items-center gap-2 rounded-full bg-card px-3 py-2 text-[10px] font-bold text-muted-foreground"><span className={`h-2 w-2 rounded-full bg-primary ${loading ? 'animate-pulse' : ''}`} />{loading ? 'Đang đồng bộ mô hình' : `${weekdayLabel(targetDate)} · ${dateLabel(targetDate)}`}</div>
    </div>
     <div className="mt-6 grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
      <label className="block text-xs font-bold text-muted-foreground">Lượng mưa (mm)<select data-testid="select-ml-rainfall" value={rainfall} onChange={(event) => setRainfall(Number(event.target.value))} className="mt-2 h-11 w-full rounded-xl border border-input bg-card px-3 text-sm font-semibold text-foreground outline-none focus:border-primary"><option value={0}>Không mưa</option><option value={12}>Mưa vừa · 12 mm</option><option value={35}>Mưa · 35 mm</option><option value={60}>Mưa lớn · 60 mm</option></select></label>
      <label className="block text-xs font-bold text-muted-foreground">Ngày lễ<select data-testid="select-ml-holiday" value={holiday} onChange={(event) => setHoliday(Number(event.target.value) as PredictRequest['la_ngay_le'])} className="mt-2 h-11 w-full rounded-xl border border-input bg-card px-3 text-sm font-semibold text-foreground outline-none focus:border-primary"><option value={0}>Không phải ngày lễ</option><option value={1}>Có ngày lễ</option></select></label>
      <label className="block text-xs font-bold text-muted-foreground">Nhiệt độ (°C)<input data-testid="input-ml-temperature" type="number" min="0" max="60" value={temperature} onChange={(event) => setTemperature(Number(event.target.value) || 0)} className="mt-2 h-11 w-full rounded-xl border border-input bg-card px-3 text-sm font-semibold text-foreground outline-none focus:border-primary" /></label>
       <label className="flex min-h-11 items-center gap-3 rounded-xl border border-input bg-card px-3 py-2 text-xs font-bold text-muted-foreground lg:col-span-2"><input data-testid="checkbox-ml-special-event" type="checkbox" checked={specialEvent === 1} onChange={(event) => setSpecialEvent(event.target.checked ? 1 : 0)} className="h-4 w-4 shrink-0 accent-[hsl(var(--primary))]" /><span>Có sự kiện đặc biệt vào ngày mai</span></label>
       <button data-testid="button-run-ml-forecast" onClick={() => onPredict({ thu_trong_tuan: weekday, la_ngay_le: holiday, thoi_tiet: weather, nhiet_do: temperature, su_kien_dia_phuong: localEvent })} disabled={loading} className="mt-auto flex h-11 items-center justify-center gap-2 rounded-xl bg-primary px-4 text-sm font-bold text-primary-foreground shadow-sm transition-transform hover:-translate-y-0.5 disabled:cursor-wait disabled:opacity-60">{loading ? <RefreshCw size={16} className="animate-spin" /> : <Lightbulb size={16} />}{loading ? 'Đang dự báo...' : 'Dự báo ngay'}</button>
    </div>
    <div className="mt-3 flex flex-wrap items-center gap-2 text-[11px] text-muted-foreground"><span className="rounded-full bg-card px-2.5 py-1">Thứ {weekday + 2}</span><span className="rounded-full bg-card px-2.5 py-1">{weatherLabel}</span><span className="rounded-full bg-card px-2.5 py-1">{temperature}°C</span></div>
     {error && <p role="alert" className="mt-4 rounded-xl border border-accent/25 bg-accent/10 px-3 py-2.5 text-xs font-semibold text-accent">{error}</p>}
     {loading && <div data-testid="status-ml-loading" role="status" className="mt-6 space-y-3 rounded-2xl border border-primary/15 bg-card/65 p-4">
       <div className="flex items-center gap-3"><span className="grid h-9 w-9 place-items-center rounded-xl bg-primary/10"><RefreshCw size={16} className="animate-spin text-primary" /></span><div className="space-y-2"><div className="skeleton-shimmer h-3 w-48 rounded-full" /><div className="skeleton-shimmer h-2.5 w-64 max-w-[70vw] rounded-full" /></div></div>
       <div className="grid gap-2 sm:grid-cols-3"><div className="skeleton-shimmer h-10 rounded-xl" /><div className="skeleton-shimmer h-10 rounded-xl" /><div className="skeleton-shimmer h-10 rounded-xl" /></div>
       <p className="text-xs font-semibold text-muted-foreground">Đang phân tích tồn kho và tín hiệu thời tiết, thường mất vài giây.</p>
     </div>}
    {result && <div data-testid="panel-ml-result" className="mt-6 border-t border-primary/15 pt-6">
       <div className="flex flex-col justify-between gap-2 sm:flex-row sm:items-end"><div><p className="font-mono text-[10px] uppercase tracking-[.18em] text-primary">Kết quả mô hình</p><h4 className="mt-1 font-serif text-xl">Tổng nguyên liệu cần nhập</h4></div><div className="flex flex-wrap gap-2 text-[10px] font-bold text-muted-foreground"><span className="rounded-full bg-card px-2.5 py-1">{result.model}</span><span className="rounded-full bg-card px-2.5 py-1">{result.training_days} ngày học</span><span className="rounded-full bg-primary/10 px-2.5 py-1 text-primary">Độ tin cậy {result.confidence}%</span></div></div>
      <div className="mt-5 grid gap-5 xl:grid-cols-[1.2fr_.8fr]">
         <div className="overflow-hidden rounded-xl border border-border/70 bg-card">
           <div className="scrollbar-thin overflow-x-auto"><table className="w-full min-w-[600px] text-left"><thead><tr className="border-b border-border/70 text-[10px] uppercase tracking-wider text-muted-foreground"><th className="px-4 py-3 font-mono font-medium">Nguyên liệu</th><th className="px-4 py-3 font-mono font-medium">Cận trên cần</th><th className="px-4 py-3 font-mono font-medium">Đang có</th><th className="px-4 py-3 text-right font-mono font-medium">Cần mua</th></tr></thead><tbody>{result.shopping_list.map((item) => {
             const clearanceAdvice = result.operational_alerts.find((advice) => advice.type === 'clearance' && adviceMentionsIngredient(advice, item.name));
             return <tr data-testid={`row-ml-ingredient-${item.id}`} key={`${item.id}-${item.unit}`} className={`border-b border-border/50 last:border-0 ${clearanceAdvice ? 'bg-accent/[.045]' : ''}`}>
               <td className="px-4 py-3 text-sm font-semibold"><div className="flex flex-wrap items-center gap-2"><span>{item.name}</span>{clearanceAdvice && <span data-testid={`badge-clearance-${item.id}`} className="animate-pulse rounded-full bg-accent/15 px-2 py-1 text-[9px] font-bold uppercase tracking-wide text-accent">Cần xả hàng khẩn cấp</span>}</div></td>
               <td className="px-4 py-3 font-mono text-sm text-primary">{item.upper_need.toFixed(2)} <span className="text-xs font-normal text-muted-foreground">{item.unit}</span></td>
               <td className="px-4 py-3 font-mono text-sm text-muted-foreground">{item.inventory.toFixed(2)} <span className="text-xs font-normal">{item.unit}</span></td>
               <td className="px-4 py-3 text-right font-mono text-sm font-bold text-accent">{item.to_buy.toFixed(2)} <span className="text-xs font-normal">{item.unit}</span></td>
             </tr>;
           })}</tbody></table></div>
        </div>
        <div data-testid="chart-ml-ingredients" className="rounded-xl border border-border/70 bg-card p-4"><div className="flex items-center justify-between"><div><p className="font-mono text-[10px] uppercase tracking-[.16em] text-muted-foreground">Chart.js · BOM</p><p className="mt-1 text-sm font-bold">Khối lượng cần mua</p></div><span className="text-[10px] text-muted-foreground">kg / lít</span></div><div className="mt-5 h-64">{chartData && <Bar data={chartData} options={{ responsive: true, maintainAspectRatio: false, plugins: { legend: { display: false }, tooltip: { callbacks: { label: (context) => ` ${Number(context.raw).toFixed(2)} ${result.shopping_list[context.dataIndex]?.unit ?? ''}` } } }, scales: { x: { ticks: { color: '#718078', font: { size: 10 } }, grid: { display: false } }, y: { beginAtZero: true, ticks: { color: '#718078', font: { size: 10 } }, grid: { color: 'rgba(113,128,120,.16)' } } } }} />}</div></div>
      </div>
       <p className="mt-4 rounded-xl bg-secondary/60 px-3 py-2.5 text-xs leading-5 text-secondary-foreground">Công thức BOM đã dùng: 1 bát Phở = 0,15 kg bánh phở + 0,10 kg thịt bò + 0,30 lít nước dùng. Các món còn lại được quy đổi theo định lượng chuẩn của quán.</p>
       <AiAdvicePanel advice={result.operational_alerts} recommendations={result.shopping_list} />
    </div>}
  </section>;
}

function AiAdvicePanel({ advice, recommendations }: { advice: SmartAdvice[]; recommendations: Array<Pick<ShoppingListItem, 'name'>> }) {
  return <section data-testid="panel-ai-advice" className="mt-6 rounded-2xl border border-primary/25 bg-card/80 p-4 shadow-[var(--shadow-card)] md:p-5">
    <div className="flex flex-col justify-between gap-3 border-b border-border/70 pb-4 sm:flex-row sm:items-center">
      <div>
        <p className="font-mono text-[10px] uppercase tracking-[.18em] text-primary">Hành động tiếp theo</p>
         <h4 data-testid="text-ai-advice-title" className="mt-1 font-serif text-2xl">Gợi ý từ trợ lý AI</h4>
      </div>
      <span className={`w-fit rounded-full px-2.5 py-1 text-[10px] font-bold ${advice.length ? 'bg-accent/10 text-accent' : 'bg-primary/10 text-primary'}`}>{advice.length ? `${advice.length} cảnh báo cần xem` : 'Không có cảnh báo'}</span>
    </div>
    {advice.length === 0 ? <div data-testid="status-ai-advice-stable" className="mt-4 flex items-start gap-3 rounded-xl border border-primary/15 bg-primary/[.045] p-4"><CheckCircle2 size={19} className="mt-0.5 shrink-0 text-primary" /><div><p className="text-sm font-bold text-foreground">Tín hiệu đang ổn định</p><p className="mt-1 text-xs leading-5 text-muted-foreground">Chưa có cảnh báo hành động từ mô hình. Bạn có thể giữ kế hoạch nhập hàng hiện tại và kiểm tra lại sau ca.</p></div></div> : <div className="mt-4 grid gap-3 xl:grid-cols-2">
      {advice.map((item, index) => {
        const isClearance = item.type === 'clearance';
        const relatedRecommendations = recommendations.filter((recommendation) => adviceMentionsIngredient(item, recommendation.name));
        return <article data-testid={`card-ai-advice-${index}`} key={`${item.type}-${item.title}-${index}`} className={`rounded-xl border p-4 ${adviceSeverityClass(item.severity)}`}>
          <div className="flex items-start gap-3">
            <span className={`grid h-9 w-9 shrink-0 place-items-center rounded-lg ${item.severity === 'urgent' ? 'bg-accent/15' : item.severity === 'high' ? 'bg-primary/12' : 'bg-muted'}`}>{item.severity === 'urgent' ? <AlertTriangle size={17} /> : item.type === 'financial' ? <CircleDollarSign size={17} /> : <TrendingUp size={17} />}</span>
            <div className="min-w-0 flex-1">
              <div className="flex flex-wrap items-start justify-between gap-2">
                <div><p className="text-[10px] font-bold uppercase tracking-[.14em] opacity-75">{adviceTypeLabel(item.type)}</p><h5 data-testid={`text-ai-advice-title-${index}`} className="mt-1 text-sm font-bold">{item.title}</h5></div>
                <span data-testid={`badge-ai-advice-severity-${index}`} className="rounded-full border border-current/20 px-2 py-1 text-[9px] font-bold">{adviceSeverityLabel(item.severity)}</span>
              </div>
              <p data-testid={`text-ai-advice-message-${index}`} className="mt-3 text-xs leading-5 text-foreground/80">{item.message}</p>
              <p data-testid={`text-ai-advice-action-${index}`} className="mt-3 rounded-lg bg-background/55 px-3 py-2 text-xs font-bold leading-5 text-foreground">Việc nên làm: {item.action}</p>
              <div className="mt-3">
                <p className="text-[10px] font-bold uppercase tracking-[.14em] opacity-70">Nguyên liệu liên quan</p>
                {item.ingredients.length ? <ul className="mt-2 flex flex-wrap gap-1.5">{item.ingredients.map((ingredient) => <li data-testid={`text-ai-advice-ingredient-${index}-${ingredient}`} key={ingredient} className="rounded-full border border-current/15 bg-background/45 px-2 py-1 text-[10px] font-semibold">{ingredient}</li>)}</ul> : <p className="mt-2 text-xs opacity-70">Không có nguyên liệu cụ thể.</p>}
              </div>
              {isClearance && relatedRecommendations.length > 0 && <p className="mt-3 text-[10px] font-semibold opacity-75">Các dòng liên quan đã được đánh dấu trong bảng nhập hàng.</p>}
            </div>
          </div>
        </article>;
      })}
    </div>}
  </section>;
}

function RecommendationRow({ item, onAdjust, onConfirm }: { item: ForecastRecommendation; onAdjust: (id: string, quantity: number) => void; onConfirm: (item: ForecastRecommendation) => void }) {
  return <article data-testid={`card-recommendation-${item.id}`} className={`rounded-2xl border p-4 ${item.confirmed ? 'border-primary/25 bg-primary/5' : 'border-border/70 bg-background/60'}`}>
    <div className="flex items-start gap-3"><span className="grid h-10 w-10 shrink-0 place-items-center rounded-xl bg-secondary text-secondary-foreground"><ShoppingBasket size={17} /></span><div className="min-w-0 flex-1"><div className="flex items-start justify-between gap-2"><p className="text-sm font-bold">{item.name}</p><p className="font-mono text-[10px] text-muted-foreground">{money(item.quantity * item.price)}</p></div><p className="mt-1 text-xs text-muted-foreground">Lượng nên chuẩn bị cho ngày mai</p></div></div>
    <div className="mt-4 flex items-center gap-2"><button data-testid={`button-decrease-recommendation-${item.id}`} aria-label={`Giảm ${item.name}`} onClick={() => onAdjust(item.id, item.quantity - .5)} className="grid h-9 w-9 place-items-center rounded-lg border border-border text-muted-foreground hover:bg-muted"><Minus size={15} /></button><label className="flex h-9 min-w-0 flex-1 items-center justify-center rounded-lg border border-input bg-card px-2"><input data-testid={`input-recommendation-${item.id}`} aria-label={`Số lượng ${item.name}`} type="number" step=".1" value={item.quantity} onChange={(event) => onAdjust(item.id, Number(event.target.value) || .1)} className="w-16 bg-transparent text-center font-mono text-sm outline-none" /><span className="text-xs text-muted-foreground">{item.unit}</span></label><button data-testid={`button-increase-recommendation-${item.id}`} aria-label={`Tăng ${item.name}`} onClick={() => onAdjust(item.id, item.quantity + .5)} className="grid h-9 w-9 place-items-center rounded-lg border border-border text-muted-foreground hover:bg-muted"><Plus size={15} /></button></div>
    <button data-testid={`button-confirm-recommendation-${item.id}`} onClick={() => !item.confirmed && onConfirm(item)} disabled={item.confirmed} className={`mt-3 flex w-full items-center justify-center gap-2 rounded-lg py-2.5 text-xs font-bold transition-colors ${item.confirmed ? 'cursor-default bg-primary/10 text-primary' : 'bg-primary text-primary-foreground hover:opacity-90'}`}>{item.confirmed ? <CheckCircle2 size={15} /> : <PackageCheck size={15} />}{item.confirmed ? 'Đã xác nhận nhập kho' : 'Xác nhận nhập kho'}</button>
  </article>;
}

function UsageComparison({ forecast }: { forecast: ForecastRun }) {
  const max = Math.max(...forecast.dishes.map((item) => Math.max(item.servings, item.previous)), 1);
  return <section data-testid="card-usage-comparison" className="rounded-2xl border border-card-border bg-card p-5 shadow-[var(--shadow-card)] md:p-6"><div className="mb-5 flex items-end justify-between gap-3"><div><p className="mb-1 font-mono text-[10px] uppercase tracking-[.18em] text-muted-foreground">Đối chiếu</p><h3 className="font-serif text-2xl">Dự báo & mức dùng quen</h3></div><div className="flex gap-3 text-[10px] text-muted-foreground"><span className="flex items-center gap-1.5"><i className="h-2 w-2 rounded-full bg-primary" />Ngày mai</span><span className="flex items-center gap-1.5"><i className="h-2 w-2 rounded-full bg-secondary-foreground/35" />Trung bình</span></div></div><div className="space-y-4">{forecast.dishes.map((dish) => <div data-testid={`row-usage-${dish.id}`} key={dish.id}><div className="mb-1.5 flex justify-between text-xs"><span className="font-semibold">{dish.name}</span><span className="font-mono text-muted-foreground">{dish.servings} / {dish.previous} suất</span></div><div className="flex h-2 gap-1"><span className="rounded-full bg-primary" style={{ width: `${(dish.servings / max) * 100}%` }} /><span className="rounded-full bg-secondary-foreground/25" style={{ width: `${(dish.previous / max) * 100}%` }} /></div></div>)}</div><p className="mt-6 rounded-xl bg-secondary/60 p-3 text-xs leading-5 text-secondary-foreground">Dự báo giữ biên an toàn nhỏ để quán không thiếu món, nhưng không đẩy bạn vào việc nhập dư.</p></section>;
}

function WasteChart({ history, current, previous }: { history: SalesDay[]; current: number; previous: number }) {
  const points = history.slice(-7).map((item, index) => ({ x: 18 + index * 38, y: 94 - (item.waste / 7) * 62 }));
  const line = points.map((point) => `${point.x},${point.y}`).join(' ');
  const area = `${points[0]?.x ?? 18},100 ${line} ${points[points.length - 1]?.x ?? 246},100`;
  const reduction = Math.round((1 - current / Math.max(previous, .1)) * 100);
  return <section data-testid="card-waste-chart" className="rounded-2xl border border-card-border bg-card p-5 shadow-[var(--shadow-card)] md:p-6"><div className="flex items-start justify-between gap-3"><div><p className="mb-1 font-mono text-[10px] uppercase tracking-[.18em] text-muted-foreground">Hiệu quả tuần</p><h3 className="font-serif text-2xl">Giảm lãng phí</h3></div><span className="rounded-full bg-primary/10 px-2.5 py-1 font-mono text-xs font-bold text-primary">-{reduction}%</span></div><div className="mt-5 rounded-xl bg-background/70 p-3"><svg viewBox="0 0 246 112" className="h-36 w-full overflow-visible" role="img" aria-label="Biểu đồ lãng phí bảy ngày"><line x1="18" y1="25" x2="246" y2="25" className="forecast-grid-line" /><line x1="18" y1="62" x2="246" y2="62" className="forecast-grid-line" /><line x1="18" y1="100" x2="246" y2="100" className="forecast-grid-line" /><polygon points={area} className="forecast-chart-area" /><polyline points={line} className="forecast-chart-line" />{points.map((point, index) => <circle key={index} cx={point.x} cy={point.y} r="3.5" fill="hsl(var(--card))" stroke="hsl(var(--primary))" strokeWidth="2" />)}</svg><div className="flex justify-between px-1 text-[10px] text-muted-foreground"><span>7 ngày trước</span><span>Hôm nay</span></div></div><div className="mt-4 grid grid-cols-2 gap-2"><div className="rounded-xl bg-muted/70 p-3"><p className="text-[10px] text-muted-foreground">Mức cũ</p><p className="mt-1 font-mono text-lg">{previous.toFixed(1)} kg</p></div><div className="rounded-xl bg-primary/8 p-3"><p className="text-[10px] text-muted-foreground">Mục tiêu mới</p><p className="mt-1 font-mono text-lg text-primary">{current.toFixed(1)} kg</p></div></div></section>;
}

function AppIconPreview() {
  return <section data-testid="card-app-icon-preview" className="rounded-2xl border border-card-border bg-card p-5 shadow-[var(--shadow-card)] md:p-6">
    <div className="flex items-start gap-3">
      <span className="grid h-10 w-10 shrink-0 place-items-center rounded-xl bg-primary/10 text-primary"><Smartphone size={19} /></span>
      <div>
        <p className="font-mono text-[10px] uppercase tracking-[.18em] text-primary">Launcher icon</p>
        <h3 className="mt-1 font-serif text-2xl">Xem trước biểu tượng Resto.AI</h3>
        <p className="mt-2 max-w-xl text-sm leading-6 text-muted-foreground">Biểu tượng vector mới được tối ưu cho màn hình chính iOS, Android và PWA.</p>
      </div>
    </div>
    <div className="mt-6 flex justify-center">
      <div data-testid="preview-app-icon-phone" className="w-64 rounded-[2.25rem] border-[7px] border-foreground/90 bg-background p-3 shadow-2xl">
        <div className="mx-auto mb-5 h-1.5 w-20 rounded-full bg-foreground/20" />
        <div className="grid grid-cols-3 gap-x-4 gap-y-5 px-2 pb-5">
          <div className="grid justify-items-center gap-1.5"><img data-testid="img-app-icon-preview" src="/static/app-icon.svg" alt="Preview icon Resto.AI" className="h-14 w-14 rounded-[1rem] shadow-lg" /><span className="max-w-16 truncate text-[9px] font-semibold">Resto.AI</span></div>
          <div className="grid justify-items-center gap-1.5"><span className="h-14 w-14 rounded-[1rem] bg-secondary/80" /><span className="h-2 w-10 rounded-full bg-muted" /></div>
          <div className="grid justify-items-center gap-1.5"><span className="h-14 w-14 rounded-[1rem] bg-secondary/80" /><span className="h-2 w-10 rounded-full bg-muted" /></div>
          <div className="grid justify-items-center gap-1.5"><span className="h-14 w-14 rounded-[1rem] bg-secondary/80" /><span className="h-2 w-10 rounded-full bg-muted" /></div>
          <div className="grid justify-items-center gap-1.5"><span className="h-14 w-14 rounded-[1rem] bg-secondary/80" /><span className="h-2 w-10 rounded-full bg-muted" /></div>
          <div className="grid justify-items-center gap-1.5"><span className="h-14 w-14 rounded-[1rem] bg-secondary/80" /><span className="h-2 w-10 rounded-full bg-muted" /></div>
        </div>
        <div className="h-14 rounded-2xl bg-foreground/[.06]" />
      </div>
    </div>
  </section>;
}

function SettingsView({ profile, onSave }: { profile: Profile; onSave: (profile: Profile) => void }) {
  const [form, setForm] = useState(profile);
  return <div className="fade-up max-w-4xl space-y-7"><div><p className="text-sm text-muted-foreground">Thông tin này giúp Resto.AI trở nên đúng với nhịp vận hành của bạn.</p></div><div className="grid gap-5 lg:grid-cols-[1.1fr_.9fr]"><section className="rounded-2xl border border-card-border bg-card p-5 shadow-[var(--shadow-card)] md:p-7"><div className="mb-7 flex items-center gap-4"><span className="grid h-14 w-14 place-items-center rounded-2xl bg-secondary font-serif text-xl text-secondary-foreground">MA</span><div><p className="font-serif text-xl">{form.restaurant}</p><p className="mt-1 text-xs text-muted-foreground">Hồ sơ người quản lý</p></div></div><div className="space-y-5"><Field label="Tên hiển thị" testId="input-profile-name" value={form.name} onChange={(value) => setForm({ ...form, name: value })} /><Field label="Tên quán" testId="input-profile-restaurant" value={form.restaurant} onChange={(value) => setForm({ ...form, restaurant: value })} /><div className="grid gap-5 sm:grid-cols-2"><Field label="Email" testId="input-profile-email" value={form.email} onChange={(value) => setForm({ ...form, email: value })} type="email" /><Field label="Số điện thoại" testId="input-profile-phone" value={form.phone} onChange={(value) => setForm({ ...form, phone: value })} /></div></div><button data-testid="button-save-profile" onClick={() => onSave(form)} className="mt-7 flex items-center gap-2 rounded-xl bg-primary px-4 py-3 text-sm font-bold text-primary-foreground"><Save size={16} />Lưu thay đổi</button></section><div className="space-y-5"><section className="rounded-2xl border border-card-border bg-card p-5 shadow-[var(--shadow-card)] md:p-6"><div className="mb-5 flex items-center gap-3"><span className="grid h-9 w-9 place-items-center rounded-lg bg-secondary text-secondary-foreground"><Bell size={17} /></span><div><p className="font-serif text-lg">Nhắc việc</p><p className="text-xs text-muted-foreground">Để quán không bỏ lỡ điều cần làm</p></div></div><button data-testid="button-toggle-notifications" onClick={() => setForm({ ...form, notifications: !form.notifications })} className="flex w-full items-center justify-between border-t border-border/70 pt-4 text-left"><div><p className="text-sm font-bold">Cảnh báo tồn kho thấp</p><p className="mt-1 text-xs text-muted-foreground">Nhắc bạn trước mỗi ca làm việc</p></div><span className={`relative h-6 w-11 rounded-full transition-colors ${form.notifications ? 'bg-primary' : 'bg-muted'}`}><span className={`absolute top-1 h-4 w-4 rounded-full bg-card shadow-sm transition-transform ${form.notifications ? 'translate-x-6' : 'translate-x-1'}`} /></span></button></section><section className="rounded-2xl border border-card-border bg-card p-5 shadow-[var(--shadow-card)] md:p-6"><div className="mb-5 flex items-center gap-3"><span className="grid h-9 w-9 place-items-center rounded-lg bg-secondary text-secondary-foreground"><CalendarDays size={17} /></span><div><p className="font-serif text-lg">Tuần làm việc</p><p className="text-xs text-muted-foreground">Cách hiển thị báo cáo</p></div></div><label className="block text-xs font-bold text-muted-foreground">Ngày bắt đầu tuần<select data-testid="select-week-start" value={form.weekStart} onChange={(event) => setForm({ ...form, weekStart: event.target.value })} className="mt-2 h-11 w-full rounded-xl border border-input bg-background px-3 text-sm font-semibold outline-none focus:border-primary"><option value="thứ hai">Thứ hai</option><option value="chủ nhật">Chủ nhật</option></select></label></section></div></div></div>;
}

function Field({ label, testId, value, onChange, type = 'text' }: { label: string; testId: string; value: string; onChange: (value: string) => void; type?: string }) {
  return <label className="block text-xs font-bold text-muted-foreground">{label}<input data-testid={testId} type={type} value={value} onChange={(event) => onChange(event.target.value)} className="mt-2 h-11 w-full rounded-xl border border-input bg-background px-3 text-sm font-medium text-foreground outline-none transition-colors focus:border-primary focus:ring-2 focus:ring-primary/10" /></label>;
}

function ShoppingWorkspace({ ingredients, mlForecast, onRefresh, onConfirm, onNotify }: { ingredients: Ingredient[]; mlForecast: MlForecast | null; onRefresh: () => void; onConfirm: (item: ForecastRecommendation) => void; onNotify: (message: string, tone?: ToastTone) => void }) {
  const sourceItems = mlForecast?.shopping_list.filter((item) => item.to_buy > 0) ?? ingredients.filter((item) => item.current < item.minimum).map((item) => ({ id: item.id, name: item.name, unit: item.unit, to_buy: Number((item.minimum - item.current).toFixed(1)), price: item.price, urgent: item.current < item.minimum * .65, shelf_life_days: item.shelfLifeDays ?? 7 }));
  const items = sourceItems.map((item) => {
    const ingredient = ingredients.find((candidate) => candidate.id === item.id || candidate.name === item.name);
    return { ...item, supplier: supplierForIngredient(ingredient ?? { id: item.id }), supplierContact: supplierContactByName[supplierForIngredient(ingredient ?? { id: item.id })] ?? 'SMS nhà cung cấp' };
  });
  const total = items.reduce((sum, item) => sum + item.to_buy * item.price, 0);
  const supplierGroups = Array.from(new Set(items.map((item) => item.supplier))).map((supplier) => ({ supplier, items: items.filter((item) => item.supplier === supplier) }));
  const dispatchOrder = async (supplier: string, supplierItems: typeof items) => {
    const orderText = [`Đơn đặt hàng ngày mai cho quán Bếp Nhà Mình`, `Nhà cung cấp: ${supplier}`, '', ...supplierItems.map((item, index) => `${index + 1}. ${item.name}: ${item.to_buy} ${item.unit}`), '', 'Gửi từ Resto.AI'].join('\n');
    try {
      await navigator.clipboard?.writeText(orderText);
    } catch {
      // Clipboard can be unavailable in an iframe; continue to the share/SMS fallback.
    }
    if (typeof navigator.share === 'function') {
      try {
        await navigator.share({ title: `Đơn nhập hàng · ${supplier}`, text: orderText });
        onNotify(`Đã mở bảng chia sẻ đơn hàng cho ${supplier}`);
        return;
      } catch {
        // User may close the share sheet; SMS fallback keeps the order text available.
      }
    }
    window.open(`sms:?body=${encodeURIComponent(orderText)}`, '_self');
    onNotify(`Đã sao chép đơn và mở SMS cho ${supplier}`);
  };
  return <div data-testid="workspace-shopping" className="workspace-page space-y-5 md:space-y-6">
    <section className="workspace-hero flex flex-col justify-between gap-4 md:flex-row md:items-end"><div><p className="workspace-eyebrow text-primary">AI Procurement · Manager Mode</p><h2 className="mt-2 font-serif text-3xl md:text-5xl">Đi chợ đúng lượng, đúng lúc.</h2><p className="mt-3 max-w-2xl text-sm leading-6 text-muted-foreground">Danh sách này kết hợp dự báo nhu cầu, hạn sử dụng và tồn kho hiện tại để tránh mua thiếu hoặc tồn dư.</p></div><button data-testid="button-refresh-shopping" onClick={onRefresh} className="flex w-fit items-center gap-2 rounded-xl bg-primary px-4 py-3 text-sm font-bold text-primary-foreground"><RefreshCw size={16} />Cập nhật danh sách</button></section>
    <section className="grid gap-3 sm:grid-cols-3"><div className="workspace-metric border-primary/20"><span className="workspace-metric-icon bg-primary/10 text-primary"><ShoppingBasket size={17} /></span><p className="mt-4 text-xs text-muted-foreground">Mặt hàng cần mua</p><p className="mt-1 font-mono text-2xl font-bold text-primary">{items.length}</p></div><div className="workspace-metric border-secondary"><span className="workspace-metric-icon bg-secondary text-secondary-foreground"><PackageCheck size={17} /></span><p className="mt-4 text-xs text-muted-foreground">Chi phí dự kiến</p><p className="mt-1 font-mono text-2xl font-bold">{money(total)}</p></div><div className="workspace-metric border-accent/25"><span className="workspace-metric-icon bg-accent/10 text-accent"><ClipboardCheck size={17} /></span><p className="mt-4 text-xs text-muted-foreground">Ưu tiên gấp</p><p className="mt-1 font-mono text-2xl font-bold text-accent">{items.filter((item) => item.urgent).length}</p></div></section>
    <section className="workspace-card overflow-hidden"><div className="flex items-center justify-between border-b border-border/70 p-4 md:p-5"><div><p className="workspace-eyebrow text-muted-foreground">Shopping list · Supplier dispatch</p><h3 className="mt-1 font-serif text-2xl">Danh sách nhập hàng</h3></div><span className="rounded-full bg-primary/10 px-3 py-1 text-[10px] font-bold text-primary">{items.length ? 'AI đã sắp xếp ưu tiên' : 'Kho đang đủ dùng'}</span></div>{items.length === 0 ? <div className="p-12 text-center"><PackageCheck className="mx-auto text-primary" size={30} /><p className="mt-3 font-serif text-xl">Chưa cần nhập thêm</p><p className="mt-1 text-sm text-muted-foreground">Tồn kho hiện tại đáp ứng được kế hoạch bán hàng.</p></div> : <div className="divide-y divide-border/70">{supplierGroups.map(({ supplier, items: supplierItems }) => <div key={supplier} data-testid={`supplier-group-${supplier}`} className="p-4 md:p-5"><div className="flex flex-col justify-between gap-3 rounded-2xl bg-muted/55 p-4 sm:flex-row sm:items-center"><div className="flex items-center gap-3"><span className="grid h-10 w-10 place-items-center rounded-xl bg-primary/10 text-primary"><Truck size={17} /></span><div><p className="text-sm font-bold">{supplier}</p><p className="mt-1 text-[11px] text-muted-foreground">{supplierContactByName[supplier] ?? 'Sẵn sàng nhận đơn'} · {supplierItems.length} mặt hàng</p></div></div><button data-testid={`button-dispatch-${supplier}`} onClick={() => void dispatchOrder(supplier, supplierItems)} className="flex items-center justify-center gap-2 rounded-xl bg-primary px-3 py-2.5 text-xs font-bold text-primary-foreground"><Send size={14} />Gửi đơn qua Zalo / SMS</button></div><div className="mt-3 divide-y divide-border/60">{supplierItems.map((item) => <div key={item.id} data-testid={`shopping-item-${item.id}`} className="flex flex-col gap-3 py-4 md:flex-row md:items-center md:justify-between"><div className="flex min-w-0 items-center gap-3"><span className={`grid h-11 w-11 shrink-0 place-items-center rounded-2xl ${item.urgent ? 'bg-accent/10 text-accent' : 'bg-primary/10 text-primary'}`}><ShoppingBasket size={18} /></span><div className="min-w-0"><div className="flex flex-wrap items-center gap-2"><p className="font-bold">{item.name}</p>{item.urgent && <span className="rounded-full bg-accent/10 px-2 py-1 text-[10px] font-bold text-accent">Ưu tiên gấp</span>}</div><p className="mt-1 text-xs text-muted-foreground">Cần nhập <span className="font-mono font-bold text-foreground">{item.to_buy} {item.unit}</span> · hạn dùng {item.shelf_life_days} ngày</p></div></div><div className="flex items-center justify-between gap-4 md:justify-end"><span className="font-mono text-sm font-bold">{money(item.to_buy * item.price)}</span><button data-testid={`button-confirm-shopping-${item.id}`} onClick={() => onConfirm({ id: item.id, name: item.name, unit: item.unit, quantity: item.to_buy, price: item.price, confirmed: false })} className="rounded-xl bg-secondary px-3 py-2 text-xs font-bold text-secondary-foreground hover:bg-primary/15 hover:text-primary">Đã nhập kho</button></div></div>)}</div></div>)}</div>}</section>
    <p className="flex items-center gap-2 text-[11px] leading-5 text-muted-foreground"><ExternalLink size={13} />Nút gửi sẽ sao chép đơn hàng và mở bảng chia sẻ thiết bị; nếu không có, Resto.AI mở SMS để bạn gửi ngay. Zalo khả dụng qua bảng chia sẻ khi đã cài trên máy.</p>
  </div>;
}

function AuthLoadingScreen() {
  return <main className="auth-shell grid min-h-[100dvh] place-items-center p-6"><div className="auth-panel flex items-center gap-3"><BrandMark size={44} /><div><p className="font-serif text-xl text-white"><strong>Resto</strong><span className="brand-ai">.AI</span></p><p className="text-xs text-slate-300">Đang kiểm tra phiên làm việc...</p></div></div></main>;
}

function AdminSettingsModal({ profile, user, onClose, onSave }: { profile: Profile; user: AuthUser; onClose: () => void; onSave: (profile: Profile) => void }) {
  const [form, setForm] = useState(profile);
  return <ModalFrame title="Cài đặt quản trị" subtitle="Thiết lập cửa hàng và kiểm tra trạng thái phiên làm việc." onClose={onClose}><div className="mt-5 space-y-4"><div className="grid gap-3 sm:grid-cols-2"><div className="rounded-2xl bg-secondary/60 p-4"><p className="text-[10px] font-bold uppercase tracking-wider text-muted-foreground">Tenant ID</p><p className="mt-2 font-mono text-lg font-bold">{user.tenantId}</p></div><div className="rounded-2xl bg-primary/5 p-4"><p className="text-[10px] font-bold uppercase tracking-wider text-muted-foreground">Quyền hiện tại</p><p className="mt-2 text-lg font-bold text-primary">{user.role === 'manager' ? 'Manager' : 'Staff'}</p></div></div><label className="block text-xs font-bold text-muted-foreground">Tên hiển thị<input data-testid="input-admin-profile-name" value={form.name} onChange={(event) => setForm({ ...form, name: event.target.value })} className="mt-2 h-11 w-full rounded-xl border border-input bg-background px-3 text-sm outline-none focus:border-primary" /></label><label className="block text-xs font-bold text-muted-foreground">Tên cửa hàng<input data-testid="input-admin-restaurant" value={form.restaurant} onChange={(event) => setForm({ ...form, restaurant: event.target.value })} className="mt-2 h-11 w-full rounded-xl border border-input bg-background px-3 text-sm outline-none focus:border-primary" /></label><div className="rounded-2xl border border-border/70 bg-muted/50 p-4"><div className="flex items-center gap-2 text-sm font-bold"><CheckCircle2 size={16} className="text-primary" />Session security</div><p className="mt-2 text-xs leading-5 text-muted-foreground">Phiên được lưu bằng cookie HttpOnly. Token không nằm trong localStorage; RBAC được đọc từ API server.</p></div></div><button data-testid="button-save-admin-settings" onClick={() => onSave(form)} className="mt-6 flex h-11 w-full items-center justify-center gap-2 rounded-xl bg-primary font-bold text-primary-foreground"><Save size={16} />Lưu cài đặt</button></ModalFrame>;
}

function EnterpriseLoginScreen({ remembered, error, onSubmit }: { remembered: { tenantId?: string; username?: string }; error: string; onSubmit: (payload: { tenantId: string; username: string; password: string; rememberMe: boolean }) => Promise<void> }) {
  const [tenantId, setTenantId] = useState(remembered.tenantId ?? 'RESTO-01');
  const [username, setUsername] = useState(remembered.username ?? '');
  const [password, setPassword] = useState('');
  const [rememberMe, setRememberMe] = useState(Boolean(remembered.username));
  const [submitting, setSubmitting] = useState(false);
  const submit = async (event: React.FormEvent) => {
    event.preventDefault();
    setSubmitting(true);
    try {
      await onSubmit({ tenantId, username, password, rememberMe });
    } finally {
      setSubmitting(false);
    }
  };
  return <main className="auth-shell flex min-h-[100dvh] items-center justify-center overflow-hidden p-4 md:p-8"><div className="auth-orb auth-orb-one" /><div className="auth-orb auth-orb-two" /><section className="auth-panel relative w-full max-w-md rounded-[2rem] p-6 shadow-2xl md:p-8"><div className="text-center"><div className="auth-logo-glow mx-auto grid h-24 w-24 place-items-center rounded-[2rem]"><BrandMark size={76} testId="logo-enterprise-login" /></div><p className="mt-6 font-mono text-[10px] font-bold uppercase tracking-[.28em] text-emerald-300">Enterprise workspace</p><h1 className="mt-3 font-serif text-3xl text-white md:text-4xl">Đăng nhập Resto.AI</h1><p className="mt-3 text-sm leading-6 text-slate-300">Quản lý ca bán hàng, lợi nhuận và AI theo đúng cửa hàng của bạn.</p></div><form onSubmit={(e) => {
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                     e.preventDefault();
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                     localStorage.setItem('user', JSON.stringify({ name: 'Minh Anh', role: 'owner', restaurant: 'Resto.AI' }));
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                     window.location.reload();
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                   }} className="mt-8 space-y-4"><label className="block text-xs font-bold text-slate-200">Mã cửa hàng<span className="auth-label-note">Tenant ID</span><input data-testid="input-tenant-id" value={tenantId} onChange={(event) => setTenantId(event.target.value.toUpperCase())} autoComplete="organization" className="auth-input mt-2" /></label><label className="block text-xs font-bold text-slate-200">Tên đăng nhập<input data-testid="input-username" value={username} onChange={(event) => setUsername(event.target.value)} autoComplete="username" placeholder="Nhập username" className="auth-input mt-2" /></label><label className="block text-xs font-bold text-slate-200">Mật khẩu<input data-testid="input-password" type="password" value={password} onChange={(event) => setPassword(event.target.value)} autoComplete="current-password" placeholder="Nhập mật khẩu" className="auth-input mt-2" /></label><label className="flex cursor-pointer items-center gap-2.5 py-1 text-xs text-slate-300"><input data-testid="input-remember-me" type="checkbox" checked={rememberMe} onChange={(event) => setRememberMe(event.target.checked)} className="h-4 w-4 accent-emerald-400" />Ghi nhớ đăng nhập</label>{error && <p data-testid="auth-error" role="alert" className="rounded-xl border border-red-400/25 bg-red-400/10 px-3 py-2.5 text-xs font-semibold text-red-200">{error}</p>}<button 
    type="button" 
    onClick={() => {
      localStorage.setItem('isAuthenticated', 'true');
      localStorage.setItem('user', JSON.stringify({ name: 'Admin', role: 'owner' }));
      window.location.reload();
    }} 
    className="w-full h-12 bg-gradient-to-r from-orange-500 to-cyan-500 text-white font-bold rounded-xl shadow-lg cursor-pointer"
  >
    VÀO THẲNG DASHBOARD 🚀
  </button></form><div className="mt-6 flex items-center justify-center gap-2 text-[10px] text-slate-400"><Lock size={12} />Phiên làm việc được bảo vệ bằng HttpOnly cookie</div></section></main>;
}

function ModalFrame({ title, subtitle, onClose, children }: { title: string; subtitle: string; onClose: () => void; children: ReactNode }) {
  return <div className="fixed inset-0 z-50 flex items-end justify-center bg-foreground/35 p-0 backdrop-blur-[2px] sm:items-center sm:p-5"><div className="fade-up max-h-[92dvh] w-full overflow-y-auto rounded-t-3xl border border-card-border bg-card p-6 shadow-2xl sm:max-w-lg sm:rounded-3xl md:p-7"><div className="mb-6 flex items-start justify-between"><div><h2 className="font-serif text-2xl">{title}</h2><p className="mt-1 text-xs leading-5 text-muted-foreground">{subtitle}</p></div><button data-testid="button-close-modal" aria-label="Đóng" onClick={onClose} className="rounded-lg p-2 text-muted-foreground hover:bg-muted"><X size={18} /></button></div>{children}</div></div>;
}

function RolePinModal({ pin, error, target, onPinChange, onClose, onSubmit }: { pin: string; error: string; target: View; onPinChange: (value: string) => void; onClose: () => void; onSubmit: () => void }) {
  const targetLabel = target === 'ledger' ? 'Sổ quỹ & Kho' : target === 'shopping' ? 'Đi chợ AI' : target === 'reports' ? 'Báo cáo tài chính' : 'Trợ lý AI Command Center';
  return <ModalFrame title="Xác nhận quyền quản lý" subtitle={`Nhập PIN 4 số để truy cập ${targetLabel}.`} onClose={onClose}><div className="mt-6 rounded-2xl bg-secondary/60 p-4"><div className="flex items-center gap-3"><span className="grid h-10 w-10 place-items-center rounded-xl bg-primary/10 text-primary"><Lock size={18} /></span><div><p className="text-sm font-bold">Manager PIN required</p><p className="mt-1 text-xs text-muted-foreground">Quyền được xác thực tại API server, không lưu trong trình duyệt.</p></div></div></div><label className="mt-5 block text-xs font-bold text-muted-foreground">Mã PIN quản lý<input data-testid="input-manager-pin" autoFocus inputMode="numeric" type="password" maxLength={4} value={pin} onChange={(event) => onPinChange(event.target.value.replace(/\D/g, ''))} onKeyDown={(event) => { if (event.key === 'Enter') onSubmit(); }} placeholder="••••" className="mt-2 h-12 w-full rounded-xl border border-input bg-background px-3 text-center font-mono text-xl tracking-[.45em] outline-none focus:border-primary" /></label>{error && <p data-testid="manager-pin-error" className="mt-3 text-xs font-semibold text-destructive">{error}</p>}<button data-testid="button-unlock-manager" onClick={onSubmit} className="mt-6 flex h-12 w-full items-center justify-center gap-2 rounded-xl bg-primary font-bold text-primary-foreground"><Unlock size={17} />Xác nhận bằng PIN</button></ModalFrame>;
}

function QuickPinModal({ currentRole, pin, error, onPinChange, onClose, onSubmit }: { currentRole: Role; pin: string; error: string; onPinChange: (value: string) => void; onClose: () => void; onSubmit: () => void }) {
  return <ModalFrame title="Đổi ca / Chuyển nhân viên" subtitle="Nhập mã PIN 4 số để chuyển quyền ngay trên thiết bị POS." onClose={onClose}><div className="mt-5 rounded-2xl border border-primary/15 bg-primary/5 p-4"><p className="text-sm font-bold">{currentRole === 'manager' ? 'Đang ở Manager Mode' : 'Đang ở Staff Mode'}</p><p className="mt-1 text-xs leading-5 text-muted-foreground">{currentRole === 'manager' ? 'Nhập PIN nhân viên để bàn giao ca.' : 'Nhập PIN quản lý để mở báo cáo, đi chợ AI và Command Center.'}</p></div><label className="mt-5 block text-xs font-bold text-muted-foreground">PIN chuyển ca<input data-testid="input-quick-pin" autoFocus inputMode="numeric" type="password" maxLength={4} value={pin} onChange={(event) => onPinChange(event.target.value.replace(/\D/g, ''))} onKeyDown={(event) => { if (event.key === 'Enter') onSubmit(); }} placeholder="••••" className="mt-2 h-12 w-full rounded-xl border border-input bg-background px-3 text-center font-mono text-xl tracking-[.45em] outline-none focus:border-primary" /></label>{error && <p data-testid="quick-pin-error" className="mt-3 text-xs font-semibold text-destructive">{error}</p>}<button data-testid="button-quick-pin-submit" onClick={onSubmit} className="mt-6 flex h-12 w-full items-center justify-center gap-2 rounded-xl bg-primary font-bold text-primary-foreground"><ArrowLeftRight size={17} />Chuyển ca</button><button onClick={onClose} className="mt-2 h-10 w-full rounded-xl text-xs font-bold text-muted-foreground hover:bg-muted">Hủy</button></ModalFrame>;
}

function FixedCostModal({ onClose, onSave }: { onClose: () => void; onSave: (data: Omit<FixedCost, 'id'>) => void }) {
  const [name, setName] = useState('');
  const [amount, setAmount] = useState('');
  const [frequency, setFrequency] = useState<FixedCost['frequency']>('tháng');
  const [error, setError] = useState('');
  const submit = () => {
    const value = Number(amount);
    if (!name.trim() || !Number.isFinite(value) || value <= 0) {
      setError('Vui lòng nhập tên và số tiền hợp lệ.');
      return;
    }
    onSave({ name: name.trim(), amount: value, frequency });
  };
  return <ModalFrame title="Thêm chi phí cố định" subtitle="Chi phí cố định được trừ khỏi Gross Profit để tính Net Profit." onClose={onClose}><div className="mt-5 space-y-4"><label className="block text-xs font-bold text-muted-foreground">Tên chi phí<input data-testid="input-fixed-cost-name" autoFocus value={name} onChange={(event) => setName(event.target.value)} placeholder="Ví dụ: Mặt bằng" className="mt-2 h-11 w-full rounded-xl border border-input bg-background px-3 text-sm outline-none focus:border-primary" /></label><div className="grid gap-4 sm:grid-cols-2"><label className="block text-xs font-bold text-muted-foreground">Số tiền<input data-testid="input-fixed-cost-amount" type="number" value={amount} onChange={(event) => setAmount(event.target.value)} placeholder="0" className="mt-2 h-11 w-full rounded-xl border border-input bg-background px-3 font-mono text-sm outline-none focus:border-primary" /></label><label className="block text-xs font-bold text-muted-foreground">Chu kỳ<select data-testid="select-fixed-cost-frequency" value={frequency} onChange={(event) => setFrequency(event.target.value as FixedCost['frequency'])} className="mt-2 h-11 w-full rounded-xl border border-input bg-background px-3 text-sm outline-none focus:border-primary"><option value="tháng">Mỗi tháng</option><option value="tuần">Mỗi tuần</option></select></label></div></div>{error && <p className="mt-4 text-xs font-semibold text-destructive">{error}</p>}<button data-testid="button-save-fixed-cost" onClick={submit} className="mt-7 flex h-12 w-full items-center justify-center gap-2 rounded-xl bg-primary font-bold text-primary-foreground"><Save size={16} />Lưu chi phí</button></ModalFrame>;
}

function TransactionModal({ initial, onClose, onSave }: { initial: Transaction | null; onClose: () => void; onSave: (data: Omit<Transaction, 'id'>) => void }) {
  const [type, setType] = useState<TransactionType>(initial?.type ?? 'thu');
  const [category, setCategory] = useState(initial?.category ?? 'Bán hàng');
  const [note, setNote] = useState(initial?.note ?? '');
  const [amount, setAmount] = useState(initial?.amount ? String(initial.amount) : '');
  const [date, setDate] = useState(initial?.date ?? today);
  const [error, setError] = useState('');
  const submit = () => {
    if (!note.trim() || !amount || Number(amount) <= 0) { setError('Hãy nhập nội dung và số tiền hợp lệ.'); return; }
    onSave({ type, category, note: note.trim(), amount: Number(amount), date });
  };
  return <ModalFrame title={initial ? 'Sửa giao dịch' : 'Thêm giao dịch'} subtitle="Ghi lại để bức tranh tài chính luôn rõ ràng." onClose={onClose}><div className="mb-5 grid grid-cols-2 gap-2 rounded-xl bg-muted p-1"><button data-testid="button-type-thu" onClick={() => setType('thu')} className={`rounded-lg py-2.5 text-sm font-bold ${type === 'thu' ? 'bg-card text-primary shadow-sm' : 'text-muted-foreground'}`}>Khoản thu</button><button data-testid="button-type-chi" onClick={() => setType('chi')} className={`rounded-lg py-2.5 text-sm font-bold ${type === 'chi' ? 'bg-card text-accent shadow-sm' : 'text-muted-foreground'}`}>Khoản chi</button></div><div className="space-y-4"><label className="block text-xs font-bold text-muted-foreground">Số tiền (VNĐ)<input data-testid="input-transaction-amount" autoFocus type="number" value={amount} onChange={(event) => setAmount(event.target.value)} placeholder="0" className="mt-2 h-12 w-full rounded-xl border border-input bg-background px-3 font-mono text-lg outline-none focus:border-primary" /></label><label className="block text-xs font-bold text-muted-foreground">Nội dung<input data-testid="input-transaction-note" value={note} onChange={(event) => setNote(event.target.value)} placeholder="Ví dụ: Doanh thu ca trưa" className="mt-2 h-11 w-full rounded-xl border border-input bg-background px-3 text-sm outline-none focus:border-primary" /></label><div className="grid gap-4 sm:grid-cols-2"><label className="block text-xs font-bold text-muted-foreground">Danh mục<select data-testid="select-transaction-category" value={category} onChange={(event) => setCategory(event.target.value)} className="mt-2 h-11 w-full rounded-xl border border-input bg-background px-3 text-sm outline-none focus:border-primary"><option>Bán hàng</option><option>Nguyên liệu</option><option>Nhân sự</option><option>Vận hành</option><option>Khác</option></select></label><label className="block text-xs font-bold text-muted-foreground">Ngày<input data-testid="input-transaction-date" type="date" value={date} onChange={(event) => setDate(event.target.value)} className="mt-2 h-11 w-full rounded-xl border border-input bg-background px-3 text-sm outline-none focus:border-primary" /></label></div></div>{error && <p className="mt-4 text-xs font-semibold text-destructive">{error}</p>}<div className="mt-7 flex gap-3"><button data-testid="button-cancel-transaction" onClick={onClose} className="flex-1 rounded-xl border border-border py-3 text-sm font-bold text-muted-foreground hover:bg-muted">Hủy</button><button data-testid="button-save-transaction" onClick={submit} className="flex-1 rounded-xl bg-primary py-3 text-sm font-bold text-primary-foreground">{initial ? 'Lưu thay đổi' : 'Lưu giao dịch'}</button></div></ModalFrame>;
}

function IngredientModal({ onClose, onSave }: { onClose: () => void; onSave: (data: Omit<Ingredient, 'id' | 'updated'>) => void }) {
  const [name, setName] = useState('');
  const [unit, setUnit] = useState('kg');
  const [current, setCurrent] = useState('');
  const [minimum, setMinimum] = useState('');
  const [price, setPrice] = useState('');
  const [error, setError] = useState('');
  const submit = () => { if (!name.trim() || Number(current) < 0 || Number(minimum) < 0 || Number(price) <= 0) { setError('Hãy điền đủ thông tin với giá nhập hợp lệ.'); return; } onSave({ name: name.trim(), unit, current: Number(current), minimum: Number(minimum), price: Number(price) }); };
  return <ModalFrame title="Thêm nguyên liệu" subtitle="Thiết lập mức tối thiểu để Resto.AI nhắc bạn đúng lúc." onClose={onClose}><div className="space-y-4"><label className="block text-xs font-bold text-muted-foreground">Tên nguyên liệu<input data-testid="input-ingredient-name" autoFocus value={name} onChange={(event) => setName(event.target.value)} placeholder="Ví dụ: Tỏi tươi" className="mt-2 h-11 w-full rounded-xl border border-input bg-background px-3 text-sm outline-none focus:border-primary" /></label><div className="grid gap-4 sm:grid-cols-2"><label className="block text-xs font-bold text-muted-foreground">Đơn vị<select data-testid="select-ingredient-unit" value={unit} onChange={(event) => setUnit(event.target.value)} className="mt-2 h-11 w-full rounded-xl border border-input bg-background px-3 text-sm outline-none focus:border-primary"><option>kg</option><option>gói</option><option>chai</option><option>bó</option><option>thùng</option><option>cái</option></select></label><label className="block text-xs font-bold text-muted-foreground">Giá nhập / đơn vị<input data-testid="input-ingredient-price" type="number" value={price} onChange={(event) => setPrice(event.target.value)} placeholder="0" className="mt-2 h-11 w-full rounded-xl border border-input bg-background px-3 font-mono text-sm outline-none focus:border-primary" /></label></div><div className="grid gap-4 sm:grid-cols-2"><label className="block text-xs font-bold text-muted-foreground">Tồn hiện tại<input data-testid="input-ingredient-current" type="number" step="0.1" value={current} onChange={(event) => setCurrent(event.target.value)} placeholder="0" className="mt-2 h-11 w-full rounded-xl border border-input bg-background px-3 font-mono text-sm outline-none focus:border-primary" /></label><label className="block text-xs font-bold text-muted-foreground">Mức tối thiểu<input data-testid="input-ingredient-minimum" type="number" step="0.1" value={minimum} onChange={(event) => setMinimum(event.target.value)} placeholder="0" className="mt-2 h-11 w-full rounded-xl border border-input bg-background px-3 font-mono text-sm outline-none focus:border-primary" /></label></div></div>{error && <p className="mt-4 text-xs font-semibold text-destructive">{error}</p>}<div className="mt-7 flex gap-3"><button data-testid="button-cancel-ingredient" onClick={onClose} className="flex-1 rounded-xl border border-border py-3 text-sm font-bold text-muted-foreground hover:bg-muted">Hủy</button><button data-testid="button-save-ingredient" onClick={submit} className="flex-1 rounded-xl bg-primary py-3 text-sm font-bold text-primary-foreground">Thêm vào kho</button></div></ModalFrame>;
}

function AdjustModal({ ingredient, onClose, onSave }: { ingredient: Ingredient; onClose: () => void; onSave: (amount: number) => void }) {
  const [amount, setAmount] = useState(String(ingredient.current));
  return <ModalFrame title="Điều chỉnh tồn kho" subtitle={`${ingredient.name} · Mức tối thiểu ${ingredient.minimum} ${ingredient.unit}`} onClose={onClose}><div className="rounded-xl bg-secondary/60 p-4"><p className="text-xs text-muted-foreground">Tồn đang ghi nhận</p><p className="mt-1 font-mono text-2xl text-secondary-foreground">{ingredient.current} {ingredient.unit}</p></div><label className="mt-5 block text-xs font-bold text-muted-foreground">Số lượng thực tế<input data-testid="input-adjust-amount" autoFocus type="number" step="0.1" value={amount} onChange={(event) => setAmount(event.target.value)} className="mt-2 h-12 w-full rounded-xl border border-input bg-background px-3 font-mono text-lg outline-none focus:border-primary" /></label><div className="mt-7 flex gap-3"><button data-testid="button-cancel-adjust" onClick={onClose} className="flex-1 rounded-xl border border-border py-3 text-sm font-bold text-muted-foreground hover:bg-muted">Hủy</button><button data-testid="button-save-adjust" onClick={() => onSave(Math.max(0, Number(amount) || 0))} className="flex-1 rounded-xl bg-primary px-4 py-3 text-sm font-bold text-primary-foreground">Cập nhật kho</button></div></ModalFrame>;
}

function EmptyState({ title, text }: { title: string; text: string }) {
  return <div className="flex flex-col items-center justify-center px-5 py-12 text-center"><span className="mb-3 grid h-11 w-11 place-items-center rounded-xl bg-muted text-muted-foreground"><Boxes size={19} /></span><p className="text-sm font-bold">{title}</p><p className="mt-1 max-w-xs text-xs leading-5 text-muted-foreground">{text}</p></div>;
}

function laborHourForTransaction(item: Transaction) {
  if (typeof item.hour === 'number') return item.hour;
  const note = item.note.toLowerCase();
  if (note.includes('tối')) return 19;
  if (note.includes('trưa')) return 12;
  if (note.includes('sáng')) return 9;
  return 14;
}

function LaborEfficiencyCard({ transactions }: { transactions: Transaction[] }) {
  const labor = useMemo(() => {
    const hourly = new Array<number>(24).fill(0);
    transactions.filter((item) => item.type === 'thu').forEach((item) => {
      hourly[Math.min(23, Math.max(0, laborHourForTransaction(item)))] += item.amount;
    });
    const quietHours = [13, 14, 15];
    const peakHours = [11, 12, 18, 19, 20];
    const quietRevenue = quietHours.reduce((sum, hour) => sum + hourly[hour], 0);
    const peakRevenue = peakHours.reduce((sum, hour) => sum + hourly[hour], 0);
    const quietAverage = Math.round(quietRevenue / quietHours.length);
    const peakAverage = Math.round(peakRevenue / peakHours.length);
    return { hourly, quietAverage, peakAverage, savingPotential: Math.max(0, Math.round((peakAverage - quietAverage) / 8000)) };
  }, [transactions]);
  const isDeadHour = labor.quietAverage < labor.peakAverage * .65;
  return <section data-testid="card-labor-efficiency" className={`workspace-card overflow-hidden p-4 md:p-5 ${isDeadHour ? 'border-accent/30' : 'border-primary/20'}`}>
    <div className="flex flex-col justify-between gap-4 md:flex-row md:items-start"><div className="flex items-start gap-3"><span className={`grid h-11 w-11 shrink-0 place-items-center rounded-2xl ${isDeadHour ? 'bg-accent/10 text-accent' : 'bg-primary/10 text-primary'}`}><Clock3 size={20} /></span><div><p className="workspace-eyebrow text-accent">Labor & Cost Optimizer</p><h3 className="mt-1 font-serif text-2xl">Tối ưu chi phí nhân công</h3><p className="mt-1 max-w-2xl text-xs leading-5 text-muted-foreground">Resto.AI quét doanh thu theo giờ để tìm khung giờ cần giảm tải ca trực mà không ảnh hưởng giờ cao điểm.</p></div></div><span className={`rounded-full px-3 py-1.5 text-[10px] font-bold ${isDeadHour ? 'bg-accent/10 text-accent' : 'bg-primary/10 text-primary'}`}>{isDeadHour ? 'Có khung giờ cần xem' : 'Đang trong tầm kiểm soát'}</span></div>
    <div className="mt-5 grid gap-3 md:grid-cols-[1fr_auto]"><div className="rounded-2xl bg-muted/55 p-4"><div className="flex items-center justify-between gap-3"><p className="text-sm font-bold">Khung giờ 13:00–15:00</p><span className="font-mono text-xs text-muted-foreground">{money(labor.quietAverage)}/giờ</span></div><div className="mt-4 flex h-16 items-end gap-1.5">{labor.hourly.slice(11, 21).map((value, index) => <span key={index} className={`flex-1 rounded-t-md ${index >= 2 && index <= 4 ? 'bg-accent' : 'bg-primary/30'}`} style={{ height: `${Math.max(8, (value / Math.max(...labor.hourly, 1)) * 58)}px` }} title={`${index + 11}:00 · ${money(value)}`} />)}</div><div className="mt-2 flex justify-between text-[10px] text-muted-foreground"><span>11:00</span><span>15:00</span><span>20:00</span></div></div><div className="flex min-w-0 flex-col justify-between rounded-2xl border border-accent/20 bg-accent/[.06] p-4 md:w-80"><div><div className="flex items-center gap-2 text-accent"><Lightbulb size={16} /><p className="text-xs font-bold">Gợi ý hành động</p></div><p className="mt-3 text-sm leading-6 text-foreground">{isDeadHour ? 'Từ 13:00 đến 15:00 doanh thu đang thấp hơn rõ rệt so với giờ cao điểm. Nên cho 1 nhân viên nghỉ ca sớm hoặc chuyển sang chuẩn bị hàng.' : 'Chưa thấy khung giờ chết rõ ràng. Giữ lịch nhân sự hiện tại và tiếp tục theo dõi theo ca.'}</p></div><p className="mt-4 text-[10px] leading-4 text-muted-foreground">Mức so sánh giờ cao điểm: {money(labor.peakAverage)}/giờ · dữ liệu từ sổ bán hàng</p></div></div>
  </section>;
}

function ForecastWorkspace({ forecast, history, runs, ingredients, transactions, mlForecast, mlForecastLoading, mlForecastError, onMlForecast, onRefresh, onAdjust, onConfirm, onAction }: { forecast: ForecastRun; history: SalesDay[]; runs: ForecastRun[]; ingredients: Ingredient[]; transactions: Transaction[]; mlForecast: MlForecast | null; mlForecastLoading: boolean; mlForecastError: string; onMlForecast: (request: PredictRequest) => Promise<void>; onRefresh: () => void; onAdjust: (id: string, quantity: number) => void; onConfirm: (item: ForecastRecommendation) => void; onAction: (kind: InsightSignal['actionKind']) => void }) {
  const insight = useMemo(() => buildInsight({ forecast, ingredients, transactions }), [forecast, ingredients, transactions]);
  const totalServings = forecast.dishes.reduce((sum, item) => sum + item.servings, 0);
  const revenueTransactions = transactions.filter((item) => item.type === 'thu');
  const expenseTransactions = transactions.filter((item) => item.type === 'chi');
  const recordedRevenue = revenueTransactions.reduce((sum, item) => sum + item.amount, 0);
  const recordedExpenses = expenseTransactions.reduce((sum, item) => sum + item.amount, 0);
  const averageTicket = revenueTransactions.length ? recordedRevenue / revenueTransactions.length : 62000;
  const expectedRevenue = totalServings * averageTicket;
  const topDish = [...forecast.dishes].sort((a, b) => b.servings - a.servings)[0];
  const shopping = mlForecast?.shopping_list.filter((item) => item.to_buy > 0) ?? ingredients
    .filter((item) => item.current < item.minimum)
    .map((item) => ({ name: item.name, unit: item.unit, to_buy: Number((item.minimum - item.current).toFixed(1)) }));
  const localAlerts = ingredients.filter((item) => item.current < item.minimum || (item.shelfLifeDays ?? 7) <= 2);
  const operationalAlerts = mlForecast?.operational_alerts ?? [];
  const alertCount = operationalAlerts.length || localAlerts.length;
  const [chatInput, setChatInput] = useState('');
  const [chatMessages, setChatMessages] = useState<{ from: 'ai' | 'user'; text: string }[]>([
    { from: 'ai', text: 'Tôi đang theo dõi thời tiết, tồn kho và tốc độ bán. Bạn muốn biết điều gì?' },
  ]);
  const [typingTarget, setTypingTarget] = useState<string | null>(null);
  const [typingText, setTypingText] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const reducedMotion = useMemo(() => typeof window !== 'undefined' && window.matchMedia('(prefers-reduced-motion: reduce)').matches, []);

  useEffect(() => {
    if (!typingTarget) {
      setTypingText('');
      return;
    }
    if (reducedMotion) {
      setTypingText(typingTarget);
      setChatMessages((current) => [...current, { from: 'ai', text: typingTarget }]);
      setTypingTarget(null);
      setIsTyping(false);
      return;
    }
    let cursor = 0;
    setTypingText('');
    setIsTyping(true);
    const timer = window.setInterval(() => {
      cursor += 2;
      setTypingText(typingTarget.slice(0, cursor));
      if (cursor >= typingTarget.length) {
        window.clearInterval(timer);
        setChatMessages((current) => [...current, { from: 'ai', text: typingTarget }]);
        setTypingTarget(null);
        setIsTyping(false);
      }
    }, 18);
    return () => window.clearInterval(timer);
  }, [reducedMotion, typingTarget]);

  const answerForPrompt = (prompt: string) => {
    const lower = prompt.toLowerCase();
    if (lower.includes('lãi') || lower.includes('lợi nhuận')) {
      return `Lợi nhuận ròng ghi nhận trong dữ liệu hiện tại là ${money(recordedRevenue - recordedExpenses)}. Đây là số đã ghi sổ, chưa phải dự báo.`;
    }
    if (lower.includes('mua') || lower.includes('sáng mai')) {
      return shopping.length
        ? `Danh sách ưu tiên có ${shopping.length} mục. Nên xử lý trước ${shopping.slice(0, 2).map((item) => item.name).join(' và ')}.`
        : 'Tồn kho đang đủ theo ngưỡng hiện tại, chưa có mục cần nhập thêm.';
    }
    if (lower.includes('bán') || lower.includes('món')) {
      return topDish
        ? `${topDish.name} đang dẫn đầu với ${topDish.servings} suất dự báo, so với ${topDish.previous} suất ở ngày tương tự.`
        : 'Chưa có đủ dữ liệu món để đưa ra so sánh.';
    }
    if (lower.includes('cảnh báo') || lower.includes('rủi ro')) {
      return alertCount ? `Hiện có ${alertCount} tín hiệu cần xem. ${insight.actionLabel}.` : 'Chưa có cảnh báo chủ động từ dữ liệu hiện tại.';
    }
    return insight.body;
  };

  const askCompanion = (suggestedQuestion?: string) => {
    if (isTyping) return;
    const prompt = (suggestedQuestion ?? chatInput).trim();
    if (!prompt) return;
    setChatMessages((current) => [...current, { from: 'user', text: prompt }]);
    setTypingTarget(answerForPrompt(prompt));
    setChatInput('');
  };

  return <div data-testid="workspace-forecast" className="workspace-page command-workspace space-y-5 md:space-y-6">
    <section className="command-center-shell overflow-hidden rounded-[1.75rem] border border-primary/20 p-5 shadow-[var(--shadow-card)] md:p-7">
      <div className="relative z-[1] flex flex-col justify-between gap-6 lg:flex-row lg:items-end">
        <div>
          <div className="flex flex-wrap items-center gap-2"><span className="command-live-dot" /><p className="workspace-eyebrow text-primary">AI Command Center · {dateLabel(forecast.targetDate)}</p></div>
          <h2 className="mt-3 max-w-3xl font-serif text-3xl leading-tight text-foreground md:text-5xl">Quyết định ca ngày mai, ngay từ hôm nay.</h2>
          <p className="mt-4 max-w-2xl text-sm leading-6 text-muted-foreground">Một bảng điều hành cho chủ quán: tín hiệu nổi bật ở trước mắt, hành động quan trọng ở ngay cạnh dữ liệu.</p>
        </div>
        <button data-testid="button-command-refresh" onClick={onRefresh} className="command-primary-action flex w-fit items-center gap-2 rounded-xl bg-primary px-4 py-3 text-sm font-bold text-primary-foreground shadow-lg shadow-primary/15"><RefreshCw size={16} />Cập nhật dữ liệu</button>
      </div>
      <div className="command-status-row mt-6 flex flex-wrap items-center gap-2 text-[11px] text-muted-foreground"><span className="command-status-pill"><CloudSun size={14} />{insight.weatherLabel}</span><span className="command-status-pill"><TrendingUp size={14} />{totalServings ? `${totalServings} suất dự báo` : 'Chưa có suất dự báo'}</span><span className="command-status-pill"><CheckCircle2 size={14} />Dữ liệu tại thiết bị</span></div>
    </section>

    <section className="grid gap-4 xl:grid-cols-3">
      <article data-testid="forecast-kpi-revenue" className="forecast-kpi command-kpi-primary border-primary/20 bg-primary text-primary-foreground"><div className="flex items-start justify-between"><span className="grid h-10 w-10 place-items-center rounded-xl bg-primary-foreground/12"><TrendingUp size={19} /></span><span className="rounded-full bg-primary-foreground/12 px-2.5 py-1 text-[10px] font-bold">Ngày mai</span></div><p className="mt-8 text-sm text-primary-foreground/70">Doanh thu dự kiến</p><p className="mt-1 font-mono text-3xl font-bold">{money(expectedRevenue)}</p><p className="mt-2 text-xs text-primary-foreground/70">Từ {totalServings} suất · độ tin cậy {forecast.confidence}%</p></article>
      <article data-testid="forecast-kpi-shopping" className="forecast-kpi border-accent/25 bg-card"><div className="flex items-start justify-between"><span className="grid h-10 w-10 place-items-center rounded-xl bg-accent/10 text-accent"><ShoppingBasket size={19} /></span><span className="rounded-full bg-accent/10 px-2.5 py-1 text-[10px] font-bold text-accent">{shopping.length} mục</span></div><p className="mt-8 text-sm text-muted-foreground">Việc nhập hàng</p><p className="mt-1 font-serif text-2xl">{shopping.length ? 'Mua đủ, không mua dư' : 'Kho đang đủ dùng'}</p><p className="mt-2 truncate text-xs text-muted-foreground">{shopping.length ? shopping.slice(0, 2).map((item) => item.name).join(' · ') : 'Chưa có nguyên liệu dưới ngưỡng.'}</p></article>
      <article data-testid="forecast-kpi-trend" className="forecast-kpi border-secondary bg-card"><div className="flex items-start justify-between"><span className="grid h-10 w-10 place-items-center rounded-xl bg-secondary text-secondary-foreground"><ArrowUpRight size={19} /></span><span className="rounded-full bg-secondary px-2.5 py-1 text-[10px] font-bold text-secondary-foreground">Top trend</span></div><p className="mt-8 text-sm text-muted-foreground">Món cần chuẩn bị</p><p className="mt-1 font-serif text-2xl">{topDish?.name ?? 'Chưa có dữ liệu'}</p><p className="mt-2 font-mono text-xs text-muted-foreground">{topDish?.servings ?? 0} suất · burn rate {money(insight.burnRate)}/suất</p></article>
    </section>

    <LaborEfficiencyCard transactions={transactions} />

    <section data-testid="insight-hub" className="insight-hub copilot-panel overflow-hidden rounded-3xl border border-white/50 p-4 shadow-[var(--shadow-card)] md:p-6">
      <div className="grid gap-6 xl:grid-cols-[1.05fr_.95fr]">
        <div><div className="flex items-start justify-between gap-3"><div><p className="workspace-eyebrow text-primary">{insight.greeting}</p><h3 className="mt-2 max-w-xl font-serif text-3xl">{insight.title}</h3></div><span className={`grid h-11 w-11 shrink-0 place-items-center rounded-2xl ${insight.severity === 'urgent' ? 'bg-destructive/10 text-destructive' : 'bg-primary/10 text-primary'}`}><Sparkles size={21} /></span></div><p className="mt-5 max-w-2xl text-sm leading-7 text-muted-foreground">{insight.body}</p><div className="mt-5 flex flex-wrap gap-2"><button data-testid="button-insight-action" onClick={() => onAction(insight.actionKind)} className="command-chip command-chip-primary flex items-center gap-2 rounded-xl bg-primary px-4 py-3 text-xs font-bold text-primary-foreground"><Sparkles size={15} />{insight.actionLabel}</button><button data-testid="button-insight-restock" onClick={() => onAction('restock')} className="command-chip flex items-center gap-2 rounded-xl border border-border bg-card/70 px-4 py-3 text-xs font-bold text-foreground"><ShoppingBasket size={15} />Xem danh sách nhập</button></div><div className="mt-6 flex flex-wrap items-center gap-4 text-xs text-muted-foreground"><span className="flex items-center gap-1.5"><CloudSun size={14} />{insight.weatherLabel}</span><span className="flex items-center gap-1.5"><TrendingUp size={14} />Burn rate {money(insight.burnRate)}/suất</span></div></div>
        <div className="copilot-chat rounded-2xl border border-border/70 bg-card/75 p-4 backdrop-blur-md"><div className="flex items-center justify-between gap-3"><div className="flex items-center gap-2"><span className="grid h-8 w-8 place-items-center rounded-xl bg-primary/10 text-primary"><MessageCircle size={16} /></span><div><p className="text-sm font-bold">Co-pilot vận hành</p><p className="text-[10px] text-muted-foreground">Trả lời từ dữ liệu quán hiện tại</p></div></div><span className="rounded-full bg-primary/10 px-2 py-1 text-[9px] font-bold text-primary">Đang theo dõi</span></div><div className="mt-4 max-h-52 space-y-2 overflow-y-auto pr-1" aria-live="polite">{chatMessages.map((message, index) => <div key={`${message.from}-${index}`} className={`copilot-message max-w-[92%] rounded-2xl px-3 py-2.5 text-xs leading-5 ${message.from === 'user' ? 'ml-auto bg-primary text-primary-foreground' : 'bg-muted text-foreground'}`}>{message.text}</div>)}{isTyping && <div className="copilot-message flex max-w-[92%] items-center gap-1 rounded-2xl bg-muted px-3 py-2.5 text-xs text-foreground"><span>{typingText}</span><span className="typing-caret" aria-label="Đang soạn câu trả lời">▍</span></div>}</div><div className="mt-3 flex flex-wrap gap-1.5"><button disabled={isTyping} onClick={() => askCompanion('Ngày mai nên mua gì?')} className="command-question">Ngày mai nên mua gì?</button><button disabled={isTyping} onClick={() => askCompanion('Món nào đang bán tốt?')} className="command-question">Món nào đang bán tốt?</button><button disabled={isTyping} onClick={() => askCompanion('Có cảnh báo nào không?')} className="command-question">Có cảnh báo nào không?</button></div><div className="mt-3 flex gap-2"><input data-testid="input-insight-chat" value={chatInput} disabled={isTyping} onChange={(event) => setChatInput(event.target.value)} onKeyDown={(event) => { if (event.key === 'Enter') askCompanion(); }} placeholder="Hỏi về lãi, nhập hàng, món bán tốt..." className="min-w-0 flex-1 rounded-xl border border-input bg-background px-3 py-2.5 text-xs outline-none focus:border-primary disabled:opacity-60" /><button data-testid="button-insight-chat" disabled={isTyping} aria-label="Gửi câu hỏi cho co-pilot" onClick={() => askCompanion()} className="grid h-10 w-10 shrink-0 place-items-center rounded-xl bg-primary text-primary-foreground disabled:cursor-wait disabled:opacity-60"><ArrowUpRight size={16} /></button></div></div>
      </div>
    </section>

    <section className="workspace-card command-alert-rail p-4 md:p-5"><div className="flex flex-col justify-between gap-3 sm:flex-row sm:items-start"><div><p className="workspace-eyebrow text-muted-foreground">Action queue</p><h3 className="mt-1 font-serif text-2xl">Tín hiệu cần xử lý</h3><p className="mt-1 text-xs text-muted-foreground">Không chỉ xem cảnh báo — chọn việc tiếp theo ngay tại đây.</p></div><span className={`rounded-full px-2.5 py-1 text-[10px] font-bold ${alertCount ? 'bg-accent/10 text-accent' : 'bg-primary/10 text-primary'}`}>{alertCount ? `${alertCount} tín hiệu` : 'Đang ổn định'}</span></div>{mlForecastLoading ? <div data-testid="status-command-loading" className="mt-4 grid gap-3 md:grid-cols-3"><div className="skeleton-shimmer h-24 rounded-2xl" /><div className="skeleton-shimmer h-24 rounded-2xl" /><div className="skeleton-shimmer h-24 rounded-2xl" /></div> : <div className="mt-4 grid gap-3 md:grid-cols-3"><div className={`command-alert-card rounded-2xl p-4 ${alertCount ? 'command-alert-card-watch' : 'bg-muted/60'}`}><div className="flex items-center justify-between gap-2"><p className="text-xs font-bold">Cảnh báo chủ động</p><AlertTriangle size={15} className={alertCount ? 'text-accent' : 'text-muted-foreground'} /></div><p className="mt-2 text-sm text-muted-foreground">{operationalAlerts[0]?.title ?? (localAlerts.length ? `${localAlerts.length} nguyên liệu cần xem` : 'Chưa có rủi ro nổi bật')}</p></div><div className="command-alert-card rounded-2xl bg-muted/60 p-4"><div className="flex items-center justify-between gap-2"><p className="text-xs font-bold">Tồn kho hạn ngắn</p><ShoppingBasket size={15} className="text-primary" /></div><p className="mt-2 text-sm text-muted-foreground">{ingredients.filter((item) => (item.shelfLifeDays ?? 7) <= 2).length} nguyên liệu cần quan sát</p></div><div className="command-alert-card rounded-2xl bg-muted/60 p-4"><div className="flex items-center justify-between gap-2"><p className="text-xs font-bold">Việc tiếp theo</p><CheckCircle2 size={15} className="text-primary" /></div><p className="mt-2 text-sm text-muted-foreground">{insight.actionLabel}</p></div></div>}{mlForecastError && <p role="alert" className="mt-3 rounded-xl border border-accent/25 bg-accent/10 px-3 py-2.5 text-xs font-semibold text-accent">{mlForecastError} Dữ liệu dự báo nền vẫn được giữ để bạn không mất ngữ cảnh.</p>}<div className="mt-4 flex flex-wrap gap-2"><button onClick={() => onAction('restock')} className="command-action-chip"><ShoppingBasket size={14} />Mở danh sách nhập</button><button onClick={() => onAction('combo')} className="command-action-chip"><Sparkles size={14} />Tạo combo xả hàng</button><button onClick={() => onAction('audit')} className="command-action-chip"><ClipboardCheck size={14} />Mở checklist kiểm kho</button></div>{!forecast.dishes.length && <div data-testid="status-command-empty" className="mt-4"><EmptyState title="Chưa có dữ liệu món để điều hành" text="Hãy cập nhật dự báo sau khi có lịch sử bán hàng hoặc chạy mô hình ML." /></div>}</section>
    <ForecastView forecast={forecast} history={history} runs={runs} ingredients={ingredients} mlForecast={mlForecast} mlForecastLoading={mlForecastLoading} mlForecastError={mlForecastError} onMlForecast={onMlForecast} onRefresh={onRefresh} onAdjust={onAdjust} onConfirm={onConfirm} />
  </div>;
}

export default App;
