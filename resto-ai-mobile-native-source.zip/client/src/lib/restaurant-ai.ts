export type PredictRequest = {
  nhiet_do: number;
  luong_mua: number;
  ngay_trong_tuan: number;
  la_ngay_le: 0 | 1;
  thoi_tiet?: 0 | 1;
  su_kien_dac_biet: 0 | 1;
  inventory?: InventorySnapshot[];
};

export type InventorySnapshot = {
  name: string;
  unit: string;
  quantity: number;
  shelf_life_days: number;
};

export type IngredientAmount = {
  name: string;
  unit: string;
  amount: number;
  price: number;
};

export type PredictedDish = {
  id: string;
  name: string;
  servings: number;
  expected_orders: number;
  lower_bound: number;
  upper_bound: number;
  margin_of_error: number;
  previous: number;
  bom: IngredientAmount[];
};

export type IngredientRecommendation = {
  id: string;
  name: string;
  unit: string;
  quantity: number;
  price: number;
  confirmed: boolean;
};

export type ShoppingListItem = {
  id: string;
  name: string;
  unit: string;
  forecast_need: number;
  upper_need: number;
  inventory: number;
  to_buy: number;
  price: number;
  urgent: boolean;
  shelf_life_days: number;
};

export type SmartAdvice = {
  type: 'weather' | 'clearance' | 'peak_hour' | 'financial' | 'surge';
  severity: 'urgent' | 'high' | 'medium';
  title: string;
  message: string;
  action: string;
  ingredients: string[];
};

export type PredictResponse = {
  model: string;
  training_days: number;
  confidence: number;
  features: {
    nhiet_do: number;
    luong_mua: number;
    ngay_trong_tuan: number;
    la_ngay_le: 0 | 1;
    su_kien_dac_biet: 0 | 1;
  };
  dishes: PredictedDish[];
  recommendations: IngredientRecommendation[];
  shopping_list: ShoppingListItem[];
  ai_advice: SmartAdvice[];
  operational_alerts: SmartAdvice[];
};

const priceByIngredient: Record<string, number> = {
  'thịt bò thăn': 210000,
  'bánh phở tươi': 32000,
  'rau quế': 9000,
  'hành lá': 38000,
  'nước mắm nhĩ': 68000,
  'chanh tươi': 42000,
  'gạo tẻ': 18500,
  'dâu tươi': 120,
  'sữa tươi': 28,
  'ly nhựa': 1000,
};

const round = (value: number, digits = 2) => Number(value.toFixed(digits));
const slug = (value: string) => value.toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g, '').replace(/[^a-z0-9]+/g, '-').replace(/(^-|-$)/g, '');

/**
 * Deterministic offline forecast used by the static deployment.
 * It keeps the same response shape as the connected model so every AI screen
 * remains usable, while a future backend can replace this adapter directly.
 */
export async function predictIngredientDemand(request: PredictRequest): Promise<PredictResponse> {
  await new Promise((resolve) => window.setTimeout(resolve, 320));
  const inventory = request.inventory ?? [];
  const demandFactor = 1 + (request.luong_mua >= 35 ? 0.12 : request.luong_mua > 0 ? 0.05 : 0) + (request.la_ngay_le ? 0.16 : 0) + (request.su_kien_dac_biet ? 0.1 : 0);
  const dishes: PredictedDish[] = [
    { id: 'pho-bo', name: 'Phở bò tái', servings: Math.round(44 * demandFactor), expected_orders: Math.round(36 * demandFactor), lower_bound: 34, upper_bound: 58, margin_of_error: 12, previous: 40, bom: [{ name: 'Thịt bò thăn', unit: 'kg', amount: .1, price: 210000 }, { name: 'Bánh phở tươi', unit: 'kg', amount: .15, price: 32000 }] },
    { id: 'com-suon', name: 'Cơm sườn nướng', servings: Math.round(28 * demandFactor), expected_orders: Math.round(24 * demandFactor), lower_bound: 20, upper_bound: 38, margin_of_error: 9, previous: 27, bom: [{ name: 'Gạo tẻ', unit: 'kg', amount: .08, price: 18500 }] },
    { id: 'tra-sua', name: 'Trà sữa ô long', servings: Math.round(24 * demandFactor), expected_orders: Math.round(22 * demandFactor), lower_bound: 16, upper_bound: 34, margin_of_error: 8, previous: 21, bom: [{ name: 'Sữa tươi', unit: 'ml', amount: 180, price: 28 }] },
  ];
  const shoppingList = inventory.map((item) => {
    const baseNeed = Math.max(item.quantity * .18, item.name.toLowerCase().includes('bò') ? 10 : item.name.toLowerCase().includes('hành') ? 5 : item.quantity * .24);
    const forecastNeed = round(baseNeed * demandFactor);
    const toBuy = round(Math.max(0, forecastNeed - item.quantity));
    return {
      id: `forecast-${slug(item.name)}`,
      name: item.name,
      unit: item.unit,
      forecast_need: forecastNeed,
      upper_need: round(forecastNeed * 1.18),
      inventory: item.quantity,
      to_buy: toBuy,
      price: priceByIngredient[item.name.toLowerCase()] ?? 50000,
      urgent: item.shelf_life_days <= 3 && toBuy > 0,
      shelf_life_days: item.shelf_life_days,
    };
  }).filter((item) => item.to_buy > 0 || item.forecast_need > item.inventory);
  const advice: SmartAdvice[] = [];
  if (request.luong_mua > 0) advice.push({ type: 'weather', severity: request.luong_mua >= 35 ? 'high' : 'medium', title: 'Tín hiệu thời tiết', message: 'Mưa có thể làm nhu cầu món nóng tăng và lượng khách vãng lai giảm.', action: 'Chuẩn bị thêm món nước, đồng thời kiểm tra kênh giao hàng.', ingredients: ['Bánh phở tươi', 'Thịt bò thăn'] });
  if (shoppingList.length) advice.push({ type: 'surge', severity: 'high', title: 'Cần bổ sung nguyên liệu', message: `${shoppingList.length} nguyên liệu đang có nhu cầu dự báo cao hơn tồn hiện tại.`, action: 'Mở danh sách đi chợ và tạo phiếu nhập trước giờ mở cửa.', ingredients: shoppingList.slice(0, 3).map((item) => item.name) });
  advice.push({ type: 'financial', severity: 'medium', title: 'Theo dõi biên lợi nhuận', message: 'Nên đối chiếu định lượng các món bán chạy với giá vốn trước khi chốt ca.', action: 'Kiểm tra BOM của Phở bò và Cơm sườn trong mục Kho.', ingredients: ['Thịt bò thăn', 'Gạo tẻ'] });
  return {
    model: 'Resto.AI Offline Forecast',
    training_days: 60,
    confidence: Math.round(78 + Math.min(12, request.la_ngay_le * 5 + request.su_kien_dac_biet * 4)),
    features: { nhiet_do: request.nhiet_do, luong_mua: request.luong_mua, ngay_trong_tuan: request.ngay_trong_tuan, la_ngay_le: request.la_ngay_le, su_kien_dac_biet: request.su_kien_dac_biet },
    dishes,
    recommendations: shoppingList.map((item) => ({ id: item.id, name: item.name, unit: item.unit, quantity: item.to_buy, price: item.price, confirmed: false })),
    shopping_list: shoppingList,
    ai_advice: advice,
    operational_alerts: advice,
  };
}
